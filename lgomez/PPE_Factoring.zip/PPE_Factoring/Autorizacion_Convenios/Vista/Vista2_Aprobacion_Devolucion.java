package Autorizacion_Convenios.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import javax.swing.text.StyledEditorKit.BoldAction;

import resources.Autorizacion_Convenios.Vista.Vista2_Aprobacion_DevolucionHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista2_Aprobacion_Devolucion extends Vista2_Aprobacion_DevolucionHelper
{
	RenderedImage Imagen;
	String opcionAprovacion, comentario, numeroConvenio;
	
	public String testMain(Object[] args) throws IOException 
	{
		opcionAprovacion = (String)args[0];
		comentario = (String)args[1];
		numeroConvenio = (String)args[2];
		
		list_aprobacionConvenio(ANY, LOADED).click();sleep(1);
		
		if(opcionAprovacion.equals("Autorizar"))
			recorrerLista(0);
		else
			recorrerLista(1);
			
		teclado("{TAB}");sleep(1);
		teclado(comentario);
		teclado("{TAB}{TAB}");
		teclado("{ENTER}");
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, numeroConvenio + "Autorizar_Devolver", "Autorizacion_Convenios");	
		
		if(html_mesajeRespuestaDialog(ANY, LOADED).exists() && html_mesajeRespuestaDialog(ANY, LOADED).isShowing())
		{
			String resulCreacion = "";
			resulCreacion = (String)html_mesajeRespuestaDialog().getProperty(".text");
			
			button_oKbutton(ubicacion(1), DEFAULT).click();sleep(5);	
			teclado("{F5}");sleep(5);
			
			return resulCreacion;
						
		}
		else 
			return "Error NO pantalla emergente";
	}
	
	public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		
	browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
	if(nivel==1)
		return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
	else
		return browser_htmlBrowser(document_capturaConvenio(), DEFAULT);	
	}
}

