package Autorizacion_Convenios.Vista;
import resources.Autorizacion_Convenios.Vista.Vista1_TablaSeleccionHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista1_TablaSeleccion extends Vista1_TablaSeleccionHelper
{
	String numeroConvenio;
		
	public void testMain(Object[] args) 
	{
		numeroConvenio = (String)args[0];
		
		if(link_autorizaci�nConvenios(ANY, LOADED).exists() && link_autorizaci�nConvenios(ANY, LOADED).isShowing())
		{
			link_autorizaci�nConvenios().click();
			sleep(4);
		}
		else
		{
			link_factoring().click();sleep(1);	
			link_convenios().click();sleep(7);
			link_autorizaci�nConvenios().click();
			sleep(5);
		}
		
		text_htmlINPUTText(ubicacion(3), DEFAULT).setText(numeroConvenio);sleep(2);
		radioButton__0capturadoCheck(ubicacion(3), DEFAULT).click();sleep(3);
		
		//Vistas sin ingresos de datos 
		button_siguientebutton(ubicacion(1), DEFAULT).click();
		button_siguientebutton2(ubicacion(1), DEFAULT).click();
		button_siguientebutton3(ubicacion(1), DEFAULT).click();
		
	}
	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else if(nivel==2)
			return browser_htmlBrowser(document_autorizarConvenios(), DEFAULT);
		else
			return browser_htmlBrowser(table_autorizarConvenio(), DEFAULT);
			
	}
	public void teclado(String tecla){
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
		}	
}

