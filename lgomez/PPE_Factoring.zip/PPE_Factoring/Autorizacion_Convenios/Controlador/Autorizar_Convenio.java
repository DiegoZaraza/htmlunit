package Autorizacion_Convenios.Controlador;
import java.awt.image.RenderedImage;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import resources.Autorizacion_Convenios.Controlador.Autorizar_ConvenioHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Autorizar_Convenio extends Autorizar_ConvenioHelper
{
	String No_Convenio, Nombre_Convenio, opcionAprovacion, comentario;
	ArrayList<String> numeroConvenios = new ArrayList<>();
	ArrayList<String> listaConvenios = new ArrayList<>();
	String[][] data;
	String[] dataVista1 = new String[1];
	String[] dataVista2 = new String[3];
	

	
	public void testMain(Object[] args) 
	{
		/*
		 * 
		 * args[0] = Nombre del Convenio
		 * args[1] = Prosedimeinto (Autorizar o Devolver)
		 * args[2] = Convenio					
		 * 
		 */
		System.out.println("----------este----------------------------");
		for (Object object : args) {
			System.out.println(object);
		}
		System.out.println("----------este----------------------------");	
		if(args[0].equals("Autorizar todos los convenios"))
		{
			ConnecionDB();
			ResultSet resultado =Consulta("SELECT No_Convenio, Nombre_Convenio " + 
											"FROM [BD_AUT_Factoring].[dbo].[Convenio] " + 
												"WHERE Estado_convenio = 'CREADO'");
			
			try {
				while(resultado.next()){
					
					No_Convenio = resultado.getString(1);
					Nombre_Convenio = resultado.getString(2);
					
					numeroConvenios.add(No_Convenio);
					listaConvenios.add(Nombre_Convenio);
				}
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
		}
		else{
			ConnecionDB();
			ResultSet resultado =Consulta("SELECT TOP 1 No_Convenio, Nombre_Convenio " + 
											"FROM [BD_AUT_Factoring].[dbo].[Convenio] " + 
												"WHERE Estado_convenio = 'CREADO' " +
													"AND No_Convenio = '" + (String)args[2] + "'");
			try {
				while(resultado.next()){
					
					No_Convenio = resultado.getString(1);
					Nombre_Convenio = resultado.getString(2);
					
					numeroConvenios.add(No_Convenio);
					listaConvenios.add(Nombre_Convenio);
				}
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
		}	
		
		if((boolean)callScript("Scripts.Login"))
			System.out.println("lOGIN");
		
		data = new String[listaConvenios.size()][4];
		grabarArchivo("AUTORIZACION CONVENIOS", "Autorizacion_Convenios");
		
		//CICLO QUE RELIZA LA AUTORIXZACION DE LOS CONVENIOS ESCOGIDOS
		for (int i = 0; i < listaConvenios.size(); i++) {
			
			
			grabarArchivo("CONVENIO: " + numeroConvenios.get(i) + " (" + listaConvenios.get(i) + ")" , "Autorizacion_Convenios");
			
			//Vista1 
			dataVista1[0] = numeroConvenios.get(i);
			callScript("Autorizacion_Convenios.Vista.Vista1_TablaSeleccion",  dataVista1);
			
			//vista2
			dataVista2[0] = (String)args[1];
			dataVista2[1] = "Pruebas Automatizacion";
			dataVista2[2] = numeroConvenios.get(i);
			Object resulAuto = callScript("Autorizacion_Convenios.Vista.Vista2_Aprobacion_Devolucion", dataVista2);
			String cadena = (String) resulAuto;
			
			if(args[1].equals("Autorizar")){
				if(cadena.equals("Convenio aprobado correctamente")){
					data[i][0]= numeroConvenios.get(i); 
					data[i][1]= "Convenio aprobado correctamente";
					data[i][2]= cadena;
					data[i][3]= "Exitoso";
				
					//Ciclo que diferencia si el convenio se creo por regresion o por genracion de datos 
					if(args.length == 3){
						ejecutar("UPDATE Convenio " +
							"SET Estado_convenio = 'CREADO-APROBADO' " +
								"WHERE No_Convenio = '" + numeroConvenios.get(i) + "'");
					}
					else
					{
						ejecutar("UPDATE Convenio " +
								"SET Estado_convenio = 'CREADO/APROBADO' " +
									"WHERE No_Convenio = '" + numeroConvenios.get(i) + "'");
					}
				}
				else
				{
					data[i][0]= numeroConvenios.get(i); 
					data[i][1]= "Convenio aprobado correctamente";
					data[i][2]= cadena;
					data[i][3]= "Fallido";	
				}
			}
			else{ 
				if(cadena.equals("Convenio devuelto correctamente")){
					
					data[i][0]= numeroConvenios.get(i); 
					data[i][1]= "Convenio devuelto correctamente";
					data[i][2]= cadena;
					data[i][3]= "Exitoso";
									
					ejecutar("UPDATE Convenio " +
								"SET Estado_convenio = 'DEVUELTO' " +
									"WHERE No_Convenio = '" + numeroConvenios.get(i) + "'");
				}
				else
				{
					data[i][0]= numeroConvenios.get(i); 
					data[i][1]= "Convenio devuelto correctamente";
					data[i][2]= cadena;
					data[i][3]= "Fallido";	
				
				}
			}
		}
		
		createPdf("Autorizacion_Convenios");
		createPdfInforme("INFORME AUTORIZACION CONVENIOS", data);
	}
}

