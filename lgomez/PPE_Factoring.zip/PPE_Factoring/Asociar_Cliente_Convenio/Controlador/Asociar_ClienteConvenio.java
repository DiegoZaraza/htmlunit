package Asociar_Cliente_Convenio.Controlador;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import resources.Asociar_Cliente_Convenio.Controlador.Asociar_ClienteConvenioHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Asociar_ClienteConvenio extends Asociar_ClienteConvenioHelper
{
	
	String no_convenio, tipoDocumento, no_documento, no_plan;
	String[] datavista1 = new String[1];
	String[] datavista2 = new String[2];
	String[] datavista3 = new String[3];
	String[][] data = new String[1][4];;
	
	public void testMain(Object[] args) 
	{
		ConnecionDB();
		/*
		 * 
		 *args[0] = No_Convenio
		 *args[1] = Tipo_Documento Cliente
		 *args[2] = No_Documento Cliente
		 *args[3] = No_Plan
		 *
		 */
//		args = new Object[4];
//		args[0] = "5000227";
//		args[1] = "NPJ";
//		args[2] = "8600741851";
//		args[3] = "1199";
		
		System.out.println("*-*-*-*-*-*-*-*-*-**-***-*-**");
		for (Object object : args) {
			System.out.println(object);
		}
		System.out.println("*-*-*-*-*-*-*-*-*-**-***-*-**");
		if(args[0].equals("1") || args[0].equals("2") || args[0].equals("3") || args[0].equals("4")){
			
			args = new Object[4];
			ResultSet resultado = Consulta("SELECT TOP 1 Cliente_Con_Convenio.No_Convenio, Cliente_Con_Convenio.No_Documento, Tipo_Documento " +
											"FROM Cliente_Con_Convenio INNER JOIN Cliente " + 
											"ON Cliente_Con_Convenio.Estado = 'PROPUESTO'");
			
			try {
				while(resultado.next()) {
					no_convenio = resultado.getString(1);
					no_documento = resultado.getString(2);
					tipoDocumento = resultado.getString(3);
				}
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
			
			
			ResultSet resultadoPlan = Consulta("SELECT Top 1 No_Plan " +
												"FROM PlanFinanciero " + 
												"WHERE No_Convenio = '" + no_convenio + "' AND Estado_Plan = 'CREADO/APROBADO'");
			
			try {
				while(resultadoPlan.next()) {
					no_plan = resultadoPlan.getString(1);
				}
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
			
		}
		else{
			no_convenio = (String)args[0];
			tipoDocumento = (String)args[1];
			no_documento = (String)args[2];
			no_plan = (String)args[3];
		}
		
		grabarArchivo("ASOCIAR CLIENTE CON CONVENIO", "Asociacion_Cliente_Convenio");
		grabarArchivo("CONVENIO: " + no_convenio, "Asociacion_Cliente_Convenio");
		grabarArchivo("CLIENTE: " + no_documento, "Asociacion_Cliente_Convenio");
		grabarArchivo("PLAN: " + no_plan, "Asociacion_Cliente_Convenio");
		
		
		if((boolean)callScript("Scripts.Login"))
			System.out.println("lOGIN");
		
		//Vista1
		datavista1[0] = no_convenio ;
		callScript("Asociar_Cliente_Convenio.Vista.Vista1_ConsultaConvenio", datavista1);
		
		//Vista2
		datavista2[0] = tipoDocumento;
		datavista2[1] = no_documento;
		callScript("Asociar_Cliente_Convenio.Vista.Vista2_ClienteAsociar", datavista2);
		
		//Vista3
		datavista3[0] = no_plan;
		Object resultado = callScript("Asociar_Cliente_Convenio.Vista.Vista3_DatosPLan", datavista3);
		String cadena =(String)resultado;
		
		if(cadena.length() == 0){
			
			data[0][0] = "Clien: " + no_documento + "-Conve:" + no_convenio;
			data[0][1] = "Cliente asociado correctamente al plan: XXXX";
			data[0][2] = cadena;
			data[0][3] = "Fallido";
			
			grabarArchivo("Clien: " + no_documento + "-Conve:" + no_convenio, "Consolidado_Asociacion");
			grabarArchivo("Cliente asociado correctamente al plan: XXXX", "Consolidado_Asociacion");
			grabarArchivo(cadena, "Consolidado_Asociacion");
			grabarArchivo("Fallido", "Consolidado_Asociacion");

		}
		else if(cadena.substring(0,21).equals("Cliente asociado corr"))
		{
			data[0][0] = "Clien: " + no_documento + "-Conve:" + no_convenio;
			data[0][1] = "Cliente asociado correctamente al plan: XXXX";
			data[0][2] = cadena;
			data[0][3] = "Exitoso";
			
			grabarArchivo("Clien: " + no_documento + "-Conve:" + no_convenio, "Consolidado_Asociacion");
			grabarArchivo("Cliente asociado correctamente al plan: XXXX", "Consolidado_Asociacion");
			grabarArchivo(cadena, "Consolidado_Asociacion");
			grabarArchivo("Exitoso", "Consolidado_Asociacion");

			ejecutar("UPDATE Cliente_Con_Convenio " +
						"SET No_Plan = '" + no_plan + "', Estado = 'ASOCIADO' " +
						"WHERE No_Convenio = '" + no_convenio + "' AND No_Documento = '" + no_documento + "'");
			
			ejecutar("UPDATE PlanFinanciero " +
						"SET Estado_Plan = 'CREA/APRO/ASOCI' " +
						"WHERE No_Plan = '" + no_plan + "'");
			
		}
		else
		{
			data[0][0] = "Clien: " + no_documento + "-Conve:" + no_convenio;
			data[0][1] = "Cliente asociado correctamente al plan: XXXX";
			data[0][2] = cadena;
			data[0][3] = "Fallido";
			
			grabarArchivo("Clien: " + no_documento + "-Conve:" + no_convenio, "Consolidado_Asociacion");
			grabarArchivo("Cliente asociado correctamente al plan: XXXX", "Consolidado_Asociacion");
			grabarArchivo(cadena, "Consolidado_Asociacion");
			grabarArchivo("Fallido", "Consolidado_Asociacion");
		}
		
		
		createPdf("Asociacion_Cliente_Convenio");
		createPdfInforme("INFORME ASOCIAR CLIENTE_CONVENIO", data);
		createPdfInforme("INFORME CONSOLIDADO ASOCIACION", ObtenerConsolidado("Consolidado_Asociacion"));
	}
}

