package Asociar_Cliente_Convenio.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Asociar_Cliente_Convenio.Vista.Vista1_ConsultaConvenioHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista1_ConsultaConvenio extends Vista1_ConsultaConvenioHelper
{
	String no_convenio;
	RenderedImage Imagen;
	
	public void testMain(Object[] args) throws IOException 
	{
		no_convenio = (String)args[0];
		
		if(link_asociarClienteAConvenios(ANY, LOADED).exists() && link_asociarClienteAConvenios(ANY, LOADED).isShowing())
		{
			link_asociarClienteAConvenios().click();
			sleep(4);
		}
		else
		{
			link_factoring().click();sleep(1);	
			link_asociaci�nClienteAConveni().click();sleep(1);
			link_asociarClienteAConvenios().click();
		}
		
		text_numeroConvenio().click();
		text_numeroConvenio().setText(no_convenio);
		teclado("{TAB}{TAB}");
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, "No_Convenio_" + no_convenio, "Asociacion_Cliente_Convenio");		
		teclado("{ENTER}");	
	}
	
	public void recorrerLista(int cantidad){
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else 
			return browser_htmlBrowser(document_asociarClienteConveni(), DEFAULT);	
	}
}

