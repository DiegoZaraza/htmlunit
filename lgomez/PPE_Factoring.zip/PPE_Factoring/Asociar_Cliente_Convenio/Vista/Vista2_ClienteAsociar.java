package Asociar_Cliente_Convenio.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Asociar_Cliente_Convenio.Vista.Vista2_ClienteAsociarHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista2_ClienteAsociar extends Vista2_ClienteAsociarHelper
{
	String tipoDocumento, no_documento;
	RenderedImage Imagen;
	
	public void testMain(Object[] args) throws IOException 
	{
		tipoDocumento = (String)args[0];
		no_documento = (String)args[1];
		
		list_tipoIdentificacion().click();
		
		if(tipoDocumento.equals("CC"))
			recorrerLista(0);
		else
			recorrerLista(1);
		
		teclado("{TAB}");
		text_numeroIdentificacion().setText(no_documento);
		teclado("{TAB}");
		text_centroCostosAso().click();
		teclado("{Num2}");sleep(2);
		recorrerLista(GetRandom1_10());
		teclado("{TAB}{TAB}");
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, "No_Documento_" + no_documento, "Asociacion_Cliente_Convenio");	
		teclado("{ENTER}");	
	}
	
	public void recorrerLista(int cantidad){
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else 
			return browser_htmlBrowser(document_asociarClienteConveni(), DEFAULT);	
	}
}

