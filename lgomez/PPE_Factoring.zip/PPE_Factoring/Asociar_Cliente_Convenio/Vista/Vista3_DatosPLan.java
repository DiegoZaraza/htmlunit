package Asociar_Cliente_Convenio.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Asociar_Cliente_Convenio.Vista.Vista3_DatosPLanHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista3_DatosPLan extends Vista3_DatosPLanHelper
{
	String no_plan;
	RenderedImage Imagen;
	
	public String testMain(Object[] args) throws IOException 
	{
		no_plan = (String)args[0];
	
		text__1403().click();
		text__1403().setText(no_plan);
		radioButton__1403(ubicacion(1), DEFAULT).click();
		button_asociarbutton().click();
		
//		html_mesajeRespuestaDialog().button_oKbutton().
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, "No_Plan_" + no_plan, "Asociacion_Cliente_Convenio");	
		
		if(html_mesajeRespuestaDialog(ANY, LOADED).exists() && html_mesajeRespuestaDialog(ANY, LOADED).isShowing())
		{
			String resulCreacion = "";
			resulCreacion = (String)html_mesajeRespuestaDialog().getProperty(".text");
			
			button_oKbutton(ubicacion(1), DEFAULT).click();sleep(5);	
			teclado("{F5}");sleep(5);
			
			return resulCreacion;
						
		}
		else 
			return "Error NO pantalla emergente";
	
	}
	
	public void recorrerLista(int cantidad){
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else 
			return browser_htmlBrowser(document_asociarClienteConveni(), DEFAULT);	
	}
}

