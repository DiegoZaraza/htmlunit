package SuperClaseAyudante;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;
import com.rational.test.ft.object.interfaces.GuiTestObject;
import com.rational.test.ft.object.interfaces.TestObject;
import com.rational.test.ft.script.DatapoolScriptSupport;
import com.rational.test.ft.script.IOptionName;
import com.rational.test.ft.script.RationalTestScript;
import com.rational.test.ft.sys.graphical.NoMatchingWindowException;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import java.io.BufferedReader; 
import java.net.MalformedURLException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JTable;







//import org.apache.xalan.templates.ElemNumber;
import org.eclipse.hyades.edit.datapool.IDatapool;
import org.eclipse.hyades.execution.runtime.datapool.IDatapoolIterator;

public abstract class ClaseAyudante extends RationalTestScript
{

	private java.sql.Connection Conec = null;
	Statement St;
	Paragraph parrafo;

	/**
	 * 
	 * METODOS PARA MANEJO DE LOGS (ARCHIVOS .TXT y ARCHIVOS .JPG)
	 * 
	 * */

	//FUNCION PARA CREAR LOG DE EVENTOS
	public void CrearLog(String nombre) 
	{
		@SuppressWarnings("unused")
		File Salida = new File("D:\\PPE_Factoring\\Resultados Ejecucion\\Log_Cp_" + nombre + ".txt");
	}

	//FUNCION PARA REGISTRAR DATOS EN EL LOG
	public void grabarArchivo(String registro, String nombre) 
	{		
		try 
		{
			//CARGA EL ARCHIVO
			PrintStream Salida = new PrintStream(new FileOutputStream("D:\\PPE_Factoring\\Resultados Ejecucion\\Log_Cp_" + nombre + ".txt", true));

			//ENVIA REGISTRO AL SCRIPT
			Salida.println(registro);
			Salida.close();
		}
		catch (FileNotFoundException e) 
		{
			//ERROR EN CASO DE NO GRABAR EL ARCHIVO
			e.printStackTrace();
		}
	}

	//FUNCION PARA GUARDAR LAS IMAGENES CAPTURADAS
	public void guardarImagen(RenderedImage image, String Nombre, String args) throws IOException
	{
		String ruta = "D:\\PPE_Factoring\\Resultados Ejecucion\\" + Nombre + ".jpg";

		grabarArchivo(ruta, args);
		//DECLARA Y CREA EL ARCHIVO CON LA IMAGEN RECIBIDA
		File file = new File(ruta);
		ImageIO.write(image, "jpg", file);
	}

	public void createPdf(String nombrePDF) 
	{
		//SE CREA UN DOCUMENTO CON TAMA�O CARTA Y SE ESCOJE LA RUTA Y NOMBRE DEL ARCHIVO 
		Document documento = new Document(PageSize.LETTER, 85, 85, 114, 60);
		String archivo = "D:\\PPE_Factoring\\Resultados Ejecucion\\" + nombrePDF + ".pdf";
		PdfWriter writer = null; 
		try {
			writer = PdfWriter.getInstance(documento, new FileOutputStream(archivo,true));
			FooterPiePaginaiText event = new FooterPiePaginaiText();
			writer.setPageEvent(event);

			//SE LE AGREGA EL TITULO Y AUTOR AL DOCUMENTO
			documento.addTitle("Registro Pruebas de Regresi�n Transacci�n - " + nombrePDF );
			documento.addAuthor("Equipo de Automatizaci�n - Direcci�n de Desarrollo Tecnologico");
			//SE ABRE EL DOCUMENTO PARA PODER INGRESRALO LO NECESARIO 
			documento.open();

			//SE CREA UN PARAGRAFO QUE LLEBA EL ENCABEZADO DEL DOCUMENTO TITULO LETRA GRANDE 
			Paragraph titulo = new Paragraph();
			titulo.setAlignment(Paragraph.ALIGN_CENTER);
			titulo.setFont(FontFactory.getFont("Sans",15,Font.BOLD));
			titulo.add("Registro Pruebas " + nombrePDF);
			titulo.add("\n");
			titulo.add("\n");
			//SE AGREGA EL PARAGRAFO AL DOCUMENTO 
			documento.add(titulo);


			//SE AGREGA REALIZA LA LECTURA DEL ARCHIVO DE TEXT QUE CONTIENE LOS RESSULTADOS DE LAS PRUEBAS 
			String Cadena = "D:\\PPE_Factoring\\Resultados Ejecucion\\Log_Cp_" + nombrePDF + ".txt";
			FileReader file = new FileReader(Cadena);
			@SuppressWarnings("resource")
			BufferedReader buffer = new BufferedReader(file);

			PdfPTable table = creartabla(documento);

			//CICLO QUE CONTROLA LA LECTURA DEL TXT
			while((Cadena = buffer.readLine())!= null)
			{
				System.out.println(Cadena);
				if(Cadena.substring(0, 2).equals("D:")) 
				{
					Image imagen = Image.getInstance(Cadena);
					imagen.setAlignment(Image.ALIGN_CENTER);
					imagen.setUseVariableBorders(true);
					imagen.scalePercent(30);
					createCellImg(imagen, 0, 1, Element.ALIGN_CENTER, documento, table);
				}
				else
					createCell(Cadena, 0, 1, Element.ALIGN_JUSTIFIED, documento, table);
			}
			
			documento.add(table);
			documento.close();
			writer.close();

		} catch (FileNotFoundException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
		catch (MalformedURLException e){
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}
	}     
	public PdfPTable creartabla(Document doc) {
		PdfPTable table = new PdfPTable(1);
		table.setTotalWidth(442);

		return table;
	}

	public void createCell(String content, float borderWidth, int colspan, int alignment, Document doc, PdfPTable table) throws DocumentException, IOException {
		Font contenido = new Font(BaseFont.createFont("d:/resources/kalinga.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 9, Font.NORMAL, BaseColor.BLACK);
		PdfPCell cell = new PdfPCell(new Phrase(content, contenido));
		cell.setBorderWidth(borderWidth);
		cell.setColspan(colspan);
		cell.setHorizontalAlignment(alignment);

		table.addCell(cell);
	}

	public void createCellTitle(String content, float borderWidth, int colspan, int alignment, Document doc, PdfPTable table) throws DocumentException, IOException {
		Font titulos = new Font(BaseFont.createFont("d:/resources/kalinga.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 10, Font.BOLD, BaseColor.BLACK);
		PdfPCell cell = new PdfPCell(new Phrase(content, titulos));
		cell.setBorderWidth(borderWidth);
		cell.setColspan(colspan);
		cell.setHorizontalAlignment(alignment);

		table.addCell(cell);
	}

	public void createCellImg(Image imagen, float borderWidth, int colspan, int alignment, Document doc, PdfPTable table) throws DocumentException, IOException {
		PdfPCell cell = new PdfPCell(imagen);

		cell.setBorderWidth(borderWidth);
		cell.setColspan(colspan);
		cell.setHorizontalAlignment(alignment);

		table.addCell(cell);
	}

	/* M�otdo para agregar una im�gen a un PDF */
	

	/* M�todo para cerrar PDF */
	public void closePDF(Document doc, PdfPTable table) throws DocumentException {
		doc.add(table);
		doc.close();
	}
	public class FooterPiePaginaiText extends PdfPageEventHelper {

		Font piePagina, encabezado;

		public void onStartPage(PdfWriter writer, Document document) {	
			try {
				encabezado = new Font(BaseFont.createFont("D:/resources/kalinga.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 12, Font.BOLD, BaseColor.BLACK);
				piePagina = new Font(BaseFont.createFont("d:/resources/kalinga.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 9, Font.NORMAL, BaseColor.BLACK);
			} catch (DocumentException | IOException e1) {
				// TODO Bloque catch generado autom�ticamente
				e1.printStackTrace();
			}
			Image img;
			try {
				img = Image.getInstance("D:/resources/Logo.jpg");
				img.scaleAbsolute(114, 39);
				img.setAbsolutePosition(document.left(), document.top() + 30);
				writer.getDirectContent().addImage(img);
			} catch (BadElementException e) {
				e.printStackTrace();
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (DocumentException e) {
				e.printStackTrace();
			}

			Paragraph texto1 = new Paragraph("DIRECCI�N DE DESARROLLO TECNOL�GICO", encabezado);
			Paragraph texto2 = new Paragraph("Checklist Armado Versi�n", piePagina);

			String annio = ObtenerFecha1().substring(0,4);
			String mes = ObtenerFecha1().substring(4,6);
			String dia = ObtenerFecha1().substring(6,8);

			Paragraph texto3 = new Paragraph(dia + "/" + mes + "/" + annio, piePagina);

			texto2.setAlignment(Paragraph.ALIGN_CENTER);
			texto1.setAlignment(Paragraph.ALIGN_CENTER);
			texto3.setAlignment(Paragraph.ALIGN_CENTER);


			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER, texto1, 363, document.top() + 57, 0);
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT, texto2, 199, document.top() + 37, 0);
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_RIGHT, texto3, document.right(), document.top() + 37, 0);

		}

		public void onEndPage(PdfWriter writer, Document document) {
			Paragraph texto2 = new Paragraph("Automatizaci�n de Pruebas", piePagina);
			Paragraph NroPagina = new Paragraph("" + document.getPageNumber(), piePagina);
			Paragraph texto4 = new Paragraph("Versi�n Mes de " + ObtenerMes(), piePagina);

			texto2.setAlignment(Paragraph.ALIGN_LEFT);
			NroPagina.setAlignment(Paragraph.ALIGN_RIGHT);
			texto4.setAlignment(Paragraph.ALIGN_CENTER);

			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_RIGHT, NroPagina, document.right(), document.bottom() - 30, 0);
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT, texto2, document.left(), document.bottom() - 30, 0);
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER, texto4, 363, document.bottom() - 30, 0);
		}
	}
	
	public String ObtenerFecha1() {
		String fecha;
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("yyyyMMdd");
		fecha = formato.format(calendar.getTime());
		return fecha;
	}
	public String[][] ObtenerConsolidado(String nombrePDF){

		int aux=0;
		int aux2=0;
		ArrayList<String> listaMensajes = new ArrayList<String>();
		String cadena = "D:\\PPE_Factoring\\Resultados Ejecucion\\Log_Cp_" + nombrePDF + ".txt";
		FileReader file;

		try {
			file = new FileReader(cadena);
			BufferedReader buffer = new BufferedReader(file);

			while((cadena = buffer.readLine())!= null)
				listaMensajes.add(cadena);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}

		String[][] auxm = new String[listaMensajes.size()/4][4];
		for(int i = 0; i<listaMensajes.size(); i++)
		{
			auxm[aux][aux2]=listaMensajes.get(i);
			if(aux2==3){
				aux2=0;
				aux++;
			}
			else
				aux2++;
		}
		return auxm;	
	}
	public void createPdfInforme(String nombrePDF, String [][] arreglo)
	{
		Document document = new Document(PageSize.A4.rotate());

		try {
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("D:\\PPE_Factoring\\Resultados Ejecucion\\" + nombrePDF + ".pdf"));
			FooterPiePaginaiText event = new FooterPiePaginaiText();
			writer.setPageEvent(event);
			document.open();

			PdfPTable table  = new PdfPTable(4);
			Paragraph titulo = new Paragraph();
			titulo.setAlignment(Paragraph.ALIGN_CENTER);
			titulo.setFont(FontFactory.getFont("Sans",15,Font.BOLD));
			titulo.add(nombrePDF);
			titulo.add("\n");
			titulo.add("\n");
			titulo.add("\n");
			Paragraph titulo2 = new Paragraph();
			titulo2.setAlignment(Paragraph.ALIGN_CENTER);
			titulo2.setFont(FontFactory.getFont("Sans",13,Font.BOLD));
			titulo2.add("Caso de Prueba");
			Paragraph titulo3 = new Paragraph();
			titulo3.setAlignment(Paragraph.ALIGN_CENTER);
			titulo3.setFont(FontFactory.getFont("Sans",13,Font.BOLD));
			titulo3.add("Resultado Esperado");
			Paragraph titulo4 = new Paragraph();
			titulo4.setAlignment(Paragraph.ALIGN_CENTER);
			titulo4.setFont(FontFactory.getFont("Sans",13,Font.BOLD));
			titulo4.add("Resultado Obtenido");
			Paragraph titulo5 = new Paragraph();
			titulo5.setAlignment(Paragraph.ALIGN_CENTER);
			titulo5.setFont(FontFactory.getFont("Sans",13,Font.BOLD));
			titulo5.add("Veredicto");

			table.addCell(titulo2);
			table.addCell(titulo3);
			table.addCell(titulo4);
			table.addCell(titulo5);

			for(int i = 0 ; i<arreglo.length; i++){
				for(int j = 0; j<4; j++)
					table.addCell(arreglo[i][j]);
			}

			document.add(titulo);
			document.add(table);
			document.close();

		} catch (FileNotFoundException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}

	}	


	//METODO QUE RECORTA LA IMAGEN A UNAS MEDIDAS PREESTABLESIDAS 
	public void cutImage(String ruta)throws IOException
	{
		File file = new File(ruta);
		BufferedImage bi = ImageIO.read(file);

		if(bi.getWidth() > 937)
		{
			bi = bi.getSubimage(0, 0, 937, bi.getHeight());
			ImageIO.write(bi, "jpg", file);
		}
	}

	public String ObtenerMes() {
		Calendar miCalendario = Calendar.getInstance();
		int mes;
		String m;

		if (ObtenerDia() > 20)
			if (miCalendario.get(Calendar.MONTH) == 11)
				mes = 1;
			else
				mes = miCalendario.get(Calendar.MONTH) + 2;
		else
			mes = miCalendario.get(Calendar.MONTH) + 1;

		if (mes < 10)
			m = "0" + mes;
		else
			m = "" + mes;

		String mesCertif = null;
		switch (m) {

		case "01": {
			mesCertif = "Enero";
			break;
		}
		case "02": {
			mesCertif = "Febrero";
			break;
		}
		case "03": {
			mesCertif = "Marzo";
			break;
		}
		case "04": {
			mesCertif = "Abril";
			break;
		}
		case "05": {
			mesCertif = "Mayo";
			break;
		}
		case "06": {
			mesCertif = "Junio";
			break;
		}
		case "07": {
			mesCertif = "Julio";
			break;
		}
		case "08": {
			mesCertif = "Agosto";
			break;
		}
		case "09": {
			mesCertif = "Septiembre";
			break;
		}
		case "10": {
			mesCertif = "Octubre";
			break;
		}
		case "11": {
			mesCertif = "Noviembre";
			break;
		}
		case "12": {
			mesCertif = "Diciembre";
			break;
		}
		}
		return mesCertif;
	}
	//METODO QUE PINTA EN EL ARCHIVO DE RESULTADOS 
	public Integer ObtenerDia() {
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		return diaHoy;
	}


	/**
	 * 
	 * METODOS PARA EL MANEJO DE HORA, MINUTOS Y SEGUNDOS (FECHAS)
	 * 
	 * */

	/* M�todo para Obtener Fecha Sin Prorrata en formato Mes/Dia/A�o */
	public String FechaReporte(){
		String fecha;	
		Date fechaActual = new Date();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");

		fecha = formato.format(calendar.getTime());
		return fecha;

	}


	// M�todo para obtener HORA en formato Hora:Minutos:Segundos
	public String ObtenerHora(){
		Calendar calendario = Calendar.getInstance();
		int hora, minutos, segundos;
		hora =calendario.get(Calendar.HOUR_OF_DAY);
		minutos = calendario.get(Calendar.MINUTE);
		segundos = calendario.get(Calendar.SECOND);
		return hora + ":" + minutos + ":" + segundos;
	}

	// M�todo para obtener FECHA en formato, A�o/Mes/Dia
	public String ObtenerFecha(){
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		int mes=miCalendario.get(Calendar.MONTH)+1;
		int a�o =miCalendario.get(Calendar.YEAR);
		return diaHoy+"/"+mes+"/"+a�o;
	}

	public String ObtenerFechaVencimientoConvenio(){
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		int mes=miCalendario.get(Calendar.MONTH)+1;
		int a�o =miCalendario.get(Calendar.YEAR)+10;

		if(mes == 2 && diaHoy >28)
			a�o += 1;
		return diaHoy+"/"+mes+"/"+a�o;
	}	
	public String ObtenerFechaVencimientoCupo(){
		int a�o;
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		int mes=miCalendario.get(Calendar.MONTH)+8;
		if(mes <7)
			a�o =miCalendario.get(Calendar.YEAR)+1;
		else
			a�o =miCalendario.get(Calendar.YEAR);
		return mes + "/" + diaHoy + "/"+ a�o;
	}	

	public String ObtenerFechaDesembolso(){
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		int mes=miCalendario.get(Calendar.MONTH)+2;
		int a�o =miCalendario.get(Calendar.YEAR)+10;
		return diaHoy+"/"+mes+"/"+a�o;
	}
	public String ObtenerFechaDesembolsoCupo(){
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		int mes=miCalendario.get(Calendar.MONTH)+10;
		int a�o =miCalendario.get(Calendar.YEAR)-1;
		return diaHoy+"/"+mes+"/"+a�o;
	}
	//Obtener fecha en formato database
	public String ObtenerFechaForDB(){
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		int mes=miCalendario.get(Calendar.MONTH)+1;
		int a�o =miCalendario.get(Calendar.YEAR);
		return a�o + "-" + mes + "-" + diaHoy;
	}

	public String ObtenerFechaVencimientoForDB(){
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		int mes=miCalendario.get(Calendar.MONTH)+1;
		int a�o =miCalendario.get(Calendar.YEAR)+10;

		if(mes == 2 && diaHoy >28)
			a�o += 1;
		return a�o + "-" + mes + "-" + diaHoy;
	}
	//
	public String ObtenerAno(){
		Calendar miCalendario = Calendar.getInstance();
		int a�o =miCalendario.get(Calendar.YEAR);
		
		return ""+a�o;
	}

	/**
	 * METODOS PARA ADMINISTRACION 
	 * */

	//M�todo para cerrar navegadores
	public void cerrarNavegadores() 
	{
		// Buscar objetos de navegador con la funci�n find de // Rational
		// Functional Tester y almacenarlos en el objeto de prueba
		TestObject[] browsers = find(atChild(".class", "Html.HtmlBrowser"));
		if (browsers.length == 0) {
			System.out.println("Found no Html.HtmlBrowser");
			return;
		}
		for (TestObject browser : browsers) {
			((com.rational.test.ft.object.interfaces.BrowserTestObject) browser)
			.close();
		}
		// Anular el registro de los objetos de prueba.
		unregister(browsers);
	}

	// M�todo para generalizar Espera en el proyecto seg�n tiempos de respuesta del aplicativo
	public void Espera (int Segundos){
		sleep(Segundos*3);
	}

	// M�todo para obtener el nombre del Datapool 
	public String getDatapool (String ProductoDesembolso){

		String strDatapool= null;
		if (ProductoDesembolso.equals("BB01")){
			strDatapool = "BB01_LibreDestino";
		}
		if (ProductoDesembolso.equals("BB27")){
			strDatapool = "BB27_LibranzasMantiz";
		}
		if (ProductoDesembolso.equals("B002")){
			strDatapool = "B002_Crediservice";
		}
		if (ProductoDesembolso.equals("B131")){
			strDatapool = "B131_CredifacilLibranzasConvenioMensual";
		}
		if (ProductoDesembolso.equals("M002")){
			strDatapool = "M002_Liquidez_30_dias_hasta_180_dias";
		}
		if (ProductoDesembolso.equals("B300")){
			strDatapool = "B300_Finagro";
		}
		if (ProductoDesembolso.equals("M007")){
			strDatapool = "M007_Liquidez_12_Meses";
		}
		if (ProductoDesembolso.equals("BB15")){
			strDatapool = "BB15_Vehiculo_Red_BancoBogota";
		}
		if (ProductoDesembolso.equals("M039")){
			strDatapool = "M039_Liquidez_18_Meses";
		}
		if (ProductoDesembolso.equals("BP14")){
			strDatapool = "BP14_Rotativo_Premium_PN";
		}
		return strDatapool;
	}

	// M�todo para comparar si un string esta un vector o no
	public boolean Comparacion (String[] vector, String valor ){

		String tmp=null;
		for (int i = 0; i < vector.length; i++) {
			if (vector[i].equals(valor)) {
				tmp=vector[i];
			} 
		}

		if (tmp== null) {
			return false;
		} else {
			return true;
		}

	}

	//M�todo para obtener un substring, especificando inicio y fin
	public String getSubString(String string, int inicio, int fin){

		String stringFinal= "";
		stringFinal= string.substring(inicio, fin);
		return stringFinal;
	}

	public String[] llenarconPN(String[] Vector){

		// Llenar array tipos de Persona Natural		
		Vector[0]="C - Cedula De Ciudadania";
		Vector[1]="T - Tarjeta de Identidad";
		Vector[2]="P - Pasaporte";
		Vector[3]="E - C�dula de Extranjeria";
		Vector[4]="R - Registro Civil";

		return Vector;
	}

	/**
	 * METODOS PARA MENEJO DE BASE DE DATOS 
	 * */

	public void ConnecionDB() {

		try{
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Conec =DriverManager.getConnection("jdbc:sqlserver://AQUILESSQL25\\REPOSITORY;databaseName=BD_AUT_Factoring;","usr_AUTFactoring","usr_AUTFactoring#6547");

			if (Conec != null){

				System.out.println("Successfully connected");

			}
		}
		catch ( SQLException excepcionSql)
		{
			JOptionPane.showMessageDialog( null, excepcionSql.getMessage(),"Error en base de datos", JOptionPane.ERROR_MESSAGE );
		}

		catch ( ClassNotFoundException claseNoEncontrada ){
			JOptionPane.showMessageDialog( null, claseNoEncontrada.getMessage(),"No se encontr� el controlador", JOptionPane.ERROR_MESSAGE );
		}
	}
	//Metodo de ejecucion de insert,update,delete a la base de datos
	public String ejecutar(String sql) {

		String error="";
		try {
			St=Conec.createStatement();
			St.executeQuery(sql);

		}
		catch(Exception ex){
			error = ex.getMessage();

		}
		return(error);
	}

	//Metodo para las consultas a la base de datos
	public ResultSet Consulta(String sql) {
		ResultSet res = null;
		try
		{
			Statement s = Conec.createStatement();
			res = s.executeQuery(sql);
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		return res;
	}

	/**
	 * METODOS FUNCOIONALES
	 * */

	public int GetRandom1_2() {
		int num = 0;
		Random rnd = new Random();
		if(rnd.nextDouble()<= 0.5)
			num = 1;
		else
			num = 2;

		return num;
	}
	public int GetRandom1_10() {

		int num = 0;

		Random rn = new Random();
		num = rn.nextInt(9);

		return num;
	}

	public boolean EsNumero(String str)  
	{  
		try  
		{  
			int d = Integer.parseInt(str);  
		}  
		catch(NumberFormatException nfe)  
		{  
			return false;  
		}  
		return true;  
	}

	public String obtenerPrefijo(int x){

		int noConsecutivo = x;
		ResultSet resultadoperistencia =Consulta("SELECT Consecutivo FROM Persistencia WHERE Id_Persistencia = 1");

		try {
			while(resultadoperistencia.next()){

				noConsecutivo = noConsecutivo + resultadoperistencia.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}

		String aux="";
		if(noConsecutivo >9 && noConsecutivo <99)
			aux = "A00" + noConsecutivo;  
		else if(noConsecutivo >99 && noConsecutivo <999)
			aux = "A0" + noConsecutivo; 
		else if(noConsecutivo >999 && noConsecutivo <9999)
			aux = "A" + noConsecutivo; 
		else
			aux = "A000" + noConsecutivo;

		return aux;
	}

	public String obtenerNumFactura(){

		int noConsecutivo = 1;
		ResultSet resultadoperistencia =Consulta("SELECT Consecutivo FROM Persistencia WHERE Id_Persistencia = 2");

		try {
			while(resultadoperistencia.next()){

				noConsecutivo = noConsecutivo + resultadoperistencia.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}

		String aux="";
		if(noConsecutivo >9 && noConsecutivo <99)
			aux = "PA00" + noConsecutivo;  
		else if(noConsecutivo >99 && noConsecutivo <999)
			aux = "PA0" + noConsecutivo; 
		else if(noConsecutivo >999 && noConsecutivo <9999)
			aux = "PA" + noConsecutivo; 
		else
			aux = "PA000" + noConsecutivo;

		return aux;
	}

	//opereciones con cupos 

	public String ObtenerNivelCupo(String ClienteConsultado)
	{
		String nivelActual = "";
		int num =0;
		ResultSet resultado = Consulta("SELECT NivelCupo_Actual " +
				"FROM Cliente " +
				"WHERE No_Documento = '" + ClienteConsultado + "'");
		try {
			while(resultado.next())
				nivelActual =resultado.getString(1);
		} catch (SQLException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}

		if(!nivelActual.equals("NA")){
			num = Integer.parseInt(nivelActual.substring(4,7));
			num++;

			if(num >0 && num <10)
				nivelActual = "00"+num;
			else if(num >9 && num <100)
				nivelActual = "0"+num;
			else
				nivelActual = ""+num;
			return nivelActual;
		}
		return "000 000";
	}

	public void ActualizarNivelCupo(String nuevoCupo, String cliente)
	{
		ejecutar("UPDATE Cliente " +
				"SET NivelCupo_Actual = '" + nuevoCupo + "'" +
				"WHERE No_Documento = '" + cliente + "'");
	}

	public void ProponerRelacionConvenio_Cliente(String convenio, String cliente)
	{
		ejecutar("IF NOT EXISTS(SELECT * FROM Cliente_Con_Convenio " +
				"WHERE No_Convenio = '" + convenio + "' AND No_Documento = '" + cliente + "') " +
				"INSERT INTO Cliente_Con_Convenio " +
				"VALUES ('" + convenio + "', '" + cliente + "', 'PROPUESTO' , 'PROPUESTO')");
	}

	public void GuardarCupo(String convenio, String nombreCupo, String lineacreditoPro, String valorcupo, String nivelcupopro, String cliente)
	{
		ejecutar("INSERT INTO Cupo " +
				"VALUES('" + convenio + "', '" + nombreCupo + "', '" + 
				lineacreditoPro + "', " + valorcupo + ", '" + nivelcupopro + "', '" + 	
				cliente + "', 'CREADO', '')");

	}
	
	/**
	 * 
	 * @param cp
	 * @param trns
	 * @param resutE
	 * @param resutO
	 * @param veredict
	 * @param detall
	 * 
	 * Metodo de insercion en base de datos del caso de prueba ejecutado
	 */
	public void GenerarRegistroEjecucion(String cp, String trns, String resutE, String resutO, String veredict, String detall)
	{
		ejecutar("INSERT INTO ConsolidadosEjecucion " +
					"VALUES('FACTORING', '" + ObtenerAno() + "', '" + ObtenerMes() + "', '" + ObtenerFecha() +
					"', '" + ObtenerHora() + "', '" + cp + "', '" + trns + "', '" + resutE + "', '" + resutO +
					"', '" + veredict + "', '" + detall+ "')" );
	}
	
	public String Repositorio(){
		
		File folder = new File("\\\\W7SICE060\\Seguimiento ejecuci�n\\PROYECTOS\\PPE Factoring\\" + ObtenerMes() + "_" +ObtenerAno());
		
		if (!folder.exists())
			folder.mkdir();
			
		return folder.getName();
	}
	
	public void CopiarInforme(String nameFile){
		
		String origen = "D:\\PPE_Factoring\\Resultados Ejecucion\\" + nameFile + ".pdf";
		String destino = "\\\\W7SICE060\\Seguimiento ejecuci�n\\PROYECTOS\\PPE Factoring\\"+ Repositorio() + "\\" + nameFile + ".pdf";
		Path FROM = Paths.get(origen);
		Path TO = Paths.get(destino);
		
		
		//sobreescribir el fichero de destino, si existe, y copiar
		// los atributos, incluyendo los permisos rwx
		CopyOption[] options = new CopyOption[]{
			StandardCopyOption.REPLACE_EXISTING,
			StandardCopyOption.COPY_ATTRIBUTES
		}; 
		try {
			Files.copy(FROM, TO, options);
		} catch (IOException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
	}

}