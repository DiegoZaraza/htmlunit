package Autorizacion_Planes.Vista;
import resources.Autorizacion_Planes.Vista.Vista2_Aprobacion_DevolucionHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista2_Aprobacion_Devolucion extends Vista2_Aprobacion_DevolucionHelper
{
	String acccion;
	
	public String testMain(Object[] args) 
	{
		acccion = (String)args[0];
		
		if(acccion.equals("Autorizar"))
			button_autorizarbutton(ANY, LOADED).click();
		if(acccion.equals("Devolver")){
			
			button_devolverbutton(ANY, LOADED).click();
			text_observacion(ubicacion(2), DEFAULT).waitForExistence();
			text_observacion(ubicacion(2), DEFAULT).setText("PRUEBAS AUTOMATIZADAS");
			
			button_aceptarbutton(ubicacion(2), DEFAULT).click();
		}
					
		sleep(5);
		
		if(html_mesajeRespuestaDialog(ubicacion(1), DEFAULT).exists() && html_mesajeRespuestaDialog(ubicacion(1), DEFAULT).isShowing())
		{
			String resulCreacion="";
			resulCreacion = (String)html_mesajeRespuestaDialog().getProperty(".text");
			button_oKbutton(ubicacion(1), DEFAULT).click();sleep(5);
			
			teclado("{F5}");sleep(5);
			return resulCreacion;
		}
		
			return "Error NO pantalla emergente"; 
	}
	
	public void teclado(String tecla){
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else 
			return browser_htmlBrowser(document_crearPlanes(), DEFAULT);	
	}
}

