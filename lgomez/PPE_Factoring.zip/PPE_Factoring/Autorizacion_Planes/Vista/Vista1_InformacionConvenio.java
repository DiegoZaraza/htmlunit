package Autorizacion_Planes.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Autorizacion_Planes.Vista.Vista1_InformacionConvenioHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista1_InformacionConvenio extends Vista1_InformacionConvenioHelper
{
	String convenio, plan;
	TestObject[] radios;
	RenderedImage Imagen;
	
	public void testMain(Object[] args) throws IOException 
	{
		convenio = (String)args[0];
		plan = (String)args[1];
		
		if(link_autorizaci�nPlanes(ANY, LOADED).exists() && link_autorizaci�nPlanes(ANY, LOADED).isShowing())
		{
			link_autorizaci�nPlanes().click();
			sleep(4);
		}
		else
		{
			link_factoring().click();sleep(1);	
			link_planes().click();sleep(1);
			link_autorizaci�nPlanes().click();
		}
	 
		text_numeroConvenio(ubicacion(1), DEFAULT).waitForExistence();
		text_numeroConvenio(ANY,LOADED).setText(convenio);
		teclado("{TAB}");
		sleep(5);
		
		ITestDataTable orderTable = (ITestDataTable)table_planesConvenioTabla().getTestData("contents");
		
		for (int row=0; row < orderTable.getRowCount();row++){
			for (int col=1; col < orderTable.getColumnCount();col++){
				if(orderTable.getCell(row,col).toString().equals(plan)){
					radios = table_planesConvenioTabla().find(atDescendant(".class","Html.INPUT.radio"));
					new GuiTestObject(radios[row]).click();
				}
			}
		}
		
		button_siguientebutton().click();sleep(3);
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, plan + "_FormaDesembolso", "Autorizacion_Planes");
		teclado("{TAB}");sleep(1);
		teclado("{TAB}");sleep(1);
		teclado("{Enter}");
//		button_siguientebutton2(ubicacion(1), DEFAULT).click();sleep(3);
	}

public void recorrerLista(int cantidad){
	for(int i = 0; i<=cantidad; i++ )
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
}
public void teclado(String tecla){
	browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
}	
public TestObject ubicacion(int nivel){
	if(nivel==1)
		return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
	else 
		return browser_htmlBrowser(document_autorizarPlanes(), DEFAULT);	
}
	
}

