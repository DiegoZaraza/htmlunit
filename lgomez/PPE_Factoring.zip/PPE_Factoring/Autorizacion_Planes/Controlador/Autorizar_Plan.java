package Autorizacion_Planes.Controlador;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import resources.Autorizacion_Planes.Controlador.Autorizar_PlanHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Autorizar_Plan extends Autorizar_PlanHelper
{
	String convenio, plan, acccion, cadena;
	ArrayList<String> listaPlanes = new ArrayList<String>();
	ArrayList<String> listaConvenios = new ArrayList<String>();
	String[][] data;
	String[] dataVista1 = new String[2];
	String[] dataVista2 = new String[1];
	
	public void testMain(Object[] args) 
	{
		ConnecionDB();
		
		convenio = (String)args[0];
		plan = (String)args[1];
		acccion = (String)args[2];
		
		System.out.println("-*-*-*-*-*-*-* AUTORIZAR PLAN-*-*-*-*-*-*-*-*-*-*-*");
		for (Object object : args) {
			System.out.println(object);
		}
		System.out.println("-*-*-*-*-*-*-* AUTORIZAR PLAN-*-*-*-*-*-*-*-*-*-*-*");

		if(!plan.equals("Autorizar Todos") && !plan.equals("- Autorizar Todos -"))
			listaPlanes.add(plan);
		else if(plan.equals("Autorizar Todos")){
			
			ResultSet resultado2 = Consulta("SELECT No_Plan " +
					"FROM PlanFinanciero " +
						"WHERE Estado_Plan = 'CREADO' AND " +
						"No_Convenio = '" + convenio + "'");
			
			try {
				while(resultado2.next())
					listaPlanes.add(resultado2.getString(1));
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
		}
		else if(plan.equals("- Autorizar Todos -")){
			ResultSet resultado2 = Consulta("SELECT No_Plan, No_Convenio " +
					"FROM PlanFinanciero " +
					"WHERE Estado_Plan = 'CREADO' " +
					"AND No_Convenio IN (SELECT No_Convenio FROM Convenio WHERE Estado_convenio = 'CREADO/APROBADO')");
			
			try {
				while(resultado2.next()){
					listaPlanes.add(resultado2.getString(1));
					listaConvenios.add(resultado2.getString(2));
				}
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
		}
		
		if((boolean)callScript("Scripts.Login"))
			System.out.println("lOGIN");
		
		data = new String[listaPlanes.size()][4];
		
		for (int i = 0; i< listaPlanes.size(); i++) {
			
			if(plan.equals("- Autorizar Todos -"))
				convenio = listaConvenios.get(i);
			
			grabarArchivo("PLAN: " + listaPlanes.get(i) + " CONVENIO(" + convenio + ")" , "Autorizacion_Planes");
									
			//Vista1
			dataVista1[0] = convenio;
			dataVista1[1] = listaPlanes.get(i);
			callScript("Autorizacion_Planes.Vista.Vista1_InformacionConvenio", dataVista1);
			
			//Vista2
			dataVista2[0] = acccion;
			Object resulAuto = callScript("Autorizacion_Planes.Vista.Vista2_Aprobacion_Devolucion", dataVista2);
			cadena = (String)resulAuto;
			
			if(acccion.equals("Autorizar")){
				if(cadena.equals("La autorizaci�n de planes se realiz� correctamente"))
				{
					data[i][0]= listaPlanes.get(i); 
					data[i][1]= "La autorizaci�n de planes se realiz� correctamente";
					data[i][2]= cadena;
					data[i][3]= "Exitoso";
					
					ejecutar("UPDATE PlanFinanciero " +
							"SET Estado_Plan = 'CREADO/APROBADO' " +
								"WHERE No_Plan = '" + listaPlanes.get(i) + "'");
				}
				else
				{
					data[i][0]= listaPlanes.get(i); 
					data[i][1]= "La autorizaci�n de planes se realiz� correctamente";
					data[i][2]= cadena;
					data[i][3]= "Fallido";
				}
			}
			else
			{
				if(cadena.equals("Plan financiero devuelto correctamente"))
				{
					data[i][0]= listaPlanes.get(i); 
					data[i][1]= "Plan financiero devuelto correctamente";
					data[i][2]= cadena;
					data[i][3]= "Exitoso";
					
					ejecutar("UPDATE PlanFinanciero " +
							"SET Estado_Plan = 'DEVUELTO' " +
								"WHERE No_Plan = '" + listaPlanes.get(i) + "'");
				}
				else
				{
					data[i][0]= listaPlanes.get(i);
					data[i][1]= "Plan financiero devuelto correctamente";
					data[i][2]= cadena;
					data[i][3]= "Fallido";
				}
			}
		}
		createPdf("Autorizacion_Planes");
		createPdfInforme("INFORME AUTORIZACION PLANES", data);
	}
}

