package Creacion_Cupos.Controlador;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import resources.Creacion_Cupos.Controlador.Crear_CupoHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Crear_Cupo extends Crear_CupoHelper
{
	String[] listaLineaCredito;
	String[][] data;
	String[] dataVista1 = new String[4];
	String[] dataVista2 = new String[6];
	ArrayList<String> lista = new ArrayList<String>();
	ArrayList<String> cuposCreados = new ArrayList<String>();
	String tipoCupoProvi;
	boolean flujo = false;
	
	public void testMain(Object[] args) 
	{
		/*
		 * args[0] = Cupo Global
		 * args[1] = Cupo Factoring 
		 * args[2] = Cupo Especifico 
		 * args[3] = Linea Credito 
		 * args[4] = Documento de Identidad 
		 * args[5] = Tipo de Documento 
		 * args[6] = Convenio
		 */
		
		System.out.println("-*-*-*-*-**-*-*- CREAR CUPOS *-*-*-*-*-*-*-*-*");
		for (Object object : args) {
			System.out.println(object);
		}
		System.out.println("-*-*-*-*-**-*-*- CREAR CUPOS *-*-*-*-*-*-*-*-*");
		
		if(args.length > 1){
			if(args[6] == null)
				args[6] = "";
		}
		
		ConnecionDB();
		
		listaLineaCredito = new String[10];
		listaLineaCredito[0] = "26-Factoring sin Recurso";
		listaLineaCredito[1] = "27-Factoring con Recurso";
		listaLineaCredito[2] = "602-Convenios C variable hasta  60 meses";
		listaLineaCredito[3] = "603-Convenio CEMEX Cuota Unica";
		listaLineaCredito[4] = "605-Convenios C Fija hasta  60 meses";
		listaLineaCredito[5] = "612-Pago a Proveedores";
		listaLineaCredito[6] = "613-Pago a Proveedores con Financiaci�n";
		listaLineaCredito[7] = "614-Anticipo de Facturas";
		listaLineaCredito[8] = "615-Descuento Proveedores";
		listaLineaCredito[9] = "616-Financiancion a Compradores";
		
		//Si se cumple dicha condicion es porque viene de prueba de regresion y no de generacion de datos 
	
			if(args[0].equals("1")){
				args = new Object[7];
				args[0] = "100000000000";
				args[1] = "90000000000";
				args[2] = "2000000000";
				args[3] = "TODAS LA LINEAS DE CREDITO";
			
				ResultSet consulCliente = Consulta("SELECT Top 1 No_Documento, Tipo_Documento, NivelCupo_Actual " +
												"FROM Cliente " +
												"WHERE NivelCupo_Actual = 'NA' " +
												"ORDER BY No_Documento ASC ");
				
				ResultSet ultimoConvenio = Consulta("SELECT TOP 1 No_Convenio, Nombre_Convenio " +
						"FROM Convenio " + 
							"WHERE Estado_convenio = 'CREADO-APROBADO' " +
								"ORDER BY No_Convenio DESC");
			
				try {
					while(consulCliente.next()){
						args[4] = consulCliente.getString(1);
						args[5] = consulCliente.getString(2);
					}
					while(ultimoConvenio.next()){
						args[6] = ultimoConvenio.getString(1);
					}
				} catch (SQLException e) {
					// TODO Bloque catch generado autom�ticamente
					e.printStackTrace();
				}
				
				flujo = true;
			}		

		if(!(args[0].equals("2")) && !(args[0].equals("3")) && !(args[0].equals("4"))){
			
			if((boolean)callScript("Scripts.Login"))
				System.out.println("lOGIN");
			
			//capturaCupo("Cupo Factoring", "900000000", "603-Convenios CEMEX cuota �nica", "80850370", "CC", "");
			if(!args[0].equals("NA"))
				capturaCupo("CUPO GLOBAL", (String)args[0], (String)args[3], (String)args[4], (String)args[5], "");
			if(!args[1].equals("NA"))
				capturaCupo("CUPO FACTORING", (String)args[1], (String)args[3], (String)args[4], (String)args[5], "");
			if(!args[2].equals("NA")){
				if(args[3].equals("TODAS LA LINEAS DE CREDITO")){
					for (String linea : listaLineaCredito) {
						
						if(flujo==false){
							ResultSet resultadoConsulta = Consulta("SELECT TOP 1 No_Convenio " +
									"FROM Convenio " +
									"WHERE No_CP_Convenio " + 
									"IN (SELECT No_CP_Convenio FROM CasoPrueba_Convenios WHERE Linea_Credito LIKE '%" + linea.substring(0,3) + "%') " +
									"ORDER BY 1 DESC ");
							try {
								while(resultadoConsulta.next())
									args[6]=resultadoConsulta.getString(1);
							} catch (SQLException e) {
								// TODO Bloque catch generado autom�ticamente
								e.printStackTrace();
							}	
						}
		
						capturaCupo("CUPO ESPECIFICO", (String)args[2], linea, (String)args[4], (String)args[5], (String)args[6]);
					}
				}
				else
					capturaCupo("CUPO ESPECIFICO", (String)args[2], (String)args[3], (String)args[4], (String)args[5], (String)args[6]);
			}
			
			//PEQUE�O CODIGO QUE PASA LO QUE TIENE LA LISTA A UN ARREGLO BIDIMENCIONAL
			data = new String[lista.size()/4][4];
			int aux = 0;
			int aux2 = 0;
			for(int i = 0; i<lista.size(); i++){
				data[aux][aux2] = lista.get(i);
					aux2++;
					if(aux2==4){	
						aux2=0;
						aux++;
					}
			}
			createPdf("Creacion_Cupos");
			createPdfInforme("INFORME CREACION CUPOS", data);
			
			if(flujo==true){
				cuposCreados.add((String)args[4]);
				cuposCreados.add("Autorizar");
				String[] cuposfinal = new String[cuposCreados.size()];
				for(int i = 0; i<cuposCreados.size(); i++){
					cuposfinal[i] = cuposCreados.get(i);
				}
				callScript("Autorizacion_Cupo.Controlador.Autorizar_Cupo", cuposfinal);
			}
		}	
	}
	
	public void capturaCupo(String tipoCupo, String valorCupo, String lineaCredito, String numeroId, String tipoDocumento, String convenio){

		
		grabarArchivo("CREACION DE CUPOS ", "Creacion_Cupos");
		grabarArchivo("Tipo de Cupo: " + tipoCupo, "Creacion_Cupos");
		grabarArchivo("Valor del Cupo: " + valorCupo.substring(0,valorCupo.length()-2), "Creacion_Cupos");
		grabarArchivo("Linea de Cr�dito: " + lineaCredito, "Creacion_Cupos");
		grabarArchivo("Tipo de Documento: " + tipoDocumento, "Creacion_Cupos");
		grabarArchivo("Numero Documento: " + numeroId, "Creacion_Cupos");
		grabarArchivo("Convenio: " + convenio, "Creacion_Cupos");
	
		//Vista1
		dataVista1[0] = tipoDocumento;
		dataVista1[1] = numeroId;
		dataVista1[2] = tipoCupo;
		dataVista1[3] = lineaCredito;
		Object resultado = callScript("Creacion_Cupos.Vista.Vista1_DatosPrincipales", dataVista1);
		
		String cadena =(String)resultado;
		
		if(cadena.equals("Reportado") || cadena.equals("NoExiste")){
			ejecutar("DELETE FROM Cliente WHERE No_Documento = '" + numeroId + "'");
			String[] reinicio = new String[1];
			reinicio[0] = "1";
			testMain(reinicio);
		}
		
		//Vista2
		dataVista2[0] = tipoCupo;
		dataVista2[1] = lineaCredito;
		dataVista2[2] = ObtenerNivelCupo(numeroId);
		dataVista2[3] = ObtenerFechaVencimientoCupo();
		dataVista2[4] = convenio;
		dataVista2[5] = valorCupo;
		Object resultado2 = callScript("Creacion_Cupos.Vista.Vista2_DatosCupo", dataVista2);
		
		String cadena2 =(String)resultado2;
		
		if(tipoCupo.equals("CUPO ESPECIFICO"))
			tipoCupoProvi = tipoCupo + "_" + lineaCredito;
		else
			tipoCupoProvi = tipoCupo;
		
		if(cadena2.equals("Cupo creado correctamente, pendiente de autorizar"))
		{
			lista.add(tipoCupoProvi);
			lista.add("Cupo creado correctamente, pendiente de autorizar");
			lista.add(cadena2);
			lista.add("Exitoso");
			
			if(tipoCupo.equals("CUPO GLOBAL")){
				ActualizarNivelCupo("000 000", numeroId);
				cuposCreados.add("000 000");
				GuardarCupo("NA", tipoCupo, "NA", valorCupo.substring(0,valorCupo.length()-2), "000 000", numeroId);
			}
			else if(tipoCupo.equals("CUPO FACTORING")){
				ActualizarNivelCupo("001 000", numeroId);
				cuposCreados.add("001 000");
				GuardarCupo("NA", tipoCupo, "NA", valorCupo.substring(0,valorCupo.length()-2), "001 000", numeroId);
			}
			else
			{
				GuardarCupo(convenio, tipoCupo, lineaCredito, valorCupo.substring(0,valorCupo.length()-2), "001 " + ObtenerNivelCupo(numeroId), numeroId);
				ActualizarNivelCupo("001 " + ObtenerNivelCupo(numeroId), numeroId);
				cuposCreados.add("001 " + ObtenerNivelCupo(numeroId));
				ProponerRelacionConvenio_Cliente(convenio, numeroId);
			}
		
		}
		else
		{
			lista.add(tipoCupoProvi);
			lista.add("Cupo creado correctamente, pendiente de autorizar");
			lista.add(cadena2);
			lista.add("Fallido");
		}
		
	}	
	
}

