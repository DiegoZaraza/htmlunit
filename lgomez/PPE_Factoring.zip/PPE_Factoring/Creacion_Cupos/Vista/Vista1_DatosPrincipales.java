package Creacion_Cupos.Vista;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.io.IOException;

import resources.Creacion_Cupos.Vista.Vista1_DatosPrincipalesHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista1_DatosPrincipales extends Vista1_DatosPrincipalesHelper
{
	String tipoDocumento, numeroId, tipoCupo, lineaCredito;
	RenderedImage Imagen;
	
	public String testMain(Object[] args) throws IOException 
	{
		tipoDocumento = (String)args[0];
		numeroId = (String)args[1];
		tipoCupo = (String)args[2];
		lineaCredito = (String)args[3];
		
		if(link_capturaCupo(ANY, LOADED).exists() && link_capturaCupo(ANY, LOADED).isShowing())
		{
			link_capturaCupo().click();
		}
		else
		{
			link_factoring().click();sleep(1);	
			link_cupo().click();sleep(1);
			link_capturaCupo().click();sleep(3);
		}
		
		list_tipoIdentificacion(ubicacion(1), DEFAULT).waitForExistence();
		list_tipoIdentificacion().click();sleep(2);
	
		System.out.println(tipoDocumento);
		switch (tipoDocumento) {
		case "CC":
			recorrerLista(0);
			break;
		case "NPJ":
			recorrerLista(1);
			break;
		case "CE":
			recorrerLista(2);
			break;
		case "NE":
			recorrerLista(3);
			break;
		case "NPN":
			recorrerLista(4);
			break;
		case "PAS":
			recorrerLista(5);
			break;
		case "RC":
			recorrerLista(6);
			break;
		case "TI":
			recorrerLista(7);
			break;
		case "PA":
			recorrerLista(8);
			break;
		case "NIT":
			recorrerLista(1);
			break;
		default:
			break;
		}
		sleep(2);	
		teclado("{TAB}");
		text_numeroIdentificacion(ubicacion(1),DEFAULT).setText(numeroId);
		teclado("{TAB}");sleep(5);
		
		if(button_oKbutton(ANY, LOADED).exists() && button_oKbutton(ANY, LOADED).isShowing())
		{
			System.out.println("Entrando");
			String resulCreacion="";
			resulCreacion = (String)html_mesajeRespuestaDialog(ANY, LOADED).getProperty(".text");
			if(resulCreacion.equals("Error consultando cliente en CRMError : El cliente no existe"))
			{
				Imagen = html_mesajeRespuestaDialog(ANY, LOADED).getScreenSnapshot();
				guardarImagen(Imagen, "ProblemasCliente", "Creacion_Cupos");
				button_oKbutton(ubicacion(2),DEFAULT).click();
				teclado("{F5}");sleep(5);
				return "NoExiste";
			}
				
			if(resulCreacion.equals("No se encotr� ningun centro de costos asociado al cliente"))
			{	
				Imagen = html_mesajeRespuestaDialog(ANY, LOADED).getScreenSnapshot();
				guardarImagen(Imagen, "ProblemasCliente", "Creacion_Cupos");
				button_oKbutton(ANY, LOADED).click();
				text_digiteElCentroDeCostos(ANY, LOADED).click();
				teclado("{Num2}");sleep(2);
				recorrerLista(GetRandom1_10());
				teclado("{TAB}");
			}
			if(resulCreacion.equals("Cliente Reportado, consultar con la DUCC"))
			{
				Imagen = html_mesajeRespuestaDialog(ANY, LOADED).getScreenSnapshot();
				guardarImagen(Imagen, "ProblemasCliente", "Creacion_Cupos");
				button_oKbutton(ANY, LOADED).click();
				teclado("{F5}");sleep(5);
				return "Reportado";
			}
		}
		else
			teclado("{TAB}{TAB}");
		
		if(tipoCupo.equals("CUPO GLOBAL"))
			recorrerLista(0);
		if(tipoCupo.equals("CUPO FACTORING"))
			recorrerLista(1);
		if(tipoCupo.equals("CUPO ESPECIFICO"))
			recorrerLista(2);
		
		teclado("{TAB}");
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, tipoCupo + "_" + lineaCredito, "Creacion_Cupos");
		teclado("{ENTER}");
		
		return "Ok";
	}
	
	public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else
			return browser_htmlBrowser(document_capturaCupo(), DEFAULT);
			
	}
}

