package Creacion_Cupos.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Creacion_Cupos.Vista.Vista2_DatosCupoHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista2_DatosCupo extends Vista2_DatosCupoHelper
{
	RenderedImage Imagen;
	String tipoCupo, lineaCredito, nivelCupo, fechaVencimiento, convenio, valorCupo;
	
	public String testMain(Object[] args) throws IOException {
			
		tipoCupo = (String)args[0];
		lineaCredito = (String)args[1];
		nivelCupo = (String)args[2];
		fechaVencimiento = (String)args[3];
		convenio = (String)args[4];
		valorCupo = (String)args[5];
		
		if(tipoCupo.equals("CUPO ESPECIFICO")){
			
			text_lineaCredito(ANY, LOADED).setText(lineaCredito);sleep(2);
			recorrerLista(0);
			teclado("{TAB}");			
			text_codigoNivel(ANY, LOADED).setText(nivelCupo);
			text_fechaVencimiento(ANY, LOADED).setText(fechaVencimiento);
			teclado("{TAB}");sleep(2);
			text_numeroConvenio(ANY, LOADED).setText(convenio);
			text_montoCupo(ANY, LOADED).setText(valorCupo);
		}
		else
		{
			text_fechaVencimiento(ANY, LOADED).setText(fechaVencimiento);
			teclado("{TAB}");	
			text_montoCupo(ANY, LOADED).setText(valorCupo);
		}
		
		teclado("{TAB}{TAB}");
				
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, tipoCupo + "_" + lineaCredito + "2", "Creacion_Cupos");
		teclado("{ENTER}");
		sleep(2);
		
		if(html_mesajeRespuestaDialog(ubicacion(1),DEFAULT).exists() && html_mesajeRespuestaDialog(ubicacion(1), DEFAULT).isShowing())
		{
			String resulCreacion2="";
			
			resulCreacion2 = (String)html_mesajeRespuestaDialog(ubicacion(1),DEFAULT).getProperty(".text");
			
			Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
			guardarImagen(Imagen, tipoCupo + "_" + lineaCredito + "2", "Creacion_Cupos");
			button_oKbutton(ubicacion(1), DEFAULT).click();sleep(5);
			teclado("{F5}");sleep(5);
			return resulCreacion2;
		}
		
		return "Error NO pantalla emergente";
		
	}
	
	public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else
			return browser_htmlBrowser(document_capturaCupo(), DEFAULT);
			
	}
}

