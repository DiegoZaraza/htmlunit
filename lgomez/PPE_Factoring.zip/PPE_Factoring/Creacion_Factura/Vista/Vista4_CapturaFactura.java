package Creacion_Factura.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Creacion_Factura.Vista.Vista4_CapturaFacturaHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista4_CapturaFactura extends Vista4_CapturaFacturaHelper
{
	String no_Factura, valorFactura, fechaExpedicion, tipoTasa_DSCTO, tipoTasa_Financiacion;
	String tipoPLazo_DSCTO, tipoPLazoFinanciacion, modoTasa_Financiacion, condicionTasa_DSCTO, no;
	RenderedImage Imagen;
	String tasaFinanciacion;
	
	public void testMain(Object[] args) throws IOException 
	{
		no_Factura = (String)args[0];
		valorFactura = (String)args[1];
		fechaExpedicion = (String)args[2];
		tipoTasa_DSCTO = (String)args[3];
		tipoTasa_Financiacion = (String)args[4];
		tipoPLazo_DSCTO = (String)args[5];
		tipoPLazoFinanciacion = (String)args[6];
		modoTasa_Financiacion = (String)args[7];
		condicionTasa_DSCTO = (String)args[8];
		no = (String)args[9];
		tasaFinanciacion = (String)args[10];
		
		System.out.println("------------------------------------------------------------");
		System.out.println("tipoTasa_DSCTO: " + tipoTasa_DSCTO );
		System.out.println("tipoTasa_Financiacion: " + tipoTasa_Financiacion);
		System.out.println("tipoPLazo_DSCTO: " + tipoPLazo_DSCTO );
		System.out.println("tipoPLazoFinanciacion: " + tipoPLazoFinanciacion);
		System.out.println("------------------------------------------------------------");
		
		text_numeroFactura().click();
		text_numeroFactura().setText(no_Factura);
		teclado("{TAB}");
		text_valorFactura().setText(valorFactura);
		teclado("{TAB}");
		while(text_fechaFactura().getText().length()<8)
			text_fechaFactura().setText(fechaExpedicion);sleep(1);

		teclado("{TAB}");
		if(no.equals("1"))
			teclado("{TAB}");
		
		if(tipoTasa_DSCTO.equals("Variable")){
			
			if(condicionTasa_DSCTO.equals("Modificable"))
			{
				text_tasaDescue().setText("3.3");
				teclado("{TAB}");
			}
			if(modoTasa_Financiacion.equals("Modificable"))
			{
				text_tasaFinan().setText("3.3");
				teclado("{TAB}");
			}

		}
		if(tipoPLazo_DSCTO.equals("Abierto")){
			
			text_fechaFinDes().setText(fechaExpedicion);
			teclado("{TAB}");
			text_diasAdiDes().setText("15");
			teclado("{TAB}");
			
			if(condicionTasa_DSCTO.equals("Modificable"))
			{
				text_tasaDescue().setText("3.3");
				teclado("{TAB}");
			}
			if(modoTasa_Financiacion.equals("Modificable"))
			{
				text_tasaFinan().setText("3.3");
				teclado("{TAB}");
			}
		
		}
		
		if(tipoPLazo_DSCTO.equals("Fijo")){
			if (text_tasaDescue().isEnabled())
				text_tasaDescue().setText("2");
		}
		
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, "CapturaFactura_" + no, "Creacion_Factura");
		
		
		teclado("{TAB}");
		button_siguientebutton().click();
	}
	
	public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else
			return browser_htmlBrowser(document_facturas(), DEFAULT);
			
	}
}

