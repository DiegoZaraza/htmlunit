package Creacion_Factura.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Creacion_Factura.Vista.Vista1_InfromacionConvenioHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista1_InfromacionConvenio extends Vista1_InfromacionConvenioHelper
{
	String no_convenio;
	RenderedImage Imagen;
	
	public void testMain(Object[] args) throws IOException 
	{
		no_convenio = (String)args[0];
		
		if(link_facturas2(ANY, LOADED).exists() && link_facturas2(ANY, LOADED).isShowing())
		{
			link_facturas2().click();
		}
		else
		{
			link_factoring().click();sleep(1);	
			link_facturas().click();sleep(1);
			link_facturas2().click();sleep(3);
		}
		
		text_numeroConvenio().click();
		text_numeroConvenio().setText(no_convenio);
		teclado("{TAB}{TAB}");
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, "No_Convenio_" + no_convenio, "Creacion_Factura");
		teclado("{ENTER}");
	}
	
	public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else
			return browser_htmlBrowser(document_facturas(), DEFAULT);
			
	}
}

