package Creacion_Factura.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Creacion_Factura.Vista.Vista6_InformacionDesembolsoHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista6_InformacionDesembolso extends Vista6_InformacionDesembolsoHelper
{
	//Varible que nos indica si tiene o no cobro del 4 por 1000
	boolean gmf = false;
	String nivelCupoAfectar;
	int cantidadFacturas;
	RenderedImage Imagen;
	
	public String testMain(Object[] args) throws IOException 
	{
		
		for (Object object : args) {
			System.out.println(object);
		}
		nivelCupoAfectar = (String)args[0];
		cantidadFacturas = Integer.parseInt((String)args[1]);
		
		list_cobroGMFselect().click();
		if(gmf==false)
			recorrerLista(1);
		else
			recorrerLista(0);
		
		teclado("{TAB}");
		text_nivelCupoInput().setText(nivelCupoAfectar);
		button_guardarbutton().click();
		sleep(3);	
		
		if(html_mesajeRespuestaDialog(ANY, LOADED).exists() && html_mesajeRespuestaDialog(ANY, LOADED).isShowing())
		{
			Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
			guardarImagen(Imagen, "Informacion Desembolso", "Creacion_Factura");
			String respuesta = (String)html_mesajeRespuestaDialog(ubicacion(2), DEFAULT).getProperty(".text");
			
		
			
			if(cantidadFacturas > 1){
				button_sIbutton().click();
				sleep(2);
			}
				
			else{
				button_nObutton().click();
				teclado("{F5}");sleep(2);	
			}
				
			return respuesta;
		}
		
		return "No genero respuesta";
	}
	
	public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else
			return browser_htmlBrowser(document_facturas(), DEFAULT);
			
	}
}

