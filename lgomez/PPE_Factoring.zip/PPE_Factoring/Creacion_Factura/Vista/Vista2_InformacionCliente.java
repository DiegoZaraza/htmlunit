package Creacion_Factura.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Creacion_Factura.Vista.Vista2_InformacionClienteHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista2_InformacionCliente extends Vista2_InformacionClienteHelper
{
	String tipoDocumento, no_Documento;
	RenderedImage Imagen;
	
	public boolean testMain(Object[] args) throws IOException 
	{
		tipoDocumento = (String)args[0];
		no_Documento = (String)args[1];
		
		list_tipoIdentificacion().click();
		
		if(tipoDocumento.equals("CC"))
			recorrerLista(0);
		else
			recorrerLista(1);
		
		teclado("{TAB}");
		text_numeroIdentificacion().setText(no_Documento);
		teclado("{TAB}");
		
		if(button_oKbutton(ANY, LOADED).exists() && button_oKbutton(ANY, LOADED).isShowing())
		{
			Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
			guardarImagen(Imagen, "No_Documento_" + no_Documento, "Creacion_Factura");
			
			return true;
		}
		
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, "No_Documento_" + no_Documento, "Creacion_Factura");
		teclado("{TAB}{TAB}");
		teclado("{ENTER}");
		
		return false;
		
	}
	
	public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else
			return browser_htmlBrowser(document_facturas(), DEFAULT);
			
	}
	
}

