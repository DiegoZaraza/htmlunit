package Creacion_Factura.Vista;
import resources.Creacion_Factura.Vista.Vista3_InformacionPlanHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista3_InformacionPlan extends Vista3_InformacionPlanHelper
{
	String no_Plan;
	
	public void testMain(Object[] args) 
	{
		no_Plan = (String)args[0];
		
		text_htmlINPUTText(ubicacion(1), DEFAULT).click();
		text_htmlINPUTText().setText(no_Plan);
		radioButton_seleccionados14046(ubicacion(1), DEFAULT).click();
		button_siguientebutton().click();sleep(1);
		radioButton_cargaFacturason().click();
		
	}
	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else
			return browser_htmlBrowser(document_facturas(), DEFAULT);
			
	}
}

