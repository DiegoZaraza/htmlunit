package Creacion_Factura.Vista;
import resources.Creacion_Factura.Vista.Vista5_GarantiasHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista5_Garantias extends Vista5_GarantiasHelper
{	
	public void testMain(Object[] args) 
	{
		list_garantiaJsp().click();
		recorrerLista(1);
		teclado("{TAB}");
		recorrerLista(1);
		teclado("{TAB}{TAB}");
		teclado("{ENTER}");
		button_aceptaRbutton().click();
		
	}
	
	public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else
			return browser_htmlBrowser(document_facturas(), DEFAULT);
			
	}
}

