package Creacion_Factura.Controlador;
import java.sql.ResultSet;
import java.sql.SQLException;

import resources.Creacion_Factura.Controlador.Crear_FacturaHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Crear_Factura extends Crear_FacturaHelper
{
	String no_convenio, no_Documento, no_Plan, no_Asociacion, tipoDocumento; 
	String inicial, no_Factura, tasaFinanciacion, finals ;
	int cantidad;
	boolean flujo = true;
	ResultSet resultadoAsoci;
	String[] dataVista1 = new String[1];
	String[] dataVista2 = new String[2];
	String[] dataVista3 = new String[1];
	String[] dataVista4 = new String[11];
	String[] dataVista6 = new String[2];
	String[] dataAutorizar = new String[2];
	String[][] data;
	String valorFactura = "375000";
	String gmf = "NO";
	String[] listaLineaCredito;
	
	public void testMain(Object[] args) 
	{
		ConnecionDB();
		
		/*
		 * args[0] = Convenio 
		 * args[1] = Cantidad de facturas
		 */
		System.out.println("-*-*-*-**-*-* crear Factura *-*-*-*-*-*-*-*");
		for (Object object : args) {
			System.out.println(object); 
		}
		System.out.println("-*-*-*-**-*-* crear Factura *-*-*-*-*-*-*-*");
		
		listaLineaCredito = new String[10];
		listaLineaCredito[0] = "26-Factoring sin recurso";
		listaLineaCredito[1] = "27-Factoring con recurso";
		listaLineaCredito[2] = "602-Convenios C variable hasta 60 meses";
		listaLineaCredito[3] = "603-Convenio CEMEX Cuota Unica";
		listaLineaCredito[4] = "605-Convenios C Fija hasta  60 meses";
		listaLineaCredito[5] = "612-Pago a proveedores";
		listaLineaCredito[6] = "613-Pago a proveedores con financiaci�n";
		listaLineaCredito[7] = "614-Anticipo de Facturas";
		listaLineaCredito[8] = "615-Descuento Proveedores";
		listaLineaCredito[9] = "616-Financiancion a Compradores";
		
		if(args[0] != null && args.length>1)
		{
			flujo = false;
			if(args[0].equals("Crear factura a todos")){
				
				resultadoAsoci =Consulta(" SELECT No_Convenio, Cliente_Con_Convenio.No_Documento, No_Plan, Id_Asociacion, Tipo_Documento "+ 
				           	"FROM Cliente_Con_Convenio INNER JOIN Cliente " +
				           	"ON Estado = 'ASOCIADO' AND Id_Asociacion Not IN(SELECT Id_Asociacion FROM Factura) "+
				           	"AND Cliente.No_Documento IN (SELECT No_Documento FROM Cliente_Con_Convenio  WHERE Estado = 'ASOCIADO')"); 
			}
			else{
				resultadoAsoci = Consulta("SELECT No_Convenio, Cliente_Con_Convenio.No_Documento, No_Plan, Id_Asociacion, Tipo_Documento "+ 
						"FROM Cliente_Con_Convenio INNER JOIN Cliente " + 
						"ON No_Convenio = '" + args[0] +"' AND Estado = 'ASOCIADO' AND Id_Asociacion Not IN(SELECT Id_Asociacion FROM Factura) "+
						"AND Cliente.No_Documento IN (SELECT No_Documento FROM Cliente_Con_Convenio  WHERE Estado = 'ASOCIADO')");
						
				System.out.println("-*-*-*-*-*-*-*-*");
				System.out.println("SELECT No_Convenio, Cliente_Con_Convenio.No_Documento, No_Plan, Id_Asociacion, Tipo_Documento "+
									"FROM Cliente_Con_Convenio INNER JOIN Cliente " + 
									"ON No_Convenio = '" + args[0] +"' AND Estado = 'ASOCIADO' AND Id_Asociacion Not IN(SELECT Id_Asociacion FROM Factura) "+
									"AND Cliente.No_Documento IN (SELECT No_Documento FROM Cliente_Con_Convenio  WHERE Estado = 'ASOCIADO')");
			}
						
			inicial = (String)args[1];
			finals = "";
			for (int x=0; x < inicial.length(); x++) {
				  if (inicial.charAt(x) != ' ')
				    finals += inicial.charAt(x);
				}
			System.out.println(finals);
			cantidad = Integer.parseInt(finals);
		}
		else
		{
			cantidad=10;

			resultadoAsoci = Consulta("SELECT TOP 1 No_Convenio, Cliente_Con_Convenio.No_Documento, No_Plan, Id_Asociacion, Tipo_Documento " +
										"FROM Cliente_Con_Convenio INNER JOIN Cliente " +
										"ON Estado = 'ASOCIADO' AND Id_Asociacion Not IN(SELECT Id_Asociacion FROM Factura)");
			
			System.out.println("SELECT TOP 1 No_Convenio, Cliente_Con_Convenio.No_Documento, No_Plan, Id_Asociacion, Tipo_Documento " +
										"FROM Cliente_Con_Convenio INNER JOIN Cliente " +
										"ON Estado = 'ASOCIADO' AND Id_Asociacion Not IN(SELECT Id_Asociacion FROM Factura)");
		}
		
		try {
			while(resultadoAsoci.next()){
				
				no_convenio = resultadoAsoci.getString(1);
				no_Documento = resultadoAsoci.getString(2);
				no_Plan = resultadoAsoci.getString(3);
				no_Asociacion = resultadoAsoci.getString(4);
				tipoDocumento = resultadoAsoci.getString(5);
				
				grabarArchivo("CREACION FACTURAS ", "Creacion_Factura");
				grabarArchivo("No_Convenio_" + no_convenio, "Creacion_Factura");
				grabarArchivo("No_Documento_" + no_Documento, "Creacion_Factura");
				grabarArchivo("No_Plan_" + no_Plan, "Creacion_Factura");
				
				if((boolean)callScript("Scripts.Login"))
					System.out.println("lOGIN");
				
				//Vista1
				dataVista1[0] = no_convenio;
				callScript("Creacion_Factura.Vista.Vista1_InfromacionConvenio", dataVista1);
				
				//Vista2
				dataVista2[0] = tipoDocumento;
				dataVista2[1] = no_Documento;
				//Condicional que identifica si no existe relacion entre el cliente y el convenio, error  que terminaria la ejecucion
				if((boolean)callScript("Creacion_Factura.Vista.Vista2_InformacionCliente", dataVista2))
				{
					ejecutar("UPDATE Cliente_Con_Convenio " +
		                      "SET Estado = 'ERROR-ASOCIACION' " +
		                      "WHERE Id_Asociacion = " + no_Asociacion);
					
					data = new String[1][4];
					data[0][0]= "CP_Asociacion";
					data[0][1]= "Creacion de Facturas" ;
					data[0][2]= "Error en Asoaciacion Cliente Covenio";
					data[0][3]= "Fallido";  
				}
				else
				{
					data = new String[cantidad][4];
					//Vista3
					dataVista3[0] = no_Plan;
					callScript("Creacion_Factura.Vista.Vista3_InformacionPlan", dataVista3);
					
					//Vista4
					dataVista4[1] = valorFactura;
					dataVista4[2] = ObtenerFecha();
					
					ResultSet resulTipoPlan = Consulta(" SELECT TipoTasa_DSCTO, TipoTasa_Financiacion, TipoPLazo_DSCTO, TipoPLazoFinanciacion, ModoTasa_Financiacion, CondicionTasa_DSCTO " +
														"FROM CasoPrueba_Plan " + 
														"WHERE No_CP_Plan = (SELECT No_CP_Plan FROM PlanFinanciero WHERE No_Plan = " + no_Plan + ")");
					
					try {
						while(resulTipoPlan.next()){
							dataVista4[3] = resulTipoPlan.getString(1);
							dataVista4[4] = resulTipoPlan.getString(2);
							dataVista4[5] = resulTipoPlan.getString(3);
							dataVista4[6] = resulTipoPlan.getString(4);
							dataVista4[7] = resulTipoPlan.getString(5);
							dataVista4[8] = resulTipoPlan.getString(6);
						}
					} catch (SQLException e) {
						// TODO Bloque catch generado autom�ticamente
						e.printStackTrace();
					}
					
					if(dataVista4[3].equals("Fija"))
						dataVista4[10] = "10.3";
					else
						dataVista4[10] = "3.3";
					
					//For que nos va crear 10 Facturas 
					for (int i = 1; i < cantidad+1; i++) {
						dataVista4[0] = obtenerNumFactura();
						dataVista4[9] = ""+i;
						callScript("Creacion_Factura.Vista.Vista4_CapturaFactura", dataVista4);
						
						//Vista5
						callScript("Creacion_Factura.Vista.Vista5_Garantias");
						
						//Vista6
						ResultSet resulLineaCredito = Consulta("SELECT Linea_Credito " +
								"FROM CasoPrueba_Convenios "+
								"WHERE No_CP_Convenio = (SELECT No_CP_Convenio FROM Convenio WHERE No_Convenio = '" + no_convenio + "')");
						
						while (resulLineaCredito.next())
							for(int j = 0; j < listaLineaCredito.length; j++){
								
								System.out.println("-------*--------*--------*---------");
								System.out.println(listaLineaCredito[j] + " - " + resulLineaCredito.getString(1) + " - " + (j+1));
								if(listaLineaCredito[j].equals(""+resulLineaCredito.getString(1))){
									
									System.out.println("*/*/*-/*");
									System.out.println(listaLineaCredito[j] + " - " + resulLineaCredito.getString(1) + " - " + j+1);
									if(j>99)
										dataVista6[0] = ""+(j+1);
									else if(j>9)
										dataVista6[0] = "0"+(j+1);
									else
										dataVista6[0] = "00"+(j+1);
								}
							}
						dataVista6[1] = ""+cantidad;
						Object resulCreacion = callScript("Creacion_Factura.Vista.Vista6_InformacionDesembolso", dataVista6);
						
						
						String cadena = (String) resulCreacion;
						
						if(cadena.substring(0, 28).equals("Factura creada correctamente"))
						{
							ejecutar("UPDATE Persistencia " +
								"SET Consecutivo = Consecutivo + 1" + 
								"WHERE  Id_Persistencia = 2");
							
							ejecutar("INSERT INTO Factura " + 
										"VALUES ('" + dataVista4[0] + "', 'NA', 'CREADA', " + no_Asociacion + ")");
												
							ejecutar("UPDATE Cliente_Con_Convenio " +
										"SET Estado = 'ASOCIADO/CON_FACTURA' " +
										"WHERE Id_Asociacion = " + no_Asociacion);
							
							data[i-1][0]= dataVista4[0];
							data[i-1][1]= "Factura creada correctamente" ;
							data[i-1][2]= cadena;
							data[i-1][3]= "Exitoso";

						}
						else
						{
							data[i-1][0]= dataVista4[0];
							data[i-1][1]= "Factura creada correctamente" ;
							data[i-1][2]= cadena;
							data[i-1][3]= "Fallido";
						}
					}
					callScript("Scripts.Refrescar");
				}
			}
		} catch (SQLException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
		createPdf("Creacion_Factura");
		createPdfInforme("INFORME CREACION FACTURAS", data);
		
		dataAutorizar = new String[1];
		dataAutorizar[0] = ""+flujo;
		callScript("Autorizacion_MasivaFacturas.Controlador.Autorizar_Masiva", dataAutorizar);

	}
	
}

