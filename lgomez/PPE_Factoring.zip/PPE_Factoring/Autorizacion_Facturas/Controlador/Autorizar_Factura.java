package Autorizacion_Facturas.Controlador;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import resources.Autorizacion_Facturas.Controlador.Autorizar_FacturaHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
//import com.sun.org.apache.xml.internal.utils.ObjectStack;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Autorizar_Factura extends Autorizar_FacturaHelper
{
	String[] dataVista1 = new String[1];
	String[] dataVista2 = new String[2];
	String[][] data;
	ArrayList<String> listaFacturas = new ArrayList<String>();
	
	public void testMain(Object[] args) 
	{
		/*
		 * args[0] = Id_relacion
		 * args[1] = Accion (Aprobado o Devuelto).
		 */
		
		//Cuando se requiere Autorizar sin autoMasiva 
//		args = new Object[2];		
//		args[0] = "1060";
//		args[1] = "Aprobado";
		
		System.out.println("-*-*-*-**-*-* Auto Factura *-*-*-*-*-*-*-*");
		for (Object object : args) {
			System.out.println(object); 
		}
		System.out.println("-*-*-*-**-*-* Auto Factura *-*-*-*-*-*-*-*");
		
		ConnecionDB();
		grabarArchivo("AUTORIZAR FACTURAS" , "Autorizacion_Factura");
		if((boolean)callScript("Scripts.Login"))
			System.out.println("lOGIN");	
		
		ResultSet consultaFacturas = Consulta("SELECT No_Factura " +
												"FROM Factura " +
												"WHERE Estado_Factura = 'CREADA' AND Id_Asociacion = " + args[0]);
		
		System.out.println("SELECT No_Factura " +
												"FROM Factura " +
												"WHERE Estado_Factura = 'CREADA' AND Id_Asociacion = " + args[0]);
		try {
			while(consultaFacturas.next()){
				
				listaFacturas.add(consultaFacturas.getString(1));
			}
		} catch (SQLException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
		
		data = new String[listaFacturas.size()][4];
		for (int i = 0; i<listaFacturas.size(); i++) {
			AutoFactura(listaFacturas.get(i), (String)args[1], i);
		}
		
		createPdf("Autorizacion_Factura");
		createPdfInforme("INFORME AUTORIZACION FACTURAS", data);
	}
	
	public void AutoFactura(String no_Factura, String accion, int num){
		
		//Vista1
		dataVista1[0] = no_Factura;
		if((boolean)callScript("Autorizacion_Facturas.Vista.Vista1_AutorizacionFacturas", dataVista1)){
			
			//Vista2
			dataVista2[0] = accion;
			dataVista2[1] = no_Factura;
			
			Object resultadoAutorizacion = callScript("Autorizacion_Facturas.Vista.Vista2_AprobacionDevolucionFacturas", dataVista2);
			String cadena = (String)resultadoAutorizacion;
			
			//prueba escritorio
			System.out.println("******-*******");
			System.out.println(cadena);
			//*******
			if(cadena.substring(0,30).equals("Factura aprobada correctamente"))
			{
				data[num][0]= "Autorizacion Factura: " + no_Factura ;
				data[num][1]= "Facturas aprobada correctamente...";
				data[num][2]= cadena;
				data[num][3]= "Exitoso";
				
				ejecutar("UPDATE Factura " +
							"SET Estado_Factura = 'AUTORIZADA' " +
							"WHERE No_Factura = '" + no_Factura +"'");
								
				ejecutar("UPDATE Factura " +
							"SET No_Credito = '" + cadena.substring(65,79) +"' " +
							"WHERE No_Factura = '" + no_Factura +"'");
				
			}
			else
			{
				data[num][0]= "Autorizacion Factura: " + no_Factura ;
				data[num][1]= "Facturas aprobada correctamente...";
				data[num][2]= cadena;
				data[num][3]= "Fallido";
				
				if(cadena.equals("El n�mero de la factura ya existe. No es posible crear la factura"))
				{
					ejecutar("UPDATE Factura " +
							"SET Estado_Factura = 'FACTURA_REPETIDA' " +
							"WHERE No_Factura = '" + no_Factura +"'");
				}
				else{
					
					ejecutar("UPDATE Factura " +
							"SET Estado_Factura = 'AUTORIZADA/FALLIDA' " +
							"WHERE No_Factura = '" + no_Factura +"'");
				}
					
			}
			
		}
		else
		{
			data[num][0]= "Autorizacion Factura: " + no_Factura ;
			data[num][1]= "Facturas aprobada correctamente...";
			data[num][2]= "No se encontro la Factura";
			data[num][3]= "Fallido";
			
			ejecutar("UPDATE Factura " +
					"SET Estado_Factura = 'NO_ENCONTRADA' " +
					"WHERE No_Factura = '" + no_Factura +"'");
		}
		
	}
}

