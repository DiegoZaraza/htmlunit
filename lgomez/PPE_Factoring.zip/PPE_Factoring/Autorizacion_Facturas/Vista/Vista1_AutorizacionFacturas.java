package Autorizacion_Facturas.Vista;
import javax.swing.plaf.basic.BasicSliderUI.ScrollListener;

import resources.Autorizacion_Facturas.Vista.Vista1_AutorizacionFacturasHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista1_AutorizacionFacturas extends Vista1_AutorizacionFacturasHelper
{
	String no_Factura, accion;
	TestObject[] radios;
	TestObject[] button;
	
	public boolean testMain(Object[] args) 
	{
		no_Factura = (String)args[0];
		AccederFacturas();
		sleep(4);
		text_htmlINPUTText(ubicacion(1), DEFAULT).waitForExistence();
		text_htmlINPUTText(ubicacion(1), DEFAULT).setText(no_Factura);
		sleep(2);
		
		try {
			radioButton__170capturadoCheck(ubicacion(1), DEFAULT).click();
			sleep(5);
//			ubicacionCLick(); sleep(2);
			
			while(!button_siguientebutton3().isEnabled()){
				LowLevelEvent llEvent[] = new LowLevelEvent[1];
				llEvent[0] = mouseWheel(-25);
				getRootTestObject().emitLowLevelEvent(llEvent);
			}
//			teclado("{TAB}");
//			teclado("{ENTER}");sleep(3);
			
			button_siguientebutton3().click();
			teclado("{TAB}{TAB}");
			teclado("{ENTER}");sleep(3);
			teclado("{TAB}{TAB}");
			teclado("{ENTER}");sleep(3);
			
			

			return true;
		} catch (Exception e) {
			
			teclado("{TAB}");
			return false;
		}
		
		
	}
	
	public void recorrerLista(int cantidad){
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else 
			return browser_htmlBrowser(document_facturas(), DEFAULT);	
	}
	public void AccederFacturas(){
		
		if(link_autorizaci�nYDesembolsoDe(ANY, LOADED).exists() && link_autorizaci�nYDesembolsoDe(ANY, LOADED).isShowing())
		{
			link_autorizaci�nYDesembolsoDe().click();
			sleep(4);
		}
		else
		{
			try {
				link_factoring().click();sleep(1);	
				link_facturas().click();sleep(1);
				link_autorizaci�nYDesembolsoDe(ANY, LOADED).click();
			} catch (Exception e) {
				teclado("{F5}");sleep(3);
				AccederFacturas();
			}
		}
	}
	
	public void ubicacionCLick(){
		try {
			text_numeroFactura().doubleClick();
		} catch (Exception e) {
			// TODO: handle exception
			ubicacionCLick();
		}
		
	}
}

