package Lanzadores;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import resources.Lanzadores.F_AutorizarCupoHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class F_AutorizarCupo extends F_AutorizarCupoHelper implements ActionListener, ItemListener
{
	/**
	 * @since  2015/10/23
	 * @author GORTEG1
	 */
	JFrame frame;
	JPanel panel1, panel2, panel3, panel4, panel5;
	Container contenedor, contenedor2;
	JComboBox<String> jComboBoxClientes, jComboBoxCupos, jComboBoxCupos2;
	ArrayList<String> arrayListaClientes, arrayListaCupos, arrayListaCupos2;
	JButton jButtonUno, jButtonTodos, jButtonautorizar;
	JLabel jLabelclientes;
	JRadioButton jRadioButtonAutorizar, jRadioButtonDevolver;
	String[] listafinal;
	ButtonGroup grupoAccion;
	String sql;
	
	public void testMain(Object[] args) 
	{
		//INCICIALIZACION PANELES Y CONTENEDORES
				frame = new JFrame("AUTORIZAR CUPOS");
				contenedor = new Container();
				contenedor.setLayout(new GridLayout(1,3));
				contenedor.setVisible(true);
				contenedor2 = new Container();
				panel1 = new JPanel();
				panel2 = new JPanel();
				ConnecionDB();
				
				//LISTAS 
				arrayListaClientes = ObtenerListaClientes();
				arrayListaCupos = new ArrayList<String>();
				arrayListaCupos2 = new ArrayList<String>();
				//arrayListaCupos = ObtenerCupos(clienteEscojido)
			
				//ETIQUETAS
				jLabelclientes = new JLabel("CLIENTES CON CUPOS");
				jLabelclientes.setVisible(true);
				
				//COMBOBOX
				jComboBoxClientes = new JComboBox<String>();
				for (String cliente : arrayListaClientes) 
					jComboBoxClientes.addItem(cliente);
				jComboBoxClientes.addItemListener(this);
				
				jComboBoxCupos = new JComboBox<String>();
				jComboBoxCupos2 = new JComboBox<String>();
								
				//BOTTONES 
				jButtonUno = new JButton();
				ImageIcon iconouno = new ImageIcon("icono_uno.png"); 
				jButtonUno.setIcon(iconouno);
				jButtonUno.addActionListener(this);
				jButtonUno.setMnemonic(KeyEvent.VK_D);
				jButtonUno.setActionCommand("uno");
				
				jButtonTodos = new JButton();
				ImageIcon iconotodos = new ImageIcon("icono_todos.png");
				jButtonTodos.setIcon(iconotodos);
				jButtonTodos.addActionListener(this);
				jButtonTodos.setMnemonic(KeyEvent.VK_D);
				jButtonTodos.setActionCommand("todos");		
				
				jButtonautorizar = new JButton("EJECUTAR");
				jButtonautorizar.addActionListener(this);
				jButtonautorizar.setMnemonic(KeyEvent.VK_D);
				jButtonautorizar.setActionCommand("auto");		
				
				//RADIOBUTTON
				jRadioButtonAutorizar = new JRadioButton("Autorizar", false);
				jRadioButtonDevolver = new JRadioButton("Devolver", false);
				jRadioButtonAutorizar.setVisible(true);
				jRadioButtonDevolver.setVisible(true);
				grupoAccion = new ButtonGroup();
				grupoAccion.add(jRadioButtonAutorizar);
				grupoAccion.add(jRadioButtonDevolver);
				
				//CARAGAR CONTENEDORES 
				panel1 = new JPanel();
				panel1.setBorder(BorderFactory.createTitledBorder("Clientes"));
				panel1.setLayout(new GridLayout(1,2));
				panel1.add(jLabelclientes);
				panel1.add(jComboBoxClientes);
				
				panel2 = new JPanel();
				panel2.setLayout(new GridLayout(2,1));
				panel2.add(jButtonUno);
				panel2.add(jButtonTodos);
				
				panel3 = new JPanel();
				panel3.setBorder(BorderFactory.createTitledBorder("Cupos"));
				panel3.setLayout(new GridLayout(1,3));
				panel3.add(jComboBoxCupos);
				panel3.add(panel2);
				panel3.add(jComboBoxCupos2);
				
				panel5 = new JPanel();
				panel5.add(jRadioButtonAutorizar);
				panel5.add(jRadioButtonDevolver);
				
				panel4 = new JPanel();
				panel4.setBorder(BorderFactory.createTitledBorder("Autorizar"));
				panel4.setLayout(new GridLayout(1,2));
				panel4.add(panel5);
				panel4.add(jButtonautorizar);
				
				
				frame.setLayout(new GridLayout(3,1));
				frame.add(panel1);
				frame.add(panel3);
				frame.add(panel4);
				frame.setSize(400, 200);
				frame.setVisible(true);
				frame.setDefaultCloseOperation(1);
				
				if(!jComboBoxClientes.getSelectedItem().equals(null)){
					ResultSet resultado = Consulta("SELECT NivelCupo " +
							"FROM Cupo " +
								"WHERE No_Documento = '" + jComboBoxClientes.getSelectedItem() + "' AND EstadoCupo = 'CREADO'" +
									"ORDER BY NivelCupo");
					
					try {
						while(resultado.next())
							arrayListaCupos.add(resultado.getString(1));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
					for (String cupo : arrayListaCupos) {
						jComboBoxCupos.addItem(cupo);
					}
				}
					
				
				sql = "";
				while(sql.equals("")){
					Espera(1);
				}
				listafinal = new String[arrayListaCupos2.size()+2];
				for (int i =0; i<arrayListaCupos2.size(); i++) {
					listafinal[i] = arrayListaCupos2.get(i);
				}
				listafinal[listafinal.length-2]= (String)jComboBoxClientes.getSelectedItem();
				if(jRadioButtonAutorizar.isSelected())
					listafinal[listafinal.length-1]= "Autorizar";
				else
					listafinal[listafinal.length-1]= "Devolver";
				
				if((boolean)callScript("Scripts.Login"))
					callScript("Autorizacion_Cupo.Controlador.Autorizar_Cupo",  listafinal);
				
			}
			
			/**
			 * 
			 * EVENTOS
			 * 
			 */
			
			//ACCION DE BOTON Y JRADIOBUTTON
			public void actionPerformed(ActionEvent e){
				
				//jComboBoxCupos2.removeAllItems();
				
				if ("uno".equals(e.getActionCommand())){
					if(jComboBoxCupos.getSelectedIndex()>=0){
						jComboBoxCupos2.addItem((String)jComboBoxCupos.getSelectedItem());
						arrayListaCupos2.add((String)jComboBoxCupos.getSelectedItem());
					}
				}
				if ("todos".equals(e.getActionCommand())){
					for (String cupo : arrayListaCupos) {
						jComboBoxCupos2.addItem(cupo);
						arrayListaCupos2.add(cupo);
					}
				}
				if ("auto".equals(e.getActionCommand())){
					sql = "ejecute";
				}
			}
			
			//ACCION DE MODIFICACION EN LISTAS
			public void itemStateChanged(ItemEvent e) {
				
				arrayListaCupos.clear();
				jComboBoxCupos.removeAllItems();
				
				if(jComboBoxClientes.getSelectedIndex()>=0){
					
					ResultSet resultado = Consulta("SELECT NivelCupo " +
							"FROM Cupo " +
								"WHERE No_Documento = '" + jComboBoxClientes.getSelectedItem() + "' AND EstadoCupo = 'CREADO'" +
									"ORDER BY NivelCupo");
					
					try {
						while(resultado.next())
							arrayListaCupos.add(resultado.getString(1));
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
					for (String cupo : arrayListaCupos) {
						jComboBoxCupos.addItem(cupo);
					}
				}
			}
			
			public ArrayList<String> ObtenerListaClientes(){
				
				ArrayList<String> listaProv = new ArrayList<>();
				ResultSet resultado = Consulta("SELECT No_Documento " +
										"FROM Cupo " +
											"WHERE EstadoCupo = 'CREADO' " +
												"GROUP BY No_Documento");
				
				try {
					while(resultado.next()){
						listaProv.add(resultado.getString(1));
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return listaProv;
			}
			
			public ArrayList<String> ObtenerCupos(String clienteEscojido){
				
				ArrayList<String> listaProv = new ArrayList<>();
				ResultSet resultado = Consulta("SELECT No_Documento " +
															"FROM Cupo " +
																"WHERE EstadoCupo = 'CREADO'");
				
				try {
					while(resultado.next()){
						listaProv.add(resultado.getString(1));
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return listaProv;
			}
	
}

