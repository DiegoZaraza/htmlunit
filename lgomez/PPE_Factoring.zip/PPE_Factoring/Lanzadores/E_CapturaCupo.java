package Lanzadores;
import resources.Lanzadores.E_CapturaCupoHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;


public class E_CapturaCupo extends E_CapturaCupoHelper implements ActionListener, ItemListener
{
	/**
	 * @since  2015/10/19
	 * @author GORTEG1
	 */
	JFrame frame, frame2;
	JPanel panel1, panel2, panel3, panel4;
	Container contenedor, contenedor2, contenedor3;
	JButton jbuttonAgregarCliente, jbuttonCapturarCupo;
	String[] listaClientesSinCupos, listaClientesConCupos, listaClientesTemporal, listaTipoDocumento, listaLineaCredito, listaConveniosTemporal, listaConvenios;
	String[] listafinal = new String[7];
	String documentoCliente, tipoDocumentoCliente, sql;
	ArrayList<String> arrayListaClientes, arrayListaDocumentos, arrayListaCupos, arrayListaNombreCupo, arrayListaValorAprobado, arrayListaConvenios;
	JComboBox<String> jComboBoxClientes, jComboBoxTipoDocumento, jComboBoxLineaCredito, jComboBoxConvenios;
	JRadioButton jRadioButtonSinCupos, jRadioButtonConCupos, jRadioButtonTodos, jRadioButtonSinAsociar;
	JLabel jlabelCupoGlogal, jlabelCupoFactoring, jlabelCupoEspecifico, jlabelCupoDisponible, jlabelInfoClientes, jlabelTipoDocumento, jlabelDocumento;
	JTextField  jtextFileCupoGlogal, jtextFileCupoFactoring, jtextFileCupoEspecifico, jtextFileCupoDisponible, jtextFileDocumento;
	ButtonGroup grupoAccion;
	
	public void testMain(Object[] args) 
	{
		frame = new JFrame("CAPTURAR CUPOS");
		frame2 = new JFrame();
		contenedor = new Container();
		contenedor2 = new Container();
		contenedor3 = new Container();
		ConnecionDB();
		
		//LISTAS PARA LOS COMBOBOX
		arrayListaClientes = new ArrayList<String>();
		arrayListaDocumentos = new ArrayList<String>();
		arrayListaCupos = new ArrayList<String>();
		arrayListaNombreCupo = new ArrayList<String>();
		arrayListaValorAprobado = new ArrayList<String>();
		arrayListaConvenios = new ArrayList<String>();
		listaClientesTemporal = new String[1];
		listaClientesTemporal[0]= "Seleccione el tipo de cliente                         ";
		listaConveniosTemporal = new String[1];
		listaConveniosTemporal[0]= "Seleccione Convenio";
		
		
		listaTipoDocumento = new String[9];
		listaTipoDocumento[0] = "Cedula de Ciudadania";
		listaTipoDocumento[1] = "NIT Persona Juridica";
		listaTipoDocumento[2] = "Cedula de Extranjeria";
		listaTipoDocumento[3] = "NIT Extranjeria";
		listaTipoDocumento[4] = "NIT Persona Natural";
		listaTipoDocumento[5] = "Pasaporte";
		listaTipoDocumento[6] = "Registro Civil";
		listaTipoDocumento[7] = "Tarjeta de Identidad";
		listaTipoDocumento[8] = "Patrimonios Autonomos";
		
		listaLineaCredito = new String[11];
		listaLineaCredito[0] = "26-Factoring sin Recurso";
		listaLineaCredito[1] = "27-Factoring con Recurso";
		listaLineaCredito[2] = "602-Convenios C variable hasta  60 meses";
		listaLineaCredito[3] = "603-Convenio CEMEX Cuota Unica";
		listaLineaCredito[4] = "605-Convenios C Fija hasta  60 meses";
		listaLineaCredito[5] = "612-Pago a Proveedores";
		listaLineaCredito[6] = "613-Pago a Proveedores con Financiaci�n";
		listaLineaCredito[7] = "614-Anticipo de Facturas";
		listaLineaCredito[8] = "615-Descuento Proveedores";
		listaLineaCredito[9] = "616-Financiancion a Compradores";
		listaLineaCredito[10] = "TODAS LA LINEAS DE CREDITO";
		
	
		//JRADIOBUTTON PARA ESCOJER QUE CLIENTES SE NECESITAN 
		jRadioButtonSinCupos = new JRadioButton("Sin Cupos", false);
		jRadioButtonConCupos = new JRadioButton("Con Cupos", false);
		jRadioButtonTodos = new JRadioButton("Todos", false);
		jRadioButtonSinCupos.setVisible(true);
		jRadioButtonConCupos.setVisible(true);
		jRadioButtonTodos.setVisible(true);
		jRadioButtonSinAsociar =  new JRadioButton("sin Asociar", false);
		jRadioButtonSinAsociar.setVisible(true);
		jRadioButtonSinAsociar.addActionListener(this);
		jRadioButtonSinAsociar.setMnemonic(KeyEvent.VK_D);
		jRadioButtonSinAsociar.setActionCommand("sinAsociar");
		
		jRadioButtonSinCupos.addActionListener(this);
		jRadioButtonSinCupos.setMnemonic(KeyEvent.VK_D);
		jRadioButtonSinCupos.setActionCommand("sinCupos");
		jRadioButtonConCupos.addActionListener(this);
		jRadioButtonConCupos.setMnemonic(KeyEvent.VK_D);
		jRadioButtonConCupos.setActionCommand("conCupos");
		jRadioButtonTodos.addActionListener(this);
		jRadioButtonTodos.setMnemonic(KeyEvent.VK_D);
		jRadioButtonTodos.setActionCommand("todos");
		
		grupoAccion = new ButtonGroup();
		grupoAccion.add(jRadioButtonSinCupos);
		grupoAccion.add(jRadioButtonConCupos);
		grupoAccion.add(jRadioButtonTodos);
				
		//COMBOBOX 
		jComboBoxClientes = new JComboBox(listaClientesTemporal);
		jComboBoxClientes.setEditable(true);
		jComboBoxClientes.addItemListener(this);
		
		jComboBoxConvenios = new JComboBox(listaConveniosTemporal);
		jComboBoxConvenios.setEditable(true);
		
		
		jComboBoxTipoDocumento = new JComboBox(listaTipoDocumento);
		jComboBoxTipoDocumento.setVisible(true);
		
		jComboBoxLineaCredito = new JComboBox(listaLineaCredito);
		jComboBoxLineaCredito.setVisible(true);
		
		//LABELS O ETIQUETAS
		jlabelCupoGlogal = new JLabel(" Cupo Glogal    ");
		jlabelCupoGlogal.setVisible(true);
		jlabelCupoFactoring = new JLabel(" Cupo Factoring ");
		jlabelCupoFactoring.setVisible(true);
		jlabelCupoEspecifico = new JLabel(" Cupo Especifico");
		jlabelCupoEspecifico.setVisible(true);
		jlabelCupoDisponible = new JLabel(" Cupo Disponible");
		jlabelTipoDocumento = new JLabel("Tipo ");
		jlabelTipoDocumento.setVisible(true);
		jlabelDocumento = new JLabel("Numero Documento");
		jlabelDocumento.setVisible(true);
		
		//CUADROS DE TEXTO 
		jtextFileCupoGlogal = new JTextField(10);
		jtextFileCupoGlogal.setVisible(true);
		jtextFileCupoFactoring = new JTextField(10);
		jtextFileCupoFactoring.setVisible(true);
		jtextFileCupoEspecifico = new JTextField(10);
		jtextFileCupoEspecifico.setVisible(true);
		jtextFileCupoDisponible = new JTextField(10);
		jtextFileCupoDisponible.setVisible(true);
		jtextFileCupoDisponible.setEditable(false);
		jtextFileDocumento = new JTextField(10);
		jtextFileDocumento.setVisible(true);
		
		//BOTONES
		jbuttonAgregarCliente = new JButton("AGREGAR CLIENTE");
		jbuttonAgregarCliente.addActionListener(this);
		jbuttonAgregarCliente.setMnemonic(KeyEvent.VK_D);
		jbuttonAgregarCliente.setActionCommand("Agregar");
		jbuttonCapturarCupo = new JButton("CAPTURA CUPO");
		jbuttonCapturarCupo.addActionListener(this);
		jbuttonCapturarCupo.setMnemonic(KeyEvent.VK_D);
		jbuttonCapturarCupo.setActionCommand("Capturar");	
		
		//PANELES Y CONTENEDORES 
		panel1 = new JPanel();
		panel1.setBorder(BorderFactory.createTitledBorder("CLIENTES"));
		panel1.add(jRadioButtonSinCupos);
		panel1.add(jRadioButtonConCupos);
		panel1.add(jRadioButtonTodos);
		panel1.add(jComboBoxClientes);
		panel1.add(jComboBoxConvenios);
		panel1.add(jRadioButtonSinAsociar);
		
		panel2 = new JPanel();
		panel2.setBorder(BorderFactory.createTitledBorder("CUPOS"));
		panel2.setLayout(new GridLayout(4,2));
		panel2.add(jlabelCupoGlogal);
		panel2.add(jtextFileCupoGlogal);
		panel2.add(jlabelCupoFactoring);
		panel2.add(jtextFileCupoFactoring);
		panel2.add(jlabelCupoEspecifico);
		panel2.add(jtextFileCupoEspecifico);
		panel2.add(jlabelCupoDisponible);
		panel2.add(jtextFileCupoDisponible);
		
		panel3 = new JPanel();
		panel3.setBorder(BorderFactory.createTitledBorder("AGREGAR CLIENTES"));
		panel3.add(jlabelDocumento);
		panel3.add(jtextFileDocumento);
		panel3.add(jlabelTipoDocumento);
		panel3.add(jComboBoxTipoDocumento);
		panel3.add(jbuttonAgregarCliente);
		
		panel4 = new JPanel();
		panel4.setBorder(BorderFactory.createTitledBorder("CAPTURAR CUPOS"));
		panel4.add(jComboBoxLineaCredito);
		panel4.add(jbuttonCapturarCupo);
				
		contenedor.setLayout(new GridLayout(1, 2));
		contenedor.add(panel1);
		contenedor.add(panel2);
		
		
		contenedor2 = frame2.getContentPane();
		contenedor2.setLayout(new GridLayout(1,2));
		contenedor2.add(panel3);
		contenedor2.add(panel4);
		
		
		frame.setLayout(new GridLayout(2,1));
		frame.add(contenedor);
		frame.add(contenedor2);
		frame.setSize(570, 280);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(1);
		
		sql = "";
		while(sql.equals("")){
			Espera(1);
		}
		listafinal[3] = (String)jComboBoxLineaCredito.getSelectedItem();
		listafinal[4] = (String)jComboBoxClientes.getSelectedItem();
		listafinal[5] = arrayListaDocumentos.get(arrayListaClientes.indexOf(jComboBoxClientes.getSelectedItem()));
		listafinal[6] = (String)jComboBoxConvenios.getSelectedItem();
		
		if((boolean)callScript("Scripts.Login"))
			callScript("Creacion_Cupos.Controlador.Crear_Cupo",  listafinal);
	}
	
	/**
	 * 
	 * EVENTOS
	 * 
	 */
	
	//ACCION DE BOTON Y JRADIOBUTTON
	public void actionPerformed(ActionEvent e){
		
		//ACCION DEL BOTON CAPTURAR CUPO
		if ("Capturar".equals(e.getActionCommand())){
			
			int error = 0;
			
			if(jtextFileCupoGlogal.isEditable()){
				if(jtextFileCupoGlogal.getText().equals("")){
					JOptionPane.showMessageDialog(null, "AGREGAR CUPO GLOBAL", "ERROR", JOptionPane.ERROR_MESSAGE);
					error++;
				}
				else
					listafinal[0]=jtextFileCupoGlogal.getText()+"00";
			}	
			else
				listafinal[0]="NA";
				
			if(jtextFileCupoFactoring.isEditable()){
				if(jtextFileCupoFactoring.getText().equals("")){
					JOptionPane.showMessageDialog(null, "AGREGAR CUPO FACTORING", "ERROR", JOptionPane.ERROR_MESSAGE);
					error++;
				}
				else {
					if(Double.parseDouble(jtextFileCupoFactoring.getText())<Double.parseDouble(jtextFileCupoGlogal.getText()))
						listafinal[1]=jtextFileCupoFactoring.getText()+"00";
					else{
						JOptionPane.showMessageDialog(null, "CUPO FACTORIG SUPERA AL CUPO GLOBAL", "ERROR", JOptionPane.ERROR_MESSAGE);
						error++;
					}
				}
			}
			else 
				listafinal[1]="NA";
				
			if((!jtextFileCupoEspecifico.getText().equals(""))) {
				if(!jtextFileCupoDisponible.getText().equals("")){
					if(Double.parseDouble(jtextFileCupoEspecifico.getText())<Double.parseDouble(jtextFileCupoDisponible.getText()))
						listafinal[2]=jtextFileCupoEspecifico.getText()+"00";
					else{
						JOptionPane.showMessageDialog(null, "IMPOSIBLE CREAR CUPO ESPECIFICO, CUPO DISPONIBLE NO ES SUFICIENTE ", "ERROR", JOptionPane.ERROR_MESSAGE);
						error++;
					}
				}
				else
					listafinal[2]=jtextFileCupoEspecifico.getText()+"00";
			}
			else 
				listafinal[2]="NA";
			if(jComboBoxConvenios.getSelectedIndex()==-1){
				JOptionPane.showMessageDialog(null, "NINGUN CONVENIO SELECCIONADO, SE ESCOGERA EL CONVENIO SEGUN LA LINEA DE CREDITO DEL CUPO A CREAR", "ERROR", JOptionPane.ERROR_MESSAGE);
			}
			if(error==0)
				sql="OK";
		}
				
		ResultSet resultado2;
		
		//CONDICIONALES PARA EL LLENADO DE COMBOBOX DE DOCUMENTOS DE IDENTIDAD 
		if("sinCupos".equals(e.getActionCommand()) || "conCupos".equals(e.getActionCommand()) || "todos".equals(e.getActionCommand())){
			jComboBoxClientes.removeAllItems();
			arrayListaClientes.clear();
		}
		if(jRadioButtonSinCupos.isSelected()){
			resultado2 = Consulta("SELECT No_Documento, Tipo_Documento " +
					"FROM Cliente " +
						"WHERE NivelCupo_Actual = 'NA'");
		}
		else if(jRadioButtonConCupos.isSelected()){
			resultado2 = Consulta("SELECT No_Documento, Tipo_Documento " +
					"FROM Cliente " +
						"WHERE NivelCupo_Actual != 'NA'");
		}
		else{
			resultado2 = Consulta("SELECT No_Documento, Tipo_Documento " +
					"FROM Cliente ");
		}

		try {
			while(resultado2.next()){
				
				documentoCliente = resultado2.getString(1);
				tipoDocumentoCliente = resultado2.getString(2);
				arrayListaClientes.add(documentoCliente);
				arrayListaDocumentos.add(tipoDocumentoCliente);
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		for (int i = 0; i < arrayListaClientes.size(); i++) {
			jComboBoxClientes.addItem(arrayListaClientes.get(i));
		}
		
		//ACCCION DEL BOTON AGREGAR CLIENTE
		if ("Agregar".equals(e.getActionCommand())){
			
			if(jtextFileDocumento.getText().equals(""))
				JOptionPane.showMessageDialog(null, "AGREGAR NUMERO DE DOCUMENTO", "Error", JOptionPane.ERROR_MESSAGE);
			else{
				
				String tipoDoc = "";
				if(jComboBoxTipoDocumento.getSelectedItem().equals("Cedula de Ciudadania"))
					tipoDoc = "CC";
				if(jComboBoxTipoDocumento.getSelectedItem().equals("NIT Persona Juridica"))
					tipoDoc = "NPJ";
				if(jComboBoxTipoDocumento.getSelectedItem().equals("Cedula de Extranjeria"))
					tipoDoc = "CE";
				if(jComboBoxTipoDocumento.getSelectedItem().equals("NIT Extranjeria"))
					tipoDoc = "NE";
				if(jComboBoxTipoDocumento.getSelectedItem().equals("NIT Persona Natural"))
					tipoDoc = "NPN";
				if(jComboBoxTipoDocumento.getSelectedItem().equals("Pasaporte"))
					tipoDoc = "PAS";
				if(jComboBoxTipoDocumento.getSelectedItem().equals("Registro Civil"))
					tipoDoc = "RC";
				if(jComboBoxTipoDocumento.getSelectedItem().equals("Tarjeta de Identidad"))
					tipoDoc = "TI";
				if(jComboBoxTipoDocumento.getSelectedItem().equals("Patrimonios Autonomos"))
					tipoDoc = "PA";
				
				String resultadoEjcucion = ejecutar("INSERT INTO Cliente " +
										"VALUES ('" + jtextFileDocumento.getText() + "'" + 
										", '" + tipoDoc + "', '', 'NA')");
				if(resultadoEjcucion.substring(0, 9).equals("Violation"))
					JOptionPane.showMessageDialog(null, "Numero de documento ya existe", "ERROR", JOptionPane.ERROR_MESSAGE);
				else 
					JOptionPane.showMessageDialog(null, "Documento agregado correctamente", "EXITOSO", JOptionPane.DEFAULT_OPTION);
			}
				
		}
		
		//ACCCION DEL BOTON AGREGAR CLIENTE
		if ("sinAsociar".equals(e.getActionCommand())){
			
			arrayListaConvenios.clear();
			jComboBoxConvenios.removeAllItems();
			
			ResultSet resultado5 = Consulta("SELECT No_Convenio " +
					"FROM Convenio " +
					"WHERE Estado_convenio = 'CREADO/APROBADO' AND " +
					"No_Convenio NOT IN(SELECT No_Convenio FROM Cliente_Con_Convenio)");
			
				try {
					while(resultado5.next())
						arrayListaConvenios.add(resultado5.getString(1));
					
				} catch (SQLException e1) {
					// TODO Bloque catch generado autom�ticamente
					e1.printStackTrace();
				}	
				
			for(int i=0; i<arrayListaConvenios.size();i++)
				jComboBoxConvenios.addItem(arrayListaConvenios.get(i));
		}
	}
	
	//ACCION DE MODIFICACION EN LISTAS
	public void itemStateChanged(ItemEvent e) {
		
		arrayListaCupos.clear();
		arrayListaNombreCupo.clear();
		arrayListaValorAprobado.clear();
		arrayListaConvenios.clear();
		jtextFileCupoGlogal.setEditable(true);
		jtextFileCupoFactoring.setEditable(true);
		jtextFileCupoGlogal.setText("");
		jtextFileCupoFactoring.setText("");
		jtextFileCupoDisponible.setText("");
		
		ResultSet resultado3 = Consulta("SELECT NivelCupo, Nombre_Cupo, Valor_Aprobado " +
				"FROM Cupo WHERE EstadoCupo != 'DEVUELTO' AND No_Documento = '" + jComboBoxClientes.getSelectedItem() + "'");
		
		ResultSet resultado4 = Consulta("SELECT No_Convenio " +
				"FROM Cliente_Con_Convenio " +
				" WHERE No_Documento = '" + jComboBoxClientes.getSelectedItem() + "'");
		
		try {
			while(resultado3.next()){
				
				arrayListaCupos.add(resultado3.getString(1));
				arrayListaNombreCupo.add(resultado3.getString(2));
				arrayListaValorAprobado.add(resultado3.getString(3));
			}
			while(resultado4.next())
				arrayListaConvenios.add(resultado4.getString(1));
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		jComboBoxConvenios.removeAllItems();
		
		listaConvenios = new String[arrayListaConvenios.size()];
		for(int i=0; i<arrayListaConvenios.size();i++)
			jComboBoxConvenios.addItem(arrayListaConvenios.get(i));
			//listaConvenios[i]=arrayListaConvenios.get(i);
		
		//CICLO QUE INDICA LOS CUPOS QUE POSEE CADA UNO DE LOS CLIENTES ESCOJIDOS DE LA LISTA 
		if(!arrayListaNombreCupo.isEmpty()){
			
			String cupoFinal= "";
			int valorDisponible = 0;
			int valor = 0;
			
			for (int i = 0; i<arrayListaNombreCupo.size(); i++){
				if(arrayListaNombreCupo.get(i).equals("CUPO GLOBAL")){
					jtextFileCupoGlogal.setText(arrayListaValorAprobado.get(i));
					jtextFileCupoGlogal.setEditable(false);
				}
				else if(arrayListaNombreCupo.get(i).equals("CUPO FACTORING")){
					if(!arrayListaValorAprobado.get(i).equals(""))
						valorDisponible = Integer.parseInt(arrayListaValorAprobado.get(i));
					jtextFileCupoFactoring.setText(arrayListaValorAprobado.get(i));
					jtextFileCupoFactoring.setEditable(false);
				}
				else {
					if(!(jComboBoxClientes.getSelectedIndex()==-1))
						valor = ObtenerSumatoriaCupos((String)jComboBoxClientes.getSelectedItem());
						//valor = valor + Integer.parseInt(arrayListaValorAprobado.get(i));
				}
			}
			if(valorDisponible == 0)
				if(!jtextFileCupoGlogal.getText().equals(""))
					valorDisponible = Integer.parseInt(jtextFileCupoGlogal.getText());
			valorDisponible = valorDisponible - valor;
			jtextFileCupoDisponible.setText(""+valorDisponible);
			jtextFileCupoDisponible.setEditable(false);
		}
	}
	
	public int ObtenerSumatoriaCupos(String clienteSelect){
		
		int sumatoria = 0;
		ResultSet resultadoSuma = Consulta("SELECT SUM(Valor_Aprobado) " +
											"FROM Cupo WHERE No_Documento = '" + clienteSelect + "' AND " +
											"Nombre_Cupo != 'CUPO FACTORING' AND Nombre_Cupo != 'CUPO GLOBAL'");
		
		try {
			while(resultadoSuma.next()){
				sumatoria = resultadoSuma.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
		
		return sumatoria;
	}
}

