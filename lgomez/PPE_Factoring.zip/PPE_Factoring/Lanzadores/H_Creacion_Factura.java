package Lanzadores;
import java.awt.BorderLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import resources.Lanzadores.H_Creacion_FacturaHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author lgomez11
 */
public class H_Creacion_Factura extends H_Creacion_FacturaHelper implements ActionListener
{
	JFrame frame;
	String No_Convenio, Nombre_Convenio, esperarAccion;
	ArrayList<String> listaConvenios;
	JComboBox desplegableConvenios;
	String[] listaConvenios2, listaConvenios3;
	JTextField jtextCantidad;
	Label labelCantidad;
	private JPanel panelCentral;
	private JButton jbuttonAutorizar;
	
	public void testMain(Object[] args) 
	{
		frame = new JFrame("CREACION FACTURA");
		listaConvenios = new ArrayList<String>();
		
		ConnecionDB();
		ResultSet resultado =Consulta("SELECT No_Convenio "+
										"FROM Cliente_Con_Convenio "+
										"WHERE Estado = 'ASOCIADO'");
		
		
			try {
				while(resultado.next()){
					
					No_Convenio = resultado.getString(1);
									
					listaConvenios.add(No_Convenio);
				}
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
		
		listaConvenios2 = new String[listaConvenios.size()+1];
		
		for (int i = 0; i < listaConvenios.size(); i++) {
			listaConvenios2[i] = listaConvenios.get(i);
		}
		listaConvenios2[listaConvenios.size()]= "Crear factura a todos";
		
		desplegableConvenios = new JComboBox(listaConvenios2);
		desplegableConvenios.setEditable(true);
		desplegableConvenios.setSelectedItem("Seleccione nombre del convenio");
		
		labelCantidad = new Label("Cantidad");
		labelCantidad.setVisible(true);
		
		jtextCantidad = new JTextField("               ");
		jtextCantidad.setEditable(true);
		
				
		jbuttonAutorizar = new JButton("EJECUTAR");
		jbuttonAutorizar.addActionListener(this);
		jbuttonAutorizar.setMnemonic(KeyEvent.VK_D);
		jbuttonAutorizar.setActionCommand("auto");
				
		panelCentral = new JPanel();
		panelCentral.add(desplegableConvenios);
		panelCentral.add(labelCantidad);
		panelCentral.add(jtextCantidad);
		panelCentral.add(jbuttonAutorizar);
		
		frame.add(panelCentral, BorderLayout.CENTER);
		frame.setSize(400, 150);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(1);
		
		//  Condicional que no permite que se cierre el JFrame
		esperarAccion = "";
		while(esperarAccion.equals("")){
			Espera(1);
		}
		
		listaConvenios3 = new String[2];
		listaConvenios3[0]=(String)desplegableConvenios.getSelectedItem();
		listaConvenios3[1]=jtextCantidad.getText();
				
		if((boolean)callScript("Scripts.Login"))
					callScript("Creacion_Factura.Controlador.Crear_Factura", listaConvenios3);

	}	
	
	public void actionPerformed(ActionEvent e){
			
		
	       // Click en botton autorizar
			if ("auto".equals(e.getActionCommand())){
				if(desplegableConvenios.getSelectedIndex()>-1){
					if(!jtextCantidad.getText().equals("               "))
						esperarAccion = "OK";
					else
						JOptionPane.showMessageDialog(null, "INSERTE CANTIDAD DE FACTURAS", "Error", JOptionPane.ERROR_MESSAGE);
				}
				else
					JOptionPane.showMessageDialog(null, "SELECCIONE EL CONVENIO QUE DESEA AUTORIZAR", "Error", JOptionPane.ERROR_MESSAGE);
				
	        }
	}
}

