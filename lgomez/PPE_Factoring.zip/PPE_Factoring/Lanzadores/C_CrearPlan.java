package Lanzadores;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.text.StyledEditorKit.BoldAction;
import javax.xml.bind.Marshaller.Listener;

import resources.Lanzadores.C_CrearPlanHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class C_CrearPlan extends C_CrearPlanHelper implements ActionListener, ItemListener
{
	/**
	 * Script Name   : <b>C_CrearPlan</b>
	 * Generated     : <b>17/09/2015 16:24:18</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/09/17
	 * @author GORTEG1
	 */
	JFrame frame;
	ArrayList<String> listaConvenios = new ArrayList<String>();
	String No_Convenio, Nombre_Convenio, sql;
	JPanel panel1, panel2, panel3, panel4;
	JButton botonaFitrar, botonCancelar;
	Label titulo, titulo2, titulo3, tituloplazod, tituloplazof;
	JTextField cuadroTexto, cuadroTexto2, cuadroTexto3, cuadroTextoplazod, cuadroTextoplazof;
	Container contenedor, contenedor2;
	String[] listaTTDescuento, listaTTFinanciacion, listaSegmento, listaConvenios2, sqlFinal; 
	JComboBox<String> jcomboboxDescuento, jcomboboxFinanciacion, jcomboboxSegmento, jcomboboxConmvenio;
	JRadioButton jRadioButtonCondicionTD, jRadioButtonCondicionTD2, jRadioButtonTipoPlazoD, jRadioButtonTipoPlazoD2, jRadioButtonCondicionTF, jRadioButtonCondicionTF2, jRadioButtonTipoPlazoF, jRadioButtonTipoPlazoF2, jRadioButtonConvenio;
	
	public void testMain(Object[] args) 
	{		
		//ELEMENTOS DE LISTAS 
		frame = new JFrame("FILTRAR CASOS DE PRUEBA PLANES");
		contenedor = new Container();
		contenedor2 = new Container();
		
		listaSegmento = new String[6];
		listaSegmento[0] = "   Escojer Segmento   ";
		listaSegmento[1] = "E- Empresarial ";
		listaSegmento[2] = "C- Corporativo";
		listaSegmento[3] = "P- Pime";
		listaSegmento[4] = "R- Red";
		listaSegmento[5] = "All";
		
		listaTTDescuento = new String[5];
		listaTTDescuento[0]= "                   Tipo Tasa_Descuento                       ";
		listaTTDescuento[1]= "Fija";
		listaTTDescuento[2]= "Variable";
		listaTTDescuento[3]= "Sin Descuento";
		listaTTDescuento[4]= "Tasa efectiva peri�dica";
		
		listaTTFinanciacion = new String[5];
		listaTTFinanciacion[0]= "                    Tipo Tasa_Financiacion                    ";
		listaTTFinanciacion[1]= "Fija";
		listaTTFinanciacion[2]= "Variable";
		listaTTFinanciacion[3]= "Sin Financiacion";
		listaTTFinanciacion[4]= "Tasa efectiva peri�dica";
		
		jcomboboxConmvenio = new JComboBox<String>(ObtenerConvenios(false));
		jcomboboxConmvenio.setVisible(true);
		jcomboboxConmvenio.setSelectedItem("Seleccione Convenio que obtendra el plan");
		
		jcomboboxDescuento = new JComboBox<String>(listaTTDescuento);
		jcomboboxDescuento.setVisible(true);
		jcomboboxDescuento.setSelectedItem("Tipo Tasa_Descuento");
		jcomboboxDescuento.addItemListener(this);
		
		jcomboboxFinanciacion = new JComboBox<String>(listaTTFinanciacion);
		jcomboboxFinanciacion.setVisible(true);
		jcomboboxFinanciacion.setSelectedItem("Tipo Tasa_Financiacion");
		jcomboboxFinanciacion.addItemListener(this);
		
		jcomboboxSegmento = new JComboBox<String>(listaSegmento);
		jcomboboxSegmento.setVisible(true);
		jcomboboxSegmento.setSelectedItem("Escojer Segmento");
	
		
		jRadioButtonCondicionTD = new JRadioButton("Tasa Estandar", false);
		jRadioButtonCondicionTD.setVisible(false);
		jRadioButtonCondicionTD.addActionListener(this);
		jRadioButtonCondicionTD.setMnemonic(KeyEvent.VK_D);
		jRadioButtonCondicionTD.setActionCommand("tasaEstandarD");
		jRadioButtonCondicionTD2 = new JRadioButton("Tasa Modificable", false);
		jRadioButtonCondicionTD2.setVisible(false);	
		jRadioButtonCondicionTD2.addActionListener(this);
		jRadioButtonCondicionTD2.setMnemonic(KeyEvent.VK_D);
		jRadioButtonCondicionTD2.setActionCommand("tasaModificableD");
		ButtonGroup grupo1 = new ButtonGroup();
		grupo1.add(jRadioButtonCondicionTD);
		grupo1.add(jRadioButtonCondicionTD2);
		jRadioButtonTipoPlazoD = new JRadioButton("Plazo Fijo", false);
		jRadioButtonTipoPlazoD.setVisible(false);		
		jRadioButtonTipoPlazoD.addActionListener(this);
		jRadioButtonTipoPlazoD.setMnemonic(KeyEvent.VK_D);
		jRadioButtonTipoPlazoD.setActionCommand("desplafijo");
		jRadioButtonTipoPlazoD2 = new JRadioButton("Plazo Abierto", false);
		jRadioButtonTipoPlazoD2.setVisible(false);	
		jRadioButtonTipoPlazoD2.addActionListener(this);
		jRadioButtonTipoPlazoD2.setMnemonic(KeyEvent.VK_D);
		jRadioButtonTipoPlazoD2.setActionCommand("desplaabierto");
		ButtonGroup grupo2 = new ButtonGroup();
		grupo2.add(jRadioButtonTipoPlazoD);
		grupo2.add(jRadioButtonTipoPlazoD2);
		//...........................................................................................
		jRadioButtonCondicionTF = new JRadioButton("Tasa Estandar", false);
		jRadioButtonCondicionTF.setVisible(false);		
		jRadioButtonCondicionTF.addActionListener(this);
		jRadioButtonCondicionTF.setMnemonic(KeyEvent.VK_D);
		jRadioButtonCondicionTF.setActionCommand("tasaEstandarF");
		jRadioButtonCondicionTF2 = new JRadioButton("Tasa Modificable", false);
		jRadioButtonCondicionTF2.setVisible(false);	
		jRadioButtonCondicionTF2.addActionListener(this);
		jRadioButtonCondicionTF2.setMnemonic(KeyEvent.VK_D);
		jRadioButtonCondicionTF2.setActionCommand("tasaModificableF");
		ButtonGroup grupo3 = new ButtonGroup();
		grupo3.add(jRadioButtonCondicionTF);
		grupo3.add(jRadioButtonCondicionTF2);
		jRadioButtonTipoPlazoF = new JRadioButton("Plazo Fijo", false);
		jRadioButtonTipoPlazoF.setVisible(false);
		jRadioButtonTipoPlazoF.addActionListener(this);
		jRadioButtonTipoPlazoF.setMnemonic(KeyEvent.VK_D);
		jRadioButtonTipoPlazoF.setActionCommand("finafijo");
		jRadioButtonTipoPlazoF2 = new JRadioButton("Plazo Abierto", false);
		jRadioButtonTipoPlazoF2.setVisible(false);
		jRadioButtonTipoPlazoF2.addActionListener(this);
		jRadioButtonTipoPlazoF2.setMnemonic(KeyEvent.VK_D);
		jRadioButtonTipoPlazoF2.setActionCommand("finaabierto");
		ButtonGroup grupo4 = new ButtonGroup();
		grupo4.add(jRadioButtonTipoPlazoF);
		grupo4.add(jRadioButtonTipoPlazoF2);
		
		
		jRadioButtonConvenio = new JRadioButton("Todos Los convenios", false);
		jRadioButtonConvenio.setVisible(true);		
		jRadioButtonConvenio.addActionListener(this);
		jRadioButtonConvenio.setMnemonic(KeyEvent.VK_D);
		jRadioButtonConvenio.setActionCommand("allconvenios");
		
		botonaFitrar = new JButton("EJECUTAR");
		botonaFitrar.addActionListener(this);
		botonaFitrar.setMnemonic(KeyEvent.VK_D);
		botonaFitrar.setActionCommand("AccionBotonfiltrar");
		botonaFitrar.setVisible(true);
		botonCancelar = new JButton("CANCELAR");
		botonCancelar.addActionListener(this);
		botonCancelar.setMnemonic(KeyEvent.VK_D);
		botonCancelar.setActionCommand("AccionBotoncancelar");
		botonCancelar.setVisible(true);
		
		titulo = new Label("Tasa Descuento");
		titulo.setVisible(false);
		cuadroTexto = new JTextField(10);
		cuadroTexto.setVisible(false);
		titulo2 = new Label("Tasa Financiacion");
		titulo2.setVisible(false);
		cuadroTexto2 = new JTextField(10);
		cuadroTexto2.setVisible(false);
		titulo3 = new Label("Cantidad");
		titulo3.setVisible(true);
		cuadroTexto3 = new JTextField(10);
		cuadroTexto3.setVisible(true);
		tituloplazod = new Label("Plazo Descuento");
		tituloplazod.setVisible(false);
		cuadroTextoplazod = new JTextField(10);
		cuadroTextoplazod.setVisible(false);
		tituloplazof = new Label("Plazo Financiaci�n");
		tituloplazof.setVisible(false);
		cuadroTextoplazof = new JTextField(10);
		cuadroTextoplazof.setVisible(false);
		
		panel1 = new JPanel();
		panel1.setBorder(BorderFactory.createTitledBorder("DESCUENTO"));
		panel1.add(jcomboboxDescuento);
		panel1.add(jRadioButtonCondicionTD);
		panel1.add(jRadioButtonCondicionTD2);
		panel1.add(jRadioButtonTipoPlazoD);
		panel1.add(jRadioButtonTipoPlazoD2);
		panel1.add(titulo);
		panel1.add(cuadroTexto);
		panel1.add(tituloplazod);
		panel1.add(cuadroTextoplazod);
		
		panel2 = new JPanel();
		panel2.setBorder(BorderFactory.createTitledBorder("FINANCIACION"));
		panel2.add(jcomboboxFinanciacion);
		panel2.add(jRadioButtonCondicionTF);
		panel2.add(jRadioButtonCondicionTF2);
		panel2.add(jRadioButtonTipoPlazoF);
		panel2.add(jRadioButtonTipoPlazoF2);
		panel2.add(titulo2);
		panel2.add(cuadroTexto2);
		panel2.add(tituloplazof);
		panel2.add(cuadroTextoplazof);
		
		panel3 = new JPanel();
		panel3.setBorder(BorderFactory.createTitledBorder(""));
		panel3.add(jRadioButtonConvenio);
		panel3.add(jcomboboxConmvenio);
		panel3.add(jcomboboxSegmento);
		panel3.add(titulo3);
		panel3.add(cuadroTexto3);
		panel3.setVisible(true);
		
		panel4 = new JPanel();
		panel4.add(botonaFitrar);
		panel4.add(botonCancelar);
		panel4.setVisible(true);
		
		
		contenedor.setLayout(new GridLayout(1,2));
		contenedor.add(panel1);
		contenedor.add(panel2);
		
		contenedor2.setLayout(new GridLayout(2,1));
		contenedor2.add(panel3);
		contenedor2.add(panel4);
		
		frame.setLayout(new GridLayout(2,1));
		frame.add(contenedor);
		frame.add(contenedor2);
		frame.setSize(550,400);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(1);
	
		//DETIENE EL SCRIPT PARA QUE NO CIERRE EL FRAME
		sql = "";
		while(sql.equals("")){
			Espera(1);
		}
		sqlFinal = new String[7];
		sqlFinal[0]=sql;
		sqlFinal[1]=cuadroTexto.getText();
		sqlFinal[2]=cuadroTexto2.getText();
		sqlFinal[3]=cuadroTexto3.getText();
		sqlFinal[4]=cuadroTextoplazod.getText();
		sqlFinal[5]=cuadroTextoplazof.getText();
	
		sqlFinal[6]= (String)jcomboboxConmvenio.getSelectedItem();
		
		if((boolean)callScript("Scripts.Login"))
			callScript("Creacion_Plan.Controlador.Crear_Plan",  sqlFinal);
	
	}
	
	/**
	 * 
	 * *EVENTOS
	 * 
	 **/
	
	public void actionPerformed(ActionEvent e){
		
		if ("tasaEstandarD".equals(e.getActionCommand())){
			titulo.setVisible(true);
			cuadroTexto.setVisible(true);
		}
		if ("tasaModificableD".equals(e.getActionCommand())){
			titulo.setVisible(false);
			cuadroTexto.setVisible(false);
		}
		if ("desplafijo".equals(e.getActionCommand())){
			
			tituloplazod.setVisible(true);
			cuadroTextoplazod.setVisible(true);
		}
		if ("desplaabierto".equals(e.getActionCommand())){
			
			tituloplazod.setVisible(false);
			cuadroTextoplazod.setVisible(false);		
		}
		
		//------------------------------------------------------------------------------------------------
		if ("tasaEstandarF".equals(e.getActionCommand())){
			
			titulo2.setVisible(true);
			cuadroTexto2.setVisible(true);
		}
		if ("tasaModificableF".equals(e.getActionCommand())){
			
			titulo2.setVisible(false);
			cuadroTexto2.setVisible(false);
		}
		
		if ("finafijo".equals(e.getActionCommand())){
			
			tituloplazof.setVisible(true);
			cuadroTextoplazof.setVisible(true);
		}
		if ("finaabierto".equals(e.getActionCommand())){
			
			tituloplazof.setVisible(false);
			cuadroTextoplazof.setVisible(false);
		}
		if ("allconvenios".equals(e.getActionCommand())){
			
			jcomboboxConmvenio.removeAllItems();
			
			if(jRadioButtonConvenio.isSelected())
			{
				String[] provicional2 = ObtenerConvenios(true);
				
				for(int i = 0; i<provicional2.length; i++)
					jcomboboxConmvenio.addItem(provicional2[i]);
			}
			if(!jRadioButtonConvenio.isSelected())
			{
				String[] provicional2 = ObtenerConvenios(false);
	
				for(int i = 0; i<provicional2.length; i++)
					jcomboboxConmvenio.addItem(provicional2[i]);
			}
		}
		//EVENTO DEL BOTON FILTRAR
		if ("AccionBotonfiltrar".equals(e.getActionCommand())){
			
			int faltante = 0;
			if(jcomboboxConmvenio.getSelectedIndex()==0){
				JOptionPane.showMessageDialog(null, "SELECCIONE EL CONVENIO QUE ADQUIRIRA EL PLAN", "Error", JOptionPane.ERROR_MESSAGE);
				faltante++;
			}
				
			if(jcomboboxDescuento.getSelectedIndex()==0){
				JOptionPane.showMessageDialog(null, "SELECCIONE TIPO DE TASA DESCUENTO", "Error", JOptionPane.ERROR_MESSAGE);
				faltante++;
			}
				
			if(jcomboboxFinanciacion.getSelectedIndex()==0){
				JOptionPane.showMessageDialog(null, "SELECCIONE TIPO DE TASA FINANCIACION", "Error", JOptionPane.ERROR_MESSAGE);
				faltante++;
			}
				
			if(jcomboboxSegmento.getSelectedIndex()==0){
				JOptionPane.showMessageDialog(null, "SELECCIONE SEGMENTO DE CREDITO", "Error", JOptionPane.ERROR_MESSAGE);
				faltante++;
			}
			if(jcomboboxDescuento.getSelectedIndex()!=3 && jRadioButtonCondicionTD.isSelected())
			{
				if(cuadroTexto.getText().equals("")){
					JOptionPane.showMessageDialog(null, "INGRESE LA TASA DE DESCUENTO", "Error", JOptionPane.ERROR_MESSAGE);
					faltante++;
				}
			}
			if(jcomboboxDescuento.getSelectedIndex()!=3 && jRadioButtonTipoPlazoD.isSelected())
			{
				if(cuadroTextoplazod.getText().equals("")){
					JOptionPane.showMessageDialog(null, "INGRESE PLAZO DESCUENTO", "Error", JOptionPane.ERROR_MESSAGE);
					faltante++;
				}
			}
			if(jcomboboxFinanciacion.getSelectedIndex()!=3 && jRadioButtonCondicionTF.isSelected())
			{
				if(cuadroTexto2.getText().equals("")){
					JOptionPane.showMessageDialog(null, "INGRESE LA TASA DE FINANCIACION", "Error", JOptionPane.ERROR_MESSAGE);
					faltante++;
				}
			}	
			if(jcomboboxFinanciacion.getSelectedIndex()!=3 && jRadioButtonTipoPlazoF.isSelected())
			{
				if(cuadroTextoplazof.getText().equals("")){
					JOptionPane.showMessageDialog(null, "INGRESE PLAZO FINANCIACION", "Error", JOptionPane.ERROR_MESSAGE);
					faltante++;
				}
			}	
			if(cuadroTexto3.getText().equals("")){
				JOptionPane.showMessageDialog(null, "AGREGAR CANTIDAD O (*) PARA EJECUTAR TODOS LOS CASO DE PRUEBA DISPONIBLES", "Error", JOptionPane.ERROR_MESSAGE);
				faltante++;
			}
			
			//VALIDA QUE SE HALLAN ESCOJIDO TODAS LA VARIABLES QUE IDENTIFICAN EL CASO DE PRUEBA 
			if(faltante==0)
			{
				sql = "SELECT * " +
						"FROM CasoPrueba_Plan " +
						"WHERE Segmento = '" + (String)jcomboboxSegmento.getSelectedItem() + "' AND " +
								"TipoTasa_DSCTO = '" + (String)jcomboboxDescuento.getSelectedItem() + "' AND " +
								"TipoTasa_Financiacion = '" + (String)jcomboboxFinanciacion.getSelectedItem() + "'";
				
				if(jcomboboxDescuento.getSelectedIndex()==3)
					sql = sql + "AND CondicionTasa_DSCTO = '' AND TipoPLazo_DSCTO = ''";
				else
				{
					if(jRadioButtonCondicionTD.isSelected())
						sql = sql + "AND CondicionTasa_DSCTO = 'Est�ndar' ";
					else
						sql = sql + "AND CondicionTasa_DSCTO = 'Modificable' ";
					
					if(jRadioButtonTipoPlazoD.isSelected())
						sql = sql + "AND TipoPLazo_DSCTO = 'Fijo' ";
					else 
						sql = sql + "AND TipoPLazo_DSCTO = 'Abierto' ";
				}
				//-----------------------------------------------------------------------------
				if(jcomboboxFinanciacion.getSelectedIndex()==3)
					sql = sql + "AND ModoTasa_Financiacion = '' AND TipoPLazoFinanciacion = ''";
				else
				{
					if(jRadioButtonCondicionTF.isSelected())
						sql = sql + "AND ModoTasa_Financiacion = 'Est�ndar' ";
					else
						sql = sql + "AND ModoTasa_Financiacion = 'Modificable' ";
					
					if(jRadioButtonTipoPlazoF.isSelected())
						sql = sql + "AND TipoPLazoFinanciacion = 'Fijo' ";
					else 
						sql = sql + "AND TipoPLazoFinanciacion = 'Abierto' ";
				}
					
			}					
				
		}
	}
	public void itemStateChanged(ItemEvent e) {
		
		if(jcomboboxDescuento.getSelectedIndex()!=3 && jcomboboxDescuento.getSelectedIndex()!=0)
		{
			jRadioButtonCondicionTD.setVisible(true);
			jRadioButtonCondicionTD2.setVisible(true);
			jRadioButtonTipoPlazoD.setVisible(true);
			jRadioButtonTipoPlazoD2.setVisible(true);
			titulo.setVisible(true);
			cuadroTexto.setVisible(true);
			tituloplazod.setVisible(true);
			cuadroTextoplazod.setVisible(true);
		}
		if(jcomboboxDescuento.getSelectedIndex()==3)
		{
			jRadioButtonCondicionTD.setVisible(false);
			jRadioButtonCondicionTD2.setVisible(false);
			jRadioButtonTipoPlazoD.setVisible(false);
			jRadioButtonTipoPlazoD2.setVisible(false);
			titulo.setVisible(false);
			cuadroTexto.setVisible(false);
			tituloplazod.setVisible(false);
			cuadroTextoplazod.setVisible(false);
		}
	//--------------------------------------------------------------------------------------------------	
		if(jcomboboxFinanciacion.getSelectedIndex()!=3 && jcomboboxFinanciacion.getSelectedIndex()!=0)
		{
			jRadioButtonCondicionTF.setVisible(true);
			jRadioButtonCondicionTF2.setVisible(true);
			jRadioButtonTipoPlazoF.setVisible(true);
			jRadioButtonTipoPlazoF2.setVisible(true);
			titulo2.setVisible(true);
			cuadroTexto2.setVisible(true);
			tituloplazof.setVisible(true);
			cuadroTextoplazof.setVisible(true);
		}
		if(jcomboboxFinanciacion.getSelectedIndex()==3)
		{
			jRadioButtonCondicionTF.setVisible(false);
			jRadioButtonCondicionTF2.setVisible(false);
			jRadioButtonTipoPlazoF.setVisible(false);
			jRadioButtonTipoPlazoF2.setVisible(false);
			titulo2.setVisible(false);
			cuadroTexto2.setVisible(false);
			tituloplazof.setVisible(false);
			cuadroTextoplazof.setVisible(false);
		}
	}
	
	public String[] ObtenerConvenios(Boolean all){
		
		ConnecionDB();
		listaConvenios = new ArrayList<String>();
		ResultSet resultado;
		
		if(all==true)
		{
			resultado=Consulta("SELECT No_Convenio " + 
					"FROM Convenio " +
					"WHERE Estado_convenio = 'CREADO/APROBADO'");
		}
		else
		{
			resultado=Consulta("SELECT No_Convenio " +
								"FROM Convenio " +
								"WHERE Estado_convenio = 'CREADO/APROBADO' " +
								"AND No_Convenio NOT IN (SELECT No_Convenio FROM Cliente_Con_Convenio)");
		}
		try {
			listaConvenios.add("Escojer connvenio para asociar");
			while(resultado.next())
			{
				No_Convenio = resultado.getString(1);
				listaConvenios.add(No_Convenio);
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		listaConvenios.add("Aplicar a Todos");
		String[] provicional = new String[listaConvenios.size()];	
				
		for (int i = 0; i < listaConvenios.size(); i++) {
			provicional[i] = listaConvenios.get(i);
		}
		
		return provicional;
	}
}

