package Lanzadores;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import resources.Lanzadores.G_Relacion_ClienteConvenioHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class G_Relacion_ClienteConvenio extends G_Relacion_ClienteConvenioHelper implements ActionListener, ItemListener
{
	/**
	 *
	 * @since  2015/11/12
	 * @author GORTEG1
	 * 
	 */
	
	JFrame frame;
	JPanel panel1;
	Container contenedor;
	JButton jbuttonAsociar;
	
	String[] listafinal = new String[4];
	String documentoCliente, tipoDocumentoCliente, sql;
	JComboBox<String> jComboBoxClientes, jComboBoxCovenios, jComboBoxPlan;
	JRadioButton jRadioButtonPropuestos;
	JLabel jlabelConvenio, jlabelCliente, jlabelPlan;
	JTextField  jtextFileCupoGlogal;
	
	public void testMain(Object[] args) 
	{
		frame = new JFrame("RELACION CLIENTE CONVENIO");
		contenedor = new Container();
		ConnecionDB();
		
		//JRADIOBUTTON PARA ESCOJER QUE CLIENTES SE NECESITAN 
		jRadioButtonPropuestos = new JRadioButton("Sin Proponer", false);
		jRadioButtonPropuestos.setVisible(true);
		jRadioButtonPropuestos.addActionListener(this);
		jRadioButtonPropuestos.setMnemonic(KeyEvent.VK_D);
		jRadioButtonPropuestos.setActionCommand("Propuestos");
				
		//JBUTTON AGREGAR CLIENTE Y BOTTON O CAPTURAR CUPO
		jbuttonAsociar = new JButton("AGREGAR CLIENTE");
		jbuttonAsociar.addActionListener(this);
		jbuttonAsociar.setMnemonic(KeyEvent.VK_D);
		jbuttonAsociar.setActionCommand("agregarCliente");
			
		//COMBOBOX 
		jComboBoxCovenios = new JComboBox();
		jComboBoxCovenios.setVisible(true);
		jComboBoxCovenios.addItemListener(this);
		jComboBoxClientes = new JComboBox();
		jComboBoxClientes.setEditable(true);
		jComboBoxPlan = new JComboBox();
		jComboBoxPlan.setVisible(true);
				
		ResultSet resultadoConvenios= Consulta("SELECT No_Convenio, Nombre_Convenio " + 
													"FROM Convenio " +
														"WHERE No_Convenio IN " +
															"(SELECT No_Convenio " +
																"FROM Cliente_Con_Convenio " +
																"WHERE Estado = 'PROPUESTO')");
		
		try {
			while(resultadoConvenios.next())
				jComboBoxCovenios.addItem(resultadoConvenios.getString(1));
		}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}			
		
		ResultSet resultadoClientes= Consulta("SELECT No_Documento " +
												"FROM  Cliente_Con_Convenio " +
													"WHERE No_Convenio = '"+ jComboBoxCovenios.getSelectedItem() + "'");
		
		
		ResultSet resultadoPlanes= Consulta("SELECT No_Plan " +
												"FROM  PlanFinanciero " +
													"WHERE No_Convenio = '"+ jComboBoxCovenios.getSelectedItem() + "'" +
													" AND Estado_Plan = 'CREADO/APROBADO'");
		
		try {
			while(resultadoClientes.next())
				jComboBoxClientes.addItem(resultadoClientes.getString(1));
			while(resultadoPlanes.next())
				jComboBoxPlan.addItem(resultadoPlanes.getString(1));
		} catch (SQLException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
			
		//jComboBoxLineaCredito = new JComboBox(listaLineaCredito);
		jComboBoxPlan.setVisible(true);
		
		//LABELS O ETIQUETAS
		
		jlabelConvenio = new JLabel("Convenio ");
		jlabelConvenio.setVisible(true);
		jlabelCliente = new JLabel("Cliente");
		jlabelCliente.setVisible(true);
		jlabelPlan = new JLabel("Plan");
		jlabelPlan.setVisible(true);
		
				
		//BOTONES
		jbuttonAsociar = new JButton("ASOCIAR");
		jbuttonAsociar.addActionListener(this);
		jbuttonAsociar.setMnemonic(KeyEvent.VK_D);
		jbuttonAsociar.setActionCommand("Asociar");
				
		//PANELES Y CONTENEDORES 
		panel1 = new JPanel();
		panel1.setBorder(BorderFactory.createTitledBorder("RELACIONAR"));
		panel1.setLayout(new GridLayout(4,2));
		panel1.add(jlabelConvenio);
		panel1.add(jComboBoxCovenios);
		panel1.add(jlabelCliente);
		panel1.add(jComboBoxClientes);
		panel1.add(jlabelPlan);
		panel1.add(jComboBoxPlan);
		panel1.add(jRadioButtonPropuestos);
		panel1.add(jbuttonAsociar);
							
		
		frame.add(panel1);
		frame.setSize(300, 150);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(1);
		
		sql = "";
		while(sql.equals("")){
			Espera(1);
		}
		listafinal[0] = (String)jComboBoxCovenios.getSelectedItem();
		listafinal[1] = tipoDocumentoCliente;
		listafinal[2] = (String)jComboBoxClientes.getSelectedItem();
		listafinal[3] = (String)jComboBoxPlan.getSelectedItem();
		
				
		if((boolean)callScript("Scripts.Login"))
			callScript("Asociar_Cliente_Convenio.Controlador.Asociar_ClienteConvenio",  listafinal);
	}
	
	/**
	 * 
	 * EVENTOS
	 * 
	 */
	
	//ACCION DE BOTON Y JRADIOBUTTON
	public void actionPerformed(ActionEvent e){
		
		//ACCION DEL BOTON CAPTURAR CUPO
		if ("Propuestos".equals(e.getActionCommand())){
			
			jComboBoxCovenios.removeAllItems();
			jComboBoxClientes.removeAllItems();
			jComboBoxPlan.removeAllItems();
			
			if(jRadioButtonPropuestos.isSelected()){
				
				ResultSet resultadoConvenios= Consulta("SELECT No_Convenio, Nombre_Convenio " +
															"FROM Convenio " +
																"WHERE Estado_convenio = 'CREADO/APROBADO'");
				
				try {
					while(resultadoConvenios.next())
						jComboBoxCovenios.addItem(resultadoConvenios.getString(1));
				} catch (SQLException e1) {
					// TODO Bloque catch generado autom�ticamente
					e1.printStackTrace();
				}
			}
			else{
				
				ResultSet resultadoConvenios= Consulta("SELECT No_Convenio, Nombre_Convenio " + 
						"FROM Convenio " +
							"WHERE No_Convenio IN " +
								"(SELECT No_Convenio " +
									"FROM Cliente_Con_Convenio)");

				try {
					while(resultadoConvenios.next())
						jComboBoxCovenios.addItem(resultadoConvenios.getString(1));
				}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}			
			}
		}
				
		ResultSet resultado2 = Consulta("SELECT No_Documento, Tipo_Documento " +
								"FROM Cliente " +
								"WHERE No_Documento = '" + jComboBoxClientes.getSelectedItem() + "'");
		try {
			while(resultado2.next()){
				
				documentoCliente = resultado2.getString(1);
				tipoDocumentoCliente = resultado2.getString(2);
				
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
		
		if ("Asociar".equals(e.getActionCommand())){
			System.out.println("Estra");
			sql = "Ok";
		}
		
	}
	
	//ACCION DE MODIFICACION EN LISTAS
	public void itemStateChanged(ItemEvent e) {
		
		jComboBoxClientes.removeAllItems();
		jComboBoxPlan.removeAllItems();
				
		ResultSet resultadoClientes= Consulta("SELECT No_Documento " +
				"FROM  Cliente_Con_Convenio " +
					"WHERE No_Convenio = '"+ jComboBoxCovenios.getSelectedItem() + "'");


		ResultSet resultadoPlanes= Consulta("SELECT No_Plan " +
				"FROM  PlanFinanciero " +
				"WHERE No_Convenio = '"+ jComboBoxCovenios.getSelectedItem() + "'" +
				" AND Estado_Plan = 'CREADO/APROBADO'");

		try {
			while(resultadoClientes.next())
				jComboBoxClientes.addItem(resultadoClientes.getString(1));
			while(resultadoPlanes.next())
				jComboBoxPlan.addItem(resultadoPlanes.getString(1));
		} catch (SQLException f) {
			// TODO Bloque catch generado autom�ticamente
			f.printStackTrace();
			}
				
		if(jComboBoxClientes.getItemCount()==0 && jRadioButtonPropuestos.isSelected())
		{
			ResultSet resultadoClientesTotales= Consulta("SELECT No_Documento " +
															"FROM  Cliente ");
			
				try {
					while(resultadoClientesTotales.next())
						jComboBoxClientes.addItem(resultadoClientesTotales.getString(1));
				} catch (SQLException e1) {
					// TODO Bloque catch generado autom�ticamente
					e1.printStackTrace();
				}
			
		}
			
	}
	
	
}
