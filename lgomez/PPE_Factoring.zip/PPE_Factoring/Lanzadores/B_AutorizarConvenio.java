package Lanzadores;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import resources.Lanzadores.B_AutorizarConvenioHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class B_AutorizarConvenio extends B_AutorizarConvenioHelper implements ActionListener
{
	/**
	 * Script Name   : <b>AutorizarConvenio</b>
	 * Generated     : <b>15/09/2015 10:10:06</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/09/15
	 * @author GORTEG1
	 */
	
	JFrame frame;
	String No_Convenio, Nombre_Convenio, esperarAccion;
	ArrayList<String> listaConvenios;
	JComboBox desplegableConvenios;
	String[] listaConvenios2, listaConvenios3;
	JRadioButton radioButtonAutorizar, radioButtonDevolver;
	ButtonGroup grupoAccion;
	private JPanel panelCentral;
	private JButton jbuttonAutorizar;
	
	public void testMain(Object[] args)
	{
		frame = new JFrame("AUTORIZAR CONVENIOS");
		listaConvenios = new ArrayList<String>();
		
		ConnecionDB();
		ResultSet resultado =Consulta("SELECT No_Convenio, Nombre_Convenio " + 
										"FROM [BD_AUT_Factoring].[dbo].[Convenio] " + 
											"WHERE Estado_convenio = 'CREADO'");
		
		
			try {
				while(resultado.next()){
					
					No_Convenio = resultado.getString(1);
					Nombre_Convenio = resultado.getString(2);
					
					listaConvenios.add(No_Convenio);
				}
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
		
		listaConvenios2 = new String[listaConvenios.size()+1];
		
		for (int i = 0; i < listaConvenios.size(); i++) {
			listaConvenios2[i] = listaConvenios.get(i);
		}
		listaConvenios2[listaConvenios.size()]= "Autorizar todos los convenios";
		
		desplegableConvenios = new JComboBox(listaConvenios2);
		desplegableConvenios.setEditable(true);
		desplegableConvenios.setSelectedItem("Seleccione nombre del convenio");
		
		radioButtonAutorizar = new JRadioButton("Autorizar", false);
		radioButtonDevolver = new JRadioButton("Devolver", false);
		radioButtonAutorizar.setVisible(true);
		radioButtonDevolver.setVisible(true);
		grupoAccion = new ButtonGroup();
		grupoAccion.add(radioButtonAutorizar);
		grupoAccion.add(radioButtonDevolver);
			
		
		jbuttonAutorizar = new JButton("EJECUTAR");
		jbuttonAutorizar.addActionListener(this);
		jbuttonAutorizar.setMnemonic(KeyEvent.VK_D);
		jbuttonAutorizar.setActionCommand("auto");
				
		panelCentral = new JPanel();
		panelCentral.add(desplegableConvenios);
		panelCentral.add(radioButtonAutorizar);
		panelCentral.add(radioButtonDevolver);
		panelCentral.add(jbuttonAutorizar);
		
		frame.add(panelCentral, BorderLayout.CENTER);
		frame.setSize(400, 150);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(1);
		
		//  Condicional que no permite que se cierre el JFrame
		esperarAccion = "";
		while(esperarAccion.equals("")){
			Espera(1);
		}
		
		listaConvenios3 = new String[3];
		listaConvenios3[0]="Nombreconvenio";
		listaConvenios3[2]=(String)desplegableConvenios.getSelectedItem();
		
		if(radioButtonAutorizar.isSelected())
			listaConvenios3[1]="Autorizar";
		else
			listaConvenios3[1]="Devolver";
		
		if((boolean)callScript("Scripts.Login"))
			callScript("Autorizacion_Convenios.Controlador.Autorizar_Convenio",  listaConvenios3);
		
		
	}	
	
	public void actionPerformed(ActionEvent e){
			
		
	       // Click en botton autorizar
			if ("auto".equals(e.getActionCommand())){
				if(desplegableConvenios.getSelectedIndex()>-1){
					esperarAccion = "OK";
				}
				else
					JOptionPane.showMessageDialog(null, "SELECCIONE EL CONVENIO QUE DESEA AUTORIZAR", "Error", JOptionPane.ERROR_MESSAGE);
				
	        }
	}
}

