package Lanzadores;
import resources.Lanzadores.A_CrearConvenioHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;


import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;



import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.xml.bind.Marshaller.Listener;
/**
 * Description   : Functional Test Script
 * @author Gorteg1
 */
public class A_CrearConvenio extends A_CrearConvenioHelper implements ActionListener, ItemListener
{
	/**
	 * Script Name   : <b>GenerarConvenio</b>
	 * Generated     : <b>09/09/2015 15:19:36</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2015/09/09
	 * @author Gorteg1
	 */
	JFrame frame;
	Container contenedor, contenedor2;
	private JButton filtrar, cancelar;
	JComboBox listaLinea, listaFormaDes;
	ButtonGroup grupoDesembolso, grupoCargo;
	JRadioButton ahorros, corrientes, ahorros2, corrientes2, cargoCuenta, tipoFront; 
	Label tipoCuentaDesembolso, tipoCuentaCargo;
	JTextField textFile_Cantidad;
	private JPanel panel1, panel2, panel3, panel4;
	int accion;
	String sql, frontBOT;
	String[] listaElementosLinea, listaElementosForma, sqlFinal;
	
	public void testMain(Object[] args) 
	{
		frame = new JFrame("FILTRAR CASOS DE PRUEBA CONVENIOS");
		contenedor = new Container();
		contenedor2 = new Container();
		frontBOT ="False";
		
		//INFORMACION Y DESPLIEGUE COMBOBOX
		listaElementosLinea = new String[11];
		listaElementosLinea[0]= "26-Factoring sin recurso";
		listaElementosLinea[1]= "27-Factoring con recurso";
		listaElementosLinea[2]= "602-Convenios C variable hasta 60 meses";
		listaElementosLinea[3]= "603-Convenio CEMEX Cuota Unica";
		listaElementosLinea[4]= "605-Convenios C Fija hasta  60 meses";
		listaElementosLinea[5]= "612-Pago a proveedores";
		listaElementosLinea[6]= "613-Pago a proveedores con financiaci�n";
		listaElementosLinea[7]= "614-Anticipo de Facturas";
		listaElementosLinea[8]= "615-Descuento Proveedores";
		listaElementosLinea[9]= "616-Financiancion a Compradores";
		listaElementosLinea[10]= "ALL                                                                                            ";
		
		listaElementosForma = new String[3];
		listaElementosForma[0]= "Cheque";
		listaElementosForma[1]= "Cuenta Contable         ";
		listaElementosForma[2]= "Abono a Cuenta";
		
		listaLinea = new JComboBox(listaElementosLinea);
		listaLinea.setEditable(true);
		listaLinea.setSelectedItem("Linea de credito");
		listaLinea.addItemListener(this);
		
		listaFormaDes = new JComboBox(listaElementosForma);
		listaFormaDes.setEditable(true);
		listaFormaDes.setSelectedItem("Forma Desembolso");
		listaFormaDes.addItemListener(this);
		
		//RADIOBUTTON
		ahorros = new JRadioButton("Cuenta de Ahorros  ", false);
		corrientes = new JRadioButton("Cuenta Corriente", false);
		ahorros.setVisible(false);
		corrientes.setVisible(false);
		ahorros2 = new JRadioButton("Cuenta de Ahorros  ", false);
		corrientes2 = new JRadioButton("Cuenta de Corriente", false);
		cargoCuenta = new JRadioButton("Cargo Cuenta", false);
		cargoCuenta.addActionListener(this);
		cargoCuenta.setMnemonic(KeyEvent.VK_D);
		cargoCuenta.setActionCommand("disable");
		cargoCuenta.setVisible(true);
		ahorros2.setVisible(false);
		corrientes2.setVisible(false);
		tipoFront = new JRadioButton("Tipo Front BOT", false);
		tipoFront.setVisible(true);
		
		grupoDesembolso = new ButtonGroup();
		grupoCargo = new ButtonGroup();
		grupoDesembolso.add(ahorros);
		grupoDesembolso.add(corrientes);
		grupoCargo.add(ahorros2);
		grupoCargo.add(corrientes2);

		
		//LABEL - ETIQUETAS 
		tipoCuentaDesembolso = new Label("                            TIPO CUENTA DESEMBOLSO                                  ");
		tipoCuentaDesembolso.setVisible(false);
		tipoCuentaCargo = new Label("                                 TIPO CUENTA CARGO                                       ");
		tipoCuentaCargo.setVisible(false);
		textFile_Cantidad = new JTextField(10);
		
		//BUTTON
		filtrar = new JButton("EJECUTAR");
		filtrar.addActionListener(this);
		filtrar.setMnemonic(KeyEvent.VK_D);
		filtrar.setActionCommand("filtrar");
		cancelar = new JButton("CANCELAR");
		cancelar.addActionListener(this);
		cancelar.setMnemonic(KeyEvent.VK_D);
		cancelar.setActionCommand("cancelar");		
		
		//PANEL CENTRAL 
		panel1 = new JPanel();
		panel1.setBorder(BorderFactory.createTitledBorder("CREAR CONVENIO"));
		panel1.add(listaLinea);
		panel1.add(new JLabel("       Cantidad:"));
		panel1.add(textFile_Cantidad);
		//panel1.add(tipoCuentaDesembolso);
		//panel1.add(tipoCuentaCargo);
		panel1.add(tipoFront);
		
		
		//PANEL INFERIOR 
		panel2 = new JPanel();
		panel2.setBorder(BorderFactory.createTitledBorder("CARGO CUENTA"));
		panel2.add(cargoCuenta);
		panel2.add(ahorros2);
		panel2.add(corrientes2);
		
		
		panel3 = new JPanel();
		panel3.setBorder(BorderFactory.createTitledBorder("CUENTA DESEMBOLSO"));
		panel3.add(listaFormaDes);
		panel3.add(ahorros);
		panel3.add(corrientes);
		
		panel4 = new JPanel();
		panel4.add(filtrar);
		panel4.add(cancelar);
		
		contenedor.setLayout(new GridLayout(2,1));
		contenedor.add(panel1);
		contenedor.add(contenedor2);
		
		contenedor2.setLayout(new GridLayout(1,2));
		contenedor2.add(panel3);
		contenedor2.add(panel2);
		
		//PANEL CONTENEDOR
		frame.add(contenedor, BorderLayout.CENTER);
		frame.add(panel4, BorderLayout.SOUTH);
		frame.setSize(400, 300);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(1);
		
		sql = "";
		while(sql.equals("")){
			Espera(1);
		}
		sqlFinal = new String[3];
		sqlFinal[0]=sql;
		sqlFinal[1]=textFile_Cantidad.getText();
		sqlFinal[2]=frontBOT;
		
		callScript("Creacion_Convenios.Controlador.Crear_Convenio",  sqlFinal);
	}
	
	public void actionPerformed(ActionEvent e){
	       // Set enabled based on button text (you can use whatever text you prefer)
			if ("disable".equals(e.getActionCommand())){
	            if(cargoCuenta.isSelected()){
	            	ahorros2.setVisible(true);
	            	corrientes2.setVisible(true);
	            }
	            else{
	            	ahorros2.setVisible(false);
	            	corrientes2.setVisible(false);
	            }
	        }
			else if("filtrar".equals(e.getActionCommand())){
				
				if(tipoFront.isSelected())
					frontBOT = "True";
				if(textFile_Cantidad.getText().equals("")){
					JOptionPane.showMessageDialog(null, "AGREGAR CANTIDAD O (*) PARA EJECUTAR TODOS LOS CASO DE PRUEBA DISPONIBLES)", "Error", JOptionPane.ERROR_MESSAGE);
				}
				else
				{
					if(listaLinea.getSelectedIndex()>-1){
						if(listaFormaDes.getSelectedIndex()>-1){
							if(listaFormaDes.getSelectedIndex()==2)
							{
								if (ahorros.isSelected())
								{
									if(listaLinea.getSelectedIndex()==10)
										sql = "WHERE Forma_Desembolso = '" + (String)listaFormaDes.getSelectedItem() + "' AND TipoCuenta_Desembolso = 'Cuenta de Ahorros'";
									else
										sql = "WHERE Linea_Credito = '"+ (String)listaLinea.getSelectedItem() + "' AND Forma_Desembolso = '" + (String)listaFormaDes.getSelectedItem() + "' AND TipoCuenta_Desembolso = 'Cuenta de Ahorros'";
								}
									
								else
								{
									if(listaLinea.getSelectedIndex()==10)
										sql = "WHERE Forma_Desembolso = '" + (String)listaFormaDes.getSelectedItem() + "' AND TipoCuenta_Desembolso = 'Cuenta Corriente'";
									else
										sql = "WHERE Linea_Credito = '"+ (String)listaLinea.getSelectedItem() + "' AND Forma_Desembolso = '" + (String)listaFormaDes.getSelectedItem() + "' AND TipoCuenta_Desembolso = 'Cuenta Corriente'";
								}
									
							}
							else
							{
								if(listaLinea.getSelectedIndex()==10)
									sql = "WHERE Forma_Desembolso = '" + (String)listaFormaDes.getSelectedItem() + "' AND TipoCuenta_Desembolso = ''";
								else
									sql = "WHERE Linea_Credito = '"+ (String)listaLinea.getSelectedItem() + "'AND Forma_Desembolso = '" + (String)listaFormaDes.getSelectedItem() + "' AND TipoCuenta_Desembolso = ''";
							}
								
							
							if(cargoCuenta.isSelected())
							{
								if (ahorros2.isSelected()) 
									sql = sql +" AND " + "TipoCuenta_Cargo = 'Cuenta de Ahorros'";
								else
									sql = sql +" AND " + "TipoCuenta_Cargo = 'Cuenta Corriente'";
							}
							else
								sql = sql +" AND " + "TipoCuenta_Cargo = ''";
							
								sql = "SELECT * FROM CasoPrueba_Convenios " + sql;

						}
						else
							JOptionPane.showMessageDialog(null, "SELECCIONE FORMA DE DESEMBOLSO", "Error", JOptionPane.ERROR_MESSAGE);
					}
					else 
						JOptionPane.showMessageDialog(null, "SELECCIONE LINEA DE CREDITO", "Error", JOptionPane.ERROR_MESSAGE);
					
				}
			} 
			else 
				System.exit( 0 ); 

	    }

		 public void itemStateChanged(ItemEvent e) {
			 
			 if(listaFormaDes.getSelectedIndex()==2){
				 tipoCuentaDesembolso.setVisible(true);
				 ahorros.setVisible(true);
				 corrientes.setVisible(true);
			 }
			 if(listaFormaDes.getSelectedIndex()!=2){
				 tipoCuentaDesembolso.setVisible(false);
				 ahorros.setVisible(false);
				 corrientes.setVisible(false);
			 }
			 	cargoCuenta.setVisible(true);
				tipoCuentaCargo.setVisible(true);
		 }
		
}

