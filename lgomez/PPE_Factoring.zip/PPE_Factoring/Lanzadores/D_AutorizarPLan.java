package Lanzadores;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import resources.Lanzadores.D_AutorizarPLanHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class D_AutorizarPLan extends D_AutorizarPLanHelper implements ActionListener, ItemListener
{
	/**
	 * @since  2015/10/08
	 * @author GORTEG1
	 */
	JFrame frame;
	JPanel panel1, panel2;
	Container contenedor, contenedor2;
	JButton botonaFitrar, botonCancelar;
	String[] listaConvenios, listaPlanes, listaplanesAux, sqlFinal;
	String No_Convenio, Nombre_Convenio, convenioEscojido, planEscojido, numeroPlan, sql;
	ArrayList<String> arrayListaNoCovenio, arrayListaPlanes;
	JComboBox<String> jComboBoxConvenios, jComboBoxPlanes;
	JRadioButton jRadioButtonAutorizar, jRadioButtonDevolver, jRadioButtonTodos;
	ButtonGroup grupoAccion;
	
	public void testMain(Object[] args) 
	{
		frame = new JFrame("AUTORIZAR PLANES");
		contenedor = new Container();
		contenedor2 = new Container();
		
		arrayListaNoCovenio = new ArrayList<String>();
		
		ConnecionDB();
		ResultSet resultado = Consulta("SELECT No_Convenio, Nombre_Convenio " + 
										"FROM Convenio WHERE Estado_convenio = 'CREADO/APROBADO' " +
										"AND No_Convenio IN(SELECT No_Convenio FROM PlanFinanciero)");
		
		try {
			while(resultado.next()){
				
				No_Convenio = resultado.getString(1);
				arrayListaNoCovenio.add(No_Convenio);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		listaConvenios = new String[arrayListaNoCovenio.size()+1];
		for (int i = 0; i < arrayListaNoCovenio.size(); i++) {
			listaConvenios[i] = arrayListaNoCovenio.get(i);
		}
		
		jComboBoxConvenios = new JComboBox(listaConvenios);
		jComboBoxConvenios.setEditable(true);
		jComboBoxConvenios.setSelectedItem("Seleccione el convenio");
		jComboBoxConvenios.addItemListener(this);
		
		listaplanesAux = new String[1];
		listaplanesAux[0] = "Escojer Plan";
		jComboBoxPlanes = new JComboBox(listaplanesAux);
		jComboBoxPlanes.setEditable(true);
		//jComboBoxPlanes.setSelectedItem(0);
		
		jRadioButtonAutorizar = new JRadioButton("Autorizar", false);
		jRadioButtonDevolver = new JRadioButton("Devolver", false);
		jRadioButtonAutorizar.setVisible(true);
		jRadioButtonDevolver.setVisible(true);
		grupoAccion = new ButtonGroup();
		grupoAccion.add(jRadioButtonAutorizar);
		grupoAccion.add(jRadioButtonDevolver);
		
		jRadioButtonTodos = new JRadioButton("Todos", false);
		jRadioButtonTodos.setVisible(true);
		jRadioButtonTodos.addActionListener(this);
		jRadioButtonTodos.setMnemonic(KeyEvent.VK_D);
		jRadioButtonTodos.setActionCommand("tod");
		
		botonaFitrar = new JButton("EJECUTAR");
		botonaFitrar.addActionListener(this);
		botonaFitrar.setMnemonic(KeyEvent.VK_D);
		botonaFitrar.setActionCommand("auto");
		
		panel1 = new JPanel();
		panel1.setBorder(BorderFactory.createTitledBorder("INFORMACION DEL PLAN"));
		panel1.add(jComboBoxConvenios);
		panel1.add(jRadioButtonTodos);
		panel1.add(jComboBoxPlanes);
		panel1.add(jRadioButtonAutorizar);
		panel1.add(jRadioButtonDevolver);
		panel1.add(botonaFitrar);
		
		frame.add(panel1, BorderLayout.CENTER);
		frame.setSize(400, 150);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(1);
		
		sql = "";
		while(sql.equals("")){
			Espera(1);
		}
		sqlFinal = new String[3];
		sqlFinal[0]= convenioEscojido;
		sqlFinal[1]= planEscojido;
		
		if(jRadioButtonAutorizar.isSelected())
			sqlFinal[2]= "Autorizar";
		else
			sqlFinal[2]= "Devolver";
		
		if((boolean)callScript("Scripts.Login"))
			callScript("Autorizacion_Planes.Controlador.Autorizar_Plan",  sqlFinal);
	}
	
	/**
	 * 
	 * EVENTOS
	 * 
	 */
	
	//ACCION DE BOTON Y JRADIOBUTTON
	public void actionPerformed(ActionEvent e){
		
		if ("auto".equals(e.getActionCommand())){
			convenioEscojido = (String)jComboBoxConvenios.getSelectedItem();
			planEscojido = (String)jComboBoxPlanes.getSelectedItem();
			
			sql = "OK";
		}
		if("tod".equals(e.getActionCommand())){
			jComboBoxPlanes.removeAllItems();
			convenioEscojido = (String)jComboBoxConvenios.getSelectedItem();
			arrayListaPlanes = new ArrayList<>();
			ResultSet resultado2 = Consulta("SELECT No_Plan, No_Convenio " +
					"FROM PlanFinanciero " +
					"WHERE Estado_Plan = 'CREADO' " +
					"AND No_Convenio IN (SELECT No_Convenio FROM Convenio WHERE Estado_convenio = 'CREADO/APROBADO')");

			try {
				while(resultado2.next()){
					
					numeroPlan = resultado2.getString(1);
					arrayListaPlanes.add(numeroPlan);
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			arrayListaPlanes.add("- Autorizar Todos -");
			if(arrayListaPlanes.size()!=1){
				for (int i = 0; i < arrayListaPlanes.size(); i++) {
					jComboBoxPlanes.addItem(arrayListaPlanes.get(i));
				}
			}
		}
		
	}
	
	//ACCION DE MODIFICACION EN LISTAS
	public void itemStateChanged(ItemEvent e) {
		
		if(jComboBoxConvenios.getSelectedIndex()>=0){
			jComboBoxPlanes.removeAllItems();
			convenioEscojido = (String)jComboBoxConvenios.getSelectedItem();
			arrayListaPlanes = new ArrayList<>();
			ResultSet resultado2 = Consulta("SELECT No_Plan " +
														"FROM PlanFinanciero " +
															"WHERE Estado_Plan = 'CREADO' AND " +
															"No_Convenio = '" + convenioEscojido + "'");

			try {
				while(resultado2.next()){
					
					numeroPlan = resultado2.getString(1);
					arrayListaPlanes.add(numeroPlan);
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			arrayListaPlanes.add("Autorizar Todos");
			if(arrayListaPlanes.size()!=1){
				for (int i = 0; i < arrayListaPlanes.size(); i++) {
					jComboBoxPlanes.addItem(arrayListaPlanes.get(i));
				}
			}
			
		}
	}
	
}

