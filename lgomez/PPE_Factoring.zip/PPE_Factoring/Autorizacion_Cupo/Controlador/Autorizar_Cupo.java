package Autorizacion_Cupo.Controlador;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import resources.Autorizacion_Cupo.Controlador.Autorizar_CupoHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Autorizar_Cupo extends Autorizar_CupoHelper
{
	String[][] data;
	String[] dataVista1 = new String[2];
	String[] dataVista2 = new String[3];
	
	ArrayList<String> lista = new ArrayList<String>();
	
	public void testMain(Object[] args) 
	{
		/*
		 * 
		 * args[0] = Cupo Autorizar
		 * args[n] = Ultimo cupo Autorizar
		 * args.length -2 = Id_Cliente
		 * args.length -1 = Autorizar o Devolver
		 * 
		 */
		
//		args = new Object[14];
//		args[0] = "000 000";
//		args[1] = "001 000";
//		args[2] = "001 001";
//		args[3] = "001 002";
//		args[4] = "001 003";
//		args[5] = "001 004";
//		args[6] = "001 005";
//		args[7] = "001 006";
//		args[8] = "001 007";
//		args[9] = "001 008";
//		args[10] = "001 009";
//		args[11] = "001 010";
//		args[12] = "13200824";
//		args[13] = "Devolver";
		
		System.out.println("-*-*-*-*-**-*-*- AUTORIZAR CUPOS *-*-*-*-*-*-*-*-*");
		for (Object object : args) {
			System.out.println(object);
		}
		System.out.println("-*-*-*-*-**-*-*- AUTORIZAR CUPOS *-*-*-*-*-*-*-*-*");
		
		ConnecionDB();
		grabarArchivo("AUTORIZAR CUPO" , "Autorizacion_Cupo");
		
		if((boolean)callScript("Scripts.Login"))
			System.out.println("lOGIN");
		
		for(int i = 0; i<args.length-2; i++){
			
			if(args[i].equals("000 000"))
				AutorizarCupo((String)args[i], "Cupo Global", (String)args[args.length-2], (String)args[args.length-1]);
				
				
			else if(args[i].equals("001 000"))
				AutorizarCupo((String)args[i], "Cupo Grupo Factoring", (String)args[args.length-2], (String)args[args.length-1]);
							
			
			else
			
				AutorizarCupo((String)args[i], "Cupo Espec�fico", (String)args[args.length-2], (String)args[args.length-1]);
				
				
		}
		
		//PEQUE�O CODIGO QUE PASA LO QUE TIENE LA LISTA A UN ARREGLO BIDIMENCIONAL
		data = new String[lista.size()/4][4];
		int aux = 0;
		int aux2 = 0;
		for(int i = 0; i<lista.size(); i++){
			data[aux][aux2] = lista.get(i);
				aux2++;
				if(aux2==4){	
					aux2=0;
					aux++;
				}
		}
		createPdf("Autorizacion_Cupo");
		createPdfInforme("INFORME AUTORIZACION CUPOS", data);
	
	}
	
	public void AutorizarCupo(String cupos, String tipoCupo, String numeroId, String accion){
		
		grabarArchivo("Tipos de Cupo: " + tipoCupo , "Autorizacion_Cupo");
		grabarArchivo("Nivel del Cupo: " + cupos , "Autorizacion_Cupo");
		grabarArchivo("Cliente: " + numeroId , "Autorizacion_Cupo");
		grabarArchivo("Acci�n: " + accion , "Autorizacion_Cupo");
				
		//Vista1
		dataVista1[0] = numeroId; 
		dataVista1[1] = tipoCupo;
		callScript("Autorizacion_Cupo.Vista.Vista1_EscojerCupo", dataVista1);
		
		//Vista2
		dataVista2[0] = accion; 
		dataVista2[1] = numeroId;
		dataVista2[2] = tipoCupo;
		Object resultadoCreacion = callScript("Autorizacion_Cupo.Vista.Vista2_AutorizarCupos", dataVista2);
		String cadena = (String)resultadoCreacion;
				
			if(accion.equals("Autorizar"))
			{
				if(cadena.substring(0,27).equals("Cupo aprobado correctamente"))
				{
					lista.add(tipoCupo + "_" + cupos);
					lista.add("Cupo aprobado correctamente XXXXXXXXX");
					lista.add(cadena);
					lista.add("Exitoso");
					
					ejecutar("UPDATE Cupo " +
							"SET EstadoCupo = 'CREADO/AUTORIZADO' " +
								"WHERE No_Documento = '" + numeroId + "' AND  NivelCupo = '" + cupos + "'");
								
					ejecutar("UPDATE Cupo " +
							"SET No_CupoAsigando = '" + cadena.substring(61) +"' " +
								"WHERE No_Documento = '" + numeroId + "' AND  NivelCupo = '" + cupos + "'");
					
					ejecutar("UPDATE Cupo " +
							"SET No_CupoAsigando = '" + cadena.substring(61) +"' " +
								"WHERE No_Documento = '" + numeroId + "' AND  NivelCupo = '" + cupos + "'");
				}
				else
				{

					lista.add(tipoCupo + "_" + cupos);
					lista.add("Cupo aprobado correctamente XXXXXXXXX");
					lista.add(cadena);
					lista.add("Fallido");
				}
			}
			else
			{
				if(cadena.equals("Cupo devuelto correctamente."))
				{
					lista.add(tipoCupo + "_" + cupos);
					lista.add("Cupo devuelto correctamente.");
					lista.add(cadena);
					lista.add("Exitoso");
					
					ejecutar("UPDATE Cupo " +
							"SET EstadoCupo = 'DEVUELTO' " +
								"WHERE No_Documento = '" + numeroId + "' AND  NivelCupo = '" + cupos + "'");
				}
				else
				{
					lista.add(tipoCupo + "_" + cupos);
					lista.add("Cupo devuelto correctamente.");
					lista.add(cadena);
					lista.add("Fallido");
				}
			}
		}
}

