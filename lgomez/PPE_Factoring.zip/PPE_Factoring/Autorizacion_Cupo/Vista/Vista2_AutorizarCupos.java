package Autorizacion_Cupo.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Autorizacion_Cupo.Vista.Vista2_AutorizarCuposHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista2_AutorizarCupos extends Vista2_AutorizarCuposHelper
{
	String accion, numeroId, tipoCupo;
	RenderedImage Imagen;
	
	public String testMain(Object[] args) throws IOException 
	{
		accion = (String)args[0];
		numeroId = (String)args[1];
		tipoCupo = (String)args[2];
		
		list_aprobacionCupo(ubicacion(1), LOADED).click();
		if(accion.equals("Autorizar"))
			recorrerLista(0);
		else
			recorrerLista(1);
		
		teclado("{TAB}");
		teclado("Pruebas Automatizaci�n");
		teclado("{TAB}{TAB}");
		teclado("{ENTER}");sleep(4);
	
		if(html_mesajeRespuestaDialog(ANY, LOADED).exists() && html_mesajeRespuestaDialog(ANY, LOADED).isShowing())
		{
			String resulCreacion="";
			resulCreacion = (String)html_mesajeRespuestaDialog().getProperty(".text");
		
		
			Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
			guardarImagen(Imagen, "DatosCupo_" + numeroId + "_" +tipoCupo, "Autorizacion_Cupo");
			button_oKbutton(ubicacion(1), DEFAULT).click();sleep(1);
			teclado("{F5}");sleep(5);
			return resulCreacion;
			
		}
		else
			return "Error NO pantalla emergente";
	}
	
	public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		
	browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
	if(nivel==1)
		return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
	else
		return browser_htmlBrowser(document_autorizacionCupo(), DEFAULT);	
	}
}

