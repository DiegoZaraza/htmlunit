package Autorizacion_Cupo.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Autorizacion_Cupo.Vista.Vista1_EscojerCupoHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista1_EscojerCupo extends Vista1_EscojerCupoHelper
{
	String numeroId, tipoCupo;
	RenderedImage Imagen;
	
	public void testMain(Object[] args) throws IOException 
	{
		numeroId = (String)args[0];
		tipoCupo = (String)args[1];
		
		System.out.println(numeroId + " - " + tipoCupo);
		
		if(link_autorizarCupo(ANY, LOADED).exists() && link_autorizarCupo(ANY, LOADED).isShowing())
		{
			link_autorizarCupo().click();
			sleep(4);
		}
		else
		{
			link_factoring().click();sleep(1);	
			link_cupo().click();sleep(1);
			link_autorizarCupo().click();
			sleep(4);
		}
		
		text_htmlINPUTText().waitForExistence();
		text_htmlINPUTText(ANY, LOADED).setText(numeroId);
		text_htmlINPUTText2(ANY, LOADED).setText(tipoCupo);sleep(2);
		radioButton__0capturadoCheck(ubicacion(1), DEFAULT).click();
		button_siguientebutton(ANY, LOADED).click();sleep(3);
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, "DatosPricipales_" + numeroId + "_" +tipoCupo, "Autorizacion_Cupo");
		button_siguientebutton2().click();sleep(3);
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, "DatosCupo_" + numeroId + "_" +tipoCupo, "Autorizacion_Cupo");
		
	}
	
	public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		
	browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
	if(nivel==1)
		return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
	else
		return browser_htmlBrowser(document_autorizacionCuposBand(), DEFAULT);	
	}
}

