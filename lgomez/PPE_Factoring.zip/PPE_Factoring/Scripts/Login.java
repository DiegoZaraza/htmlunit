package Scripts;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import resources.Scripts.LoginHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;

public class Login extends LoginHelper
{  
	
	String UsuarioAutomatizador;		// Ingreso de usuario Capturador
	String ContrasenaAutomatizador;		// Ingreso de Contrase�a Usuario Capturador
	String Dominio; 
	
	
	public String consulta ="";
	FileWriter fichero = null;	
	boolean estadoLog;
	
	public boolean testMain(Object[] args) throws IOException 
	{
		ConnecionDB();
		ResultSet resultadoUsuarios = Consulta("SELECT TOP 1 * FROM UsuariosAcceso");
		
		try {
			while(resultadoUsuarios.next()){
				
				UsuarioAutomatizador = resultadoUsuarios.getString(2);
				ContrasenaAutomatizador = resultadoUsuarios.getString(3);
				Dominio = resultadoUsuarios.getString(4);
				
			}
		} catch (SQLException e) {
			// TODO Bloque catch generado autom�ticamente
			e.printStackTrace();
		}
		
		estadoLog = true;	
		
		if(link_inicio(ANY,LOADED).exists()){
			
			System.out.println("Ya esta log");
		}
		else
		{
			
			cerrarNavegadores();  //Cierra navegadores antes de la ejecuci�n
			sleep(3);
			startApp("PPE_FACTORING");	//Inicio Aplicacion PPE
			browser_htmlBrowser().maximize();
			
		}
		
		sleep(5);
		if(text_usuario(ANY, LOADED).exists() && text_usuario(ANY, LOADED).isShowing())
		{
						
			text_usuario(ANY,LOADED).setText(UsuarioAutomatizador);	// Ingresa Usuario Desembolsar
			text_fake_pass(ANY,LOADED).setText(ContrasenaAutomatizador); // Ingresa Contrase�a Desembolsar
			
			list_dominio(ANY,LOADED).select(Dominio); //Selecciona Dominio de usuarios 
			
			button_ingresarsubmit(ANY,LOADED).click(); 		// Click en Ingresar para realizar el login en la aplicacion
		
			Espera(2);
		
			// Verificacion de login exitoso si el boton button_aceptarbutton().de inicio existe 
			if (!link_inicio(ANY,LOADED).exists()){
				
				// Inserta resultado del Login en el log de RFT
				logError("El usuario "+ UsuarioAutomatizador + " No ingreso correctamente a la aplicaci�n", browser_htmlBrowser(ANY, LOADED).getScreenSnapshot());
				
				button_aceptarbutton(ANY,LOADED).click(); //Click en la ventana emergente cuando el login no es exitoso
			
				browser_htmlBrowser(ANY, LOADED).close(); // Cierra navegador
				estadoLog = false;
			}
		}
		return estadoLog;
	}	
}

