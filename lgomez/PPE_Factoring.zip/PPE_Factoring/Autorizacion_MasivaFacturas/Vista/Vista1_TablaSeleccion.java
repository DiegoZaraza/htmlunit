package Autorizacion_MasivaFacturas.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import resources.Autorizacion_MasivaFacturas.Vista.Vista1_TablaSeleccionHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista1_TablaSeleccion extends Vista1_TablaSeleccionHelper
{
	String no_Convenio, no_Documento, no_Plan;
	TestObject[] radios;
	int cantidad; //Cantidad de facturaas que se desea autorizar masivamente
	RenderedImage Imagen;
	ArrayList<String> listaFacturas = new ArrayList<String>();
	
	public String testMain(Object[] args) throws IOException 
	{
		no_Convenio = (String)args[0];
		no_Documento = (String)args[1];
		no_Plan = (String)args[2];
		cantidad = Integer.parseInt((String)args[3]);
		
		AccederFacturas();
		
		text__13200808().setText(no_Documento);
		text_htmlINPUTText().setText(no_Plan);
		text__5000272().setText(no_Convenio);
		
		//pruebas escritorio
		System.out.println(no_Documento);
		System.out.println(no_Plan);
		System.out.println(no_Convenio);
		//*****************************
		
		ITestDataTable orderTable = (ITestDataTable)table_autorizaFacturasMasivasT().getTestData("contents");
		
		for (int i = 0; i < cantidad; i++) {
			radios = table_autorizaFacturasMasivasT().find(atDescendant(".class","Html.INPUT.checkbox"));
			new GuiTestObject(radios[i]).click();
			listaFacturas.add(orderTable.getCell(i,3).toString());
		}
		
		for (Object facturas : listaFacturas) {
			grabarArchivo("Autorizacion_Factura: " + facturas, "Autorizacion_Masiva_Facturas");
		}
		
	
		button_autorizarbutton().click();
		
		try {
			html_mesajeRespuestaDialog(ANY, LOADED).waitForExistence(40, 0.5);
			
			String resulCreacion="";
			resulCreacion = (String)html_mesajeRespuestaDialog().getProperty(".text");
		
		
			Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
			guardarImagen(Imagen, "Autorizacion_Masiva", "Autorizacion_Masiva_Facturas");
			button_oKbutton().click();sleep(1);
			teclado("{F5}");sleep(5);
			return resulCreacion;
		} catch (Exception e) {
			return "Error NO pantalla emergente";
		}
	}
	
	public void teclado(String tecla){
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else 
			return browser_htmlBrowser(document_autorizacionMasivaFac(), DEFAULT);	
	}
	
	public void AccederFacturas(){
		
		if(link_autorizaci�nMasivaDeFactu(ANY, LOADED).exists() && link_autorizaci�nMasivaDeFactu(ANY, LOADED).isShowing())
		{
			link_autorizaci�nMasivaDeFactu().click();
			sleep(4);
		}
		else
		{
			try {
				
				link_factoring().click();sleep(1);	
				link_facturas().click();sleep(1);
				link_autorizaci�nMasivaDeFactu(ANY, LOADED).click();
			} catch (Exception e) {
				teclado("{F5}");sleep(3);
				AccederFacturas();
			}
		}
	}
}

