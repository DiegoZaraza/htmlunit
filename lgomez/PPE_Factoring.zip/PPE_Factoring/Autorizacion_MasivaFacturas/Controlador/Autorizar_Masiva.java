package Autorizacion_MasivaFacturas.Controlador;
import java.sql.ResultSet;
import java.sql.SQLException;

import resources.Autorizacion_MasivaFacturas.Controlador.Autorizar_MasivaHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Autorizar_Masiva extends Autorizar_MasivaHelper
{
	String  no_Convenio, no_Documento, no_Plan, id_Asociacion;
	String[] dataVista1 = new String[4]; 
	String[] dataVistaAutorizacionFacturas = new String[2];
	String[][] data;
	int cantidadFacturas = 5;
	
	public void testMain(Object[] args) 
	{
		ConnecionDB();

		
//		args = new Object[1];
//		args[0] = "true";
		
		System.out.println("-*-*-*-**-*-* Auto Masiva Factura *-*-*-*-*-*-*-*");
		for (Object object : args) {
			System.out.println(object); 
		}
		System.out.println("-*-*-*-**-*-* Auo Masiva Facturas *-*-*-*-*-*-*-*");
		
		if(args[0].equals("true")){
			ResultSet datosRelacion = Consulta("SELECT TOP 1 No_Convenio, No_Documento, No_Plan, Id_Asociacion " +
												"FROM Cliente_Con_Convenio " + 
												"WHERE Id_Asociacion IN (SELECT Id_Asociacion FROM Factura " +
												"WHERE Estado_Factura = 'CREADA' " +
												"GROUP BY Id_Asociacion HAVING COUNT(Id_Asociacion)> 9) ");
			
			try {
				while (datosRelacion.next()) 
				{
					no_Convenio = datosRelacion.getString(1);
					no_Documento = datosRelacion.getString(2);
					no_Plan = datosRelacion.getString(3);
					id_Asociacion = datosRelacion.getString(4);
				}
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
			
			grabarArchivo("AUTORIZACION MASIVA", "Autorizacion_Masiva_Facturas");
			grabarArchivo("No_Convenio: " + no_Convenio, "Autorizacion_Masiva_Facturas");
			grabarArchivo("Documento_Cliente: " + no_Documento, "Autorizacion_Masiva_Facturas");
			grabarArchivo("Plan: " + no_Plan, "Autorizacion_Masiva_Facturas");
			
			if((boolean)callScript("Scripts.Login"))
				System.out.println("lOGIN");
			
			//Vista1
			dataVista1[0] = no_Convenio;
			dataVista1[1] = no_Documento;
			dataVista1[2] = no_Plan;
			dataVista1[3] = ""+cantidadFacturas;
			
			Object resultadoAutorizacion = callScript("Autorizacion_MasivaFacturas.Vista.Vista1_TablaSeleccion", dataVista1);
			String cadena = (String)resultadoAutorizacion;
			data = new String[1][4];
			
			if(cadena.length()>41){
				if(cadena.substring(0,41).equals("Las facturas se autorizaron correctamente"))
				{
					data[0][0]= "Autorizacion Masiva";
					data[0][1]= "Las facturas se autorizaron correctamente...";
					data[0][2]= cadena;
					data[0][3]= "Exitoso";
					
					ejecutar("UPDATE Factura " +
								"SET Estado_Factura = 'AUTO/MASIVA' " +
								"WHERE Id_Factura IN (SELECT TOP 5 Id_Factura FROM Factura WHERE Estado_Factura = 'CREADA')");
				}
				else
				{
					data[0][0]= "Autorizacion Masiva";
					data[0][1]= "Las facturas se autorizaron correctamente...";
					data[0][2]= cadena;
					data[0][3]= "Fallido";
					
					ejecutar("UPDATE Factura " +
							"SET Estado_Factura = 'AUTO/FALLIDA' " +
							"WHERE Id_Factura IN (SELECT TOP 5 Id_Factura FROM Factura WHERE Estado_Factura = 'CREADA')");
				}
			}
			else
			{
				data[0][0]= "Autorizacion Masiva";
				data[0][1]= "Las facturas se autorizaron correctamente...";
				data[0][2]= cadena;
				data[0][3]= "Fallido";
				
				ejecutar("UPDATE Factura " +
						"SET Estado_Factura = 'AUTO/FALLIDA' " +
						"WHERE Id_Factura IN (SELECT TOP 5 Id_Factura FROM Factura WHERE Estado_Factura = 'CREADA')");
			}
			
			createPdf("Autorizacion_Masiva_Facturas");
			createPdfInforme("INFORME AUTORIZACION MASIVA", data);
			
			//Aututorizacion Manual
			dataVistaAutorizacionFacturas[0] = id_Asociacion;
			dataVistaAutorizacionFacturas[1] = "Aprobado";
			callScript("Autorizacion_Facturas.Controlador.Autorizar_Factura", dataVistaAutorizacionFacturas );
		}
		else{
			
			ResultSet datosRelacion = Consulta("SELECT No_Convenio, No_Documento, No_Plan, Id_Asociacion " +
					"FROM Cliente_Con_Convenio " + 
					"WHERE Id_Asociacion IN (SELECT Id_Asociacion FROM Factura " +
					"WHERE Estado_Factura = 'CREADA')");

			try {
				while (datosRelacion.next()) 
				{
					no_Convenio = datosRelacion.getString(1);
					no_Documento = datosRelacion.getString(2);
					no_Plan = datosRelacion.getString(3);
					id_Asociacion = datosRelacion.getString(4);
					
					dataVistaAutorizacionFacturas[0] = id_Asociacion;
					dataVistaAutorizacionFacturas[1] = "Aprobado";
					callScript("Autorizacion_Facturas.Controlador.Autorizar_Factura", dataVistaAutorizacionFacturas );
					
					
					grabarArchivo("AUTORIZACION MASIVA", "Autorizacion_Masiva_Facturas");
					grabarArchivo("No_Convenio: " + no_Convenio, "Autorizacion_Masiva_Facturas");
					grabarArchivo("Documento_Cliente: " + no_Documento, "Autorizacion_Masiva_Facturas");
					grabarArchivo("Plan: " + no_Plan, "Autorizacion_Masiva_Facturas");
				}
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
			
		}
		
	}
}

