package Creacion_Convenios.Controlador;
import java.sql.ResultSet;
import java.sql.SQLException;

import resources.Creacion_Convenios.Controlador.Crear_ConvenioHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Crear_Convenio extends Crear_ConvenioHelper
{
	String Linea_Credito, formaDesembolso, tipoDesembolso, cuentaDesembolso;
	String cargoCuenta, tipoCargoCuenta, cuentaCargo, nombreConvenio;
	int consecutivoFinal;
	boolean flujo = false;
	int casoPrueba;
	String[][] data;
	String[] dataVista1 = new String[4];
	String[] dataVista2 = new String[5];
	String[] dataVista3 = new String[7];
	String[] dataVista4 = new String[1];
	String[] dataflujo = new String[3];
	int cantidadResultados, ubicacion;
	
	public void testMain(Object[] args) 
	{
		ConnecionDB();
		
		/*
		 * 
		 * args[0] ----> Consulta SQL para seleccio de caso de prueba 
		 * args[1] ----> Cantidad de veces que se decea ejcutar el caso de prueba(genEracion de datos)
		 * args[2] ----> Front activo 
		 * 
		 */
		
		//Se valida Object[] args == sql de jpanel generacion o varible de Quality Manager
		if(EsNumero((String)args[0])==true){
			if(Integer.valueOf((String) args[0])==2 || Integer.valueOf((String) args[0])==4){
				args = new Object[3];
				args[0] = "  SELECT TOP 1 * " +
						"FROM CasoPrueba_Convenios " +
						"WHERE Forma_Desembolso = 'Cuenta Contable' " +
						"ORDER BY NEWID()";
			}
			else if(Integer.valueOf((String) args[0])==1){
				args = new Object[3];
				args[0] = "  SELECT TOP 1 * " +
						"FROM CasoPrueba_Convenios " +
						"WHERE Forma_Desembolso = 'Cheque' " +
						"ORDER BY NEWID()";
			}
			else if(Integer.valueOf((String) args[0])==3){
				args = new Object[3];
				args[0] = "  SELECT TOP 1 * " +
						"FROM CasoPrueba_Convenios " +
						"WHERE Forma_Desembolso = 'Abono a Cuenta' " +
						"ORDER BY NEWID()";
			}
						
			args[1] = "1";
			args[2] = "True";
			flujo = true;
						
		}
		
		ResultSet cantidad =Consulta((String)args[0]);
				
		try {
			while(cantidad.next()){
				cantidadResultados++;
			}
		} catch (SQLException e1) {
			// TODO Bloque catch generado autom�ticamente
			e1.printStackTrace();
		}
		
		if(cantidadResultados>1)
			data = new String[cantidadResultados][4];
		else
			data = new String[Integer.parseInt((String)args[1])][4];
		
		if((boolean)callScript("Scripts.Login"))
			System.out.println("lOGIN");
						
					
		for(int i = 0; i < Integer.parseInt((String)args[1]); i++)
		{
			ResultSet resultado = Consulta((String)args[0]);
						
			
			try {
				while(resultado.next()){
					
					casoPrueba = resultado.getInt(1);
					Linea_Credito = resultado.getString(2);
					formaDesembolso = resultado.getString(3);
					tipoDesembolso = resultado.getString(4);
					cuentaDesembolso = resultado.getString(5);
					cargoCuenta = resultado.getString(6);
					tipoCargoCuenta = resultado.getString(7);
					cuentaCargo = resultado.getString(8);
									
					ResultSet resultadoOrden =Consulta("SELECT COUNT(*) +1 FROM Convenio");
					while(resultadoOrden.next())
						nombreConvenio = resultadoOrden.getString(1);
					
					
					grabarArchivo("CREACION DE CONVENIOS ", "Creacion_Convenios");
					grabarArchivo("Caso de Prueba: " + casoPrueba, "Creacion_Convenios");
					grabarArchivo("Linea de Credito: " + Linea_Credito, "Creacion_Convenios");
					grabarArchivo("Forma Desembolso: " + formaDesembolso, "Creacion_Convenios");
					grabarArchivo("Tipo Desembolso: " + tipoDesembolso, "Creacion_Convenios");
					grabarArchivo("Cuenta Desembolso: " + cuentaDesembolso,  "Creacion_Convenios");
					grabarArchivo("Cargo Cuenta: " + cargoCuenta, "Creacion_Convenios");
					grabarArchivo("Tipo Cargo Cuenta: " + tipoCargoCuenta, "Creacion_Convenios");
					grabarArchivo("Cuenta Cargo " + cuentaCargo, "Creacion_Convenios");
											
					// Vista1 
					dataVista1[0] = nombreConvenio;
					dataVista1[1] = obtenerPrefijo(1);
					dataVista1[2] = obtenerPrefijo(2);
					dataVista1[3] = ""+casoPrueba;									
					Object resultadoPrefijo =  callScript("Creacion_Convenios.Vista.Vista1_DatosPricipales",  dataVista1);
					consecutivoFinal = Integer.parseInt((String)resultadoPrefijo);
									
					// Vista2
					dataVista2[0] = Linea_Credito;
					dataVista2[1] = ObtenerFecha();
					dataVista2[2] = ObtenerFechaVencimientoConvenio();
					dataVista2[3] = (String)args[2];
					dataVista2[4] = ""+casoPrueba;
					callScript("Creacion_Convenios.Vista.Vista2_InformacionAdicional",  dataVista2);
									
					//Vista3
					dataVista3[0] = formaDesembolso; 
					dataVista3[1] = tipoDesembolso; 
					dataVista3[2] = cuentaDesembolso; 
					dataVista3[3] = cargoCuenta; 
					dataVista3[4] = tipoCargoCuenta; 
					dataVista3[5] = cuentaCargo; 
					dataVista3[6] = ""+casoPrueba; 
					callScript("Creacion_Convenios.Vista.Vista3_FormaDesembolso",  dataVista3);
									
					//Vista4
					dataVista4[0] = ""+casoPrueba; 
					Object resulCreacion = callScript("Creacion_Convenios.Vista.Vista4_Respuesta", dataVista4);
					String cadena = (String) resulCreacion;
					
					if(cadena.substring(0, 64).equals("Convenio creado correctamente, El n�mero de Convenio asignado es"))
					{
						data[ubicacion][0]= "" +casoPrueba;
						data[ubicacion][1]= "Convenio creado correctamente, El n�mero de Convenio asignado es : XXXXX" ;
						data[ubicacion][2]= cadena;
						data[ubicacion][3]= "Exitoso";
						
						dataflujo[0] = 	"ConvenioAutomatizacion"  + nombreConvenio;
						dataflujo[1] =  "Autorizar";
						dataflujo[2] =  cadena.substring(67, 74);
						
						ejecutar("INSERT INTO Convenio " +
								"VALUES ('"+ cadena.substring(67, 74) + "', '"
								+ "ConvenioAutomatizacion"  + nombreConvenio + "', '"
								+ "CREADO" + "', '"
								+ obtenerPrefijo(0) + "', '"
								+ ObtenerFechaForDB() + "', '"
								+ ObtenerFechaVencimientoForDB() + "', "
								+ casoPrueba + ")");
										
						System.out.println("*/-*/*/-/-*/*/-/-*/-*/-*/-*/-*/*");
						System.out.println("INSERT INTO Convenio " +
								"VALUES ('"+ cadena.substring(67, 74) + "', '"
								+ "ConvenioAutomatizacion"  + nombreConvenio + "', '"
								+ "CREADO" + "', '"
								+ obtenerPrefijo(0) + "', '"
								+ ObtenerFechaForDB() + "', '"
								+ ObtenerFechaVencimientoForDB() + "', "
								+ casoPrueba + ")");
										
						ejecutar("UPDATE dbo.Persistencia " +
								"SET Consecutivo = Consecutivo + " + consecutivoFinal  + " " + 
								"WHERE  Id_Persistencia = 1");
													
					}
					else
					{
						data[ubicacion][0]= "" +casoPrueba;
						data[ubicacion][1]= "Convenio creado correctamente, El n�mero de Convenio asignado es : XXXXX";
						data[ubicacion][2]= cadena;
						data[ubicacion][3]= "Fallido";
					}
									
					ubicacion++;
				}
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}	
		}
		createPdf("Creacion_Convenios");
		createPdfInforme("INFORME CREACION CONVENIOS", data);
		
		if(flujo == true){
			if(dataflujo[0]!=null)
				callScript("Autorizacion_Convenios.Controlador.Autorizar_Convenio",  dataflujo);
		}
	}
}

