package Creacion_Convenios.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Creacion_Convenios.Vista.Vista1_DatosPricipalesHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.object.map.ObjectMap;
import com.rational.test.ft.object.map.ObjectMapSet;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista1_DatosPricipales extends Vista1_DatosPricipalesHelper
{
	RenderedImage Imagen;
	String nombreConvenio, prefijo1, prefijo2;
	int casoPrueba;
			
	public String testMain(Object[] args) throws IOException 
	{
		nombreConvenio = (String)args[0];
		prefijo1 = (String)args[1];
		prefijo2 = (String)args[2];
		casoPrueba = Integer.parseInt((String)args[3]);
		
		if(link_creaci�nConvenios(ANY, LOADED).exists() && link_creaci�nConvenios(ANY, LOADED).isShowing())
		{
			link_creaci�nConvenios().click();
		}
		else
		{
			link_factoring().click();sleep(2);	
			link_convenios().click();sleep(2);
			link_creaci�nConvenios().click();sleep(2);
			
		}
		
		list_tipoIdentificacion(ubicacion(1), DEFAULT).waitForExistence();
		list_tipoIdentificacion(ubicacion(1), DEFAULT).select("Cedula de Ciudadania");
		teclado("{TAB}");
		text_numeroIdentificacion(ubicacion(1), DEFAULT).setText("80850370");
		grabarArchivo("Documento: CC - 80850370", "Creacion_Convenios");
	
		teclado("{TAB}");sleep(5);
		recorrerLista(0);
		teclado("{TAB}{TAB}");
		teclado("{Num2}"); sleep(3);
		recorrerLista(GetRandom1_10());
		teclado("{TAB}");
		text_nombreConvenio(ubicacion(1), DEFAULT).setText("ConvenioAutomatizacion"  + nombreConvenio);
		teclado("{TAB}");
		recorrerLista(0);
		teclado("{TAB}");
		text_prefijo(ubicacion(1), DEFAULT).setText(prefijo1);
		
		//captura de pantalla 
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		teclado("{TAB}");
		
		//Validacion ventana emergente(Prefijo existente)
		if(button_oKbutton(ANY, LOADED).exists()){
			button_oKbutton(ubicacion(2), DEFAULT).click();
			text_prefijo(ubicacion(1), DEFAULT).setText(prefijo2);
			Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
			grabarArchivo("Prefijo "  + prefijo2, "Creacion_Convenios");
			teclado("{TAB}");
			return "2";
		}
		else{
			grabarArchivo("Prefijo "  + prefijo1, "Creacion_Convenios");
			guardarImagen(Imagen, casoPrueba + "_DatosPricipalesConvenio", "Creacion_Convenios");
			return "1";
		}
	}
	
	public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else
			return browser_htmlBrowser(document_capturaConvenio(), DEFAULT);
			
	}
}

