package Creacion_Convenios.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Creacion_Convenios.Vista.Vista3_FormaDesembolsoHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista3_FormaDesembolso extends Vista3_FormaDesembolsoHelper
{
	RenderedImage Imagen;
	String formaDesembolso, tipoDesembolso, cuentaDesembolso, cargoCuenta, tipoCargoCuenta, cuentaCargo;
	int casoPrueba;
	
	public void testMain(Object[] args) throws IOException 
	{
		formaDesembolso = (String)args[0];
		tipoDesembolso = (String)args[1];
		cuentaDesembolso = (String)args[2];
		cargoCuenta = (String)args[3];
		tipoCargoCuenta = (String)args[4];
		cuentaCargo = (String)args[5];
		casoPrueba = Integer.parseInt((String)args[6]);
		
		list_formaDesembolso(ANY, LOADED).click();sleep(2);
		if(formaDesembolso.equals("Cheque"))
		{
			recorrerLista(0);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}
		if(formaDesembolso.equals("Cuenta Contable"))
		{
			recorrerLista(1);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
		}	
		if(formaDesembolso.equals("Abono a Cuenta"))
		{
			recorrerLista(2);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			sleep(2);		
			list_tipoCuentaDes(browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT), DEFAULT).click();
			
			if(tipoDesembolso.equals("Cuenta de Ahorros"))
				recorrerLista(0);
			else
				recorrerLista(1);
			
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			text_numeroCuentaDes().setText(cuentaDesembolso);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			
		}
		if(cargoCuenta.equals("NO"))
		{
			recorrerLista(0);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			recorrerLista(0);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{ENTER}");			
		}
		else
		{
			sleep(1);
			recorrerLista(1);
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");sleep(2);
			if(tipoCargoCuenta.equals("Cuenta de Ahorros"))
				recorrerLista(0);
			else
				recorrerLista(1);
				
				teclado("{TAB}");
				text_cuentaCargo().setText(cuentaCargo);
				teclado("{TAB}");
				recorrerLista(0);
				teclado("{TAB}");
				teclado("{TAB}");
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{ENTER}");
		}
		
//		grabarArchivo("****************************************", "Creacion_Convenios");
	}
	
public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
public void teclado(String tecla){
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else
			return browser_htmlBrowser(document_capturaConvenio(), DEFAULT);
	}
}

