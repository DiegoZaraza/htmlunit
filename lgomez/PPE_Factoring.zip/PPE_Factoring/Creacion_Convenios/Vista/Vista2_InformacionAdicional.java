package Creacion_Convenios.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Creacion_Convenios.Vista.Vista2_InformacionAdicionalHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista2_InformacionAdicional extends Vista2_InformacionAdicionalHelper
{
	RenderedImage Imagen;
	String linea_Credito, fechaDesde, FechaHasta, valorFront;
	int casoPrueba;
	
	public void testMain(Object[] args) throws IOException 
	{
		linea_Credito = (String)args[0];
		fechaDesde = (String)args[1];
		FechaHasta = (String)args[2];
		valorFront = (String)args[3];
		casoPrueba = Integer.parseInt((String)args[4]);
		
		text_fechaDesde(ANY, LOADED).setText(fechaDesde);
		sleep(1);
		teclado("{TAB}");
		text_fechaHasta(ANY, LOADED).setText(FechaHasta);
		sleep(1);
		teclado("{TAB}");
		text_lineaCredito(ANY, LOADED).setText(linea_Credito);sleep(4);
		recorrerLista(0);
		teclado("{TAB}");
		
		if(valorFront.equals("True"))
			recorrerLista(1);
		else
			recorrerLista(0);
		
		teclado("{TAB}");
		recorrerLista(0);
		teclado("{TAB}");
		recorrerLista(0);
		teclado("{TAB}{TAB}");
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, casoPrueba + "_InfoAdicional", "Creacion_Convenios");
		teclado("{ENTER}");	
	}
	
public void recorrerLista(int cantidad){
		
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
public void teclado(String tecla){
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else
			return browser_htmlBrowser(document_capturaConvenio(), DEFAULT);
	}

}

