package Creacion_Convenios.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Creacion_Convenios.Vista.Vista4_RespuestaHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista4_Respuesta extends Vista4_RespuestaHelper
{
	RenderedImage Imagen;
	int casoPrueba;
	
		
	public String testMain(Object[] args) throws IOException 
	{
		casoPrueba = Integer.parseInt((String)args[0]);
		sleep(2);	
		if(html_mesajeRespuestaDialog(browser_htmlBrowser(document_capturaConvenio(), DEFAULT), DEFAULT).exists() && html_mesajeRespuestaDialog(browser_htmlBrowser(document_capturaConvenio(), DEFAULT), DEFAULT).isShowing())
		{	
			sleep(2);
			Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
			guardarImagen(Imagen, casoPrueba + "_FormaDesembolso", "Creacion_Convenios");
			String respuesta = (String)html_mesajeRespuestaDialog(ubicacion(2), DEFAULT).getProperty(".text"); 
			button_oKbutton(ubicacion(2), DEFAULT).click();sleep(5);
			teclado("{F5}");sleep(5);
			return respuesta;
				
		}
		else
		{
			sleep(2);
			Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
			guardarImagen(Imagen, casoPrueba + "_FormaDesembolso", "Creacion_Convenios");
			button_oKbutton(ubicacion(2), DEFAULT).click();sleep(5);
			teclado("{F5}");sleep(5);
			return "No se genero ventana de respuesta";
		}
			
	}
public void teclado(String tecla){
		
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
public TestObject ubicacion(int nivel){
	if(nivel==1)
		return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
	else
		return browser_htmlBrowser(document_capturaConvenio(), DEFAULT);
}
}