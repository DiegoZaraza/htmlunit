package Creacion_Plan.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;
import java.util.Iterator;

import resources.Creacion_Plan.Vista.Vista3_DatosPlanFinanciacionHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista3_DatosPlanFinanciacion extends Vista3_DatosPlanFinanciacionHelper
{
	RenderedImage Imagen;
	String tipoTasa_Financiacion, modoTasa_Financiacion, tasaFinanciacion, tipoPLazoFinanciacion;
	String plazoFinanciacion, noConvenio;
	
	public String testMain(Object[] args) throws IOException{
		
		tipoTasa_Financiacion = (String)args[0];
		modoTasa_Financiacion = (String)args[1];
		tasaFinanciacion = (String)args[2]; 
		tipoPLazoFinanciacion = (String)args[3];
		plazoFinanciacion = (String)args[4];
		noConvenio = (String)args[5];
						
		teclado("{TAB}");		
		if(tipoTasa_Financiacion.equals("Fija") || tipoTasa_Financiacion.equals("Tasa efectiva peri�dica")){
			if (tipoTasa_Financiacion.equals("Fija"))
				recorrerLista(0);
			if (tipoTasa_Financiacion.equals("Tasa efectiva peri�dica"))
				recorrerLista(2);
			
			teclado("{TAB}");
			
			if(modoTasa_Financiacion.equals("Est�ndar")){
				recorrerLista(0);
				teclado("{TAB}");
				text_tasaFinan(ANY, LOADED).setText(tasaFinanciacion);
				teclado("{TAB}");
			}
			else{
				recorrerLista(1);
				teclado("{TAB}");
			}
			if(tipoPLazoFinanciacion.equals("Fijo")){
				recorrerLista(0);
				teclado("{TAB}");
				text_plazoFinan(ANY, LOADED).setText(plazoFinanciacion);
				teclado("{TAB}");
			}
			else{
				recorrerLista(1);
				teclado("{TAB}");
			}
		}
		if(tipoTasa_Financiacion.equals("Variable"))
		{
			recorrerLista(1);
			teclado("{TAB}");
			
			if(modoTasa_Financiacion.equals("Est�ndar")){
				recorrerLista(0);
				teclado("{TAB}");
				recorrerLista(0);
				teclado("{TAB}");
				recorrerLista(0);
				teclado("{TAB}");
				if(tipoPLazoFinanciacion.equals("Fijo"))
				{
					recorrerLista(0);
					teclado("{TAB}");
					text_puntosFinan(ANY, LOADED).setText(tasaFinanciacion);
					text_plazoFinan(ANY, LOADED).setText(plazoFinanciacion);
					teclado("{TAB}");
				}
				else
				{
					recorrerLista(1);
					teclado("{TAB}");
					text_puntosFinan(ANY, LOADED).setText(tasaFinanciacion);
					teclado("{TAB}");
				}
			}
			else{
				recorrerLista(1);
				teclado("{TAB}");
				recorrerLista(0);
				teclado("{TAB}");
				recorrerLista(0);
				teclado("{TAB}");
				if(tipoPLazoFinanciacion.equals("Fijo"))
				{
					recorrerLista(0);
					teclado("{TAB}");
					text_plazoFinan(ANY, LOADED).setText(plazoFinanciacion);
					teclado("{TAB}");
				}
				else
				{
					recorrerLista(1);
					teclado("{TAB}");
				}
			}
		}
		if(tipoTasa_Financiacion.equals("Sin Financiacion")){
			recorrerLista(2);
			teclado("{TAB}");
		}
			
		
		teclado("{TAB}");
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, (String)args[3] + "RegistroDatosPlanDescuento", "Creacion_Planes");
		teclado("{ENTER}");sleep(3);
		
		if(html_mesajeRespuestaDialog(ANY, LOADED).exists() && html_mesajeRespuestaDialog(ANY, LOADED).isShowing())
		{
			String resulCreacion="";
			resulCreacion = (String)html_mesajeRespuestaDialog().getProperty(".text");
			sleep(2);
			Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
			button_oKbutton(ubicacion(1), DEFAULT).click();sleep(5);
			guardarImagen(Imagen, (String)args[5] + "final", "Creacion_Planes");
			grabarArchivo("*******************************************************************************", "Creacion_Planes");
			teclado("{F5}");sleep(5);
			return resulCreacion;
		}
		
		return "Error NO pantalla emergente";
	}
	
public void recorrerLista(int cantidad){
	for(int i = 0; i<=cantidad; i++ )
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
}
public void teclado(String tecla){
	browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
}	
public TestObject ubicacion(int nivel){
	if(nivel==1)
		return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
	else
		return browser_htmlBrowser(document_crearPlanes(), DEFAULT);	
}

	
}

