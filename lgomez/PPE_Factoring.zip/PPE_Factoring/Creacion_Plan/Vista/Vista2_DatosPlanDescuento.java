package Creacion_Plan.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Creacion_Plan.Vista.Vista2_DatosPlanDescuentoHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista2_DatosPlanDescuento extends Vista2_DatosPlanDescuentoHelper
{
	RenderedImage Imagen;
	String segmento, tipoTasa_DSCTO, condicionTasa_DSCTO, tasaDescuento, tipoPLazo_DSCTO;
	String plazoDescuento;
		
	public void testMain(Object[] args) throws IOException 
	{
		segmento = (String)args[0];
		tipoTasa_DSCTO = (String)args[1];
		condicionTasa_DSCTO = (String)args[2];
		tasaDescuento = (String)args[3];
		tipoPLazo_DSCTO = (String)args[4];
		plazoDescuento = (String)args[5];
				
		teclado("{TAB}");
		if(segmento.equals("C- Corporativo"))
			recorrerLista(0);
		else if(segmento.equals("E- Empresarial "))
			recorrerLista(1);
		else if(segmento.equals("P- Pime"))
			recorrerLista(2);
		else
			recorrerLista(3);
		
		teclado("{TAB}");
		
		if(tipoTasa_DSCTO.equals("Sin descuento"))
		{
			recorrerLista(2);
			teclado("{TAB}");sleep(1);
			recorrerLista(GetRandom1_2()-1);
			teclado("{TAB}");
			text_diaDesembolso().setText(ObtenerFechaDesembolso());
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}{TAB}");
			Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
			teclado("{ENTER}");sleep(3);
		}
		else
		{
			if(tipoTasa_DSCTO.equals("Fija"))
				recorrerLista(0);
			if(tipoTasa_DSCTO.equals("Variable"))
				recorrerLista(1);
			if(tipoTasa_DSCTO.equals("Tasa efectiva peri�dica"))
				recorrerLista(3);
			
			teclado("{TAB}");
			
			if(condicionTasa_DSCTO.equals("Est�ndar"))
				recorrerLista(0);
			if(condicionTasa_DSCTO.equals("Modificable"))
				recorrerLista(1);
			teclado("{TAB}");
			
			
			if(tipoTasa_DSCTO.equals("Fija") || tipoTasa_DSCTO.equals("Tasa efectiva peri�dica"))
			{
				if(condicionTasa_DSCTO.equals("Est�ndar")){
					text_tasaDescue(ANY, LOADED).setText(tasaDescuento);
					teclado("{TAB}");
				}
			}
			else 
			{
				if(condicionTasa_DSCTO.equals("Est�ndar")){
					teclado("{TAB}");
					text_puntosDescu(ANY, LOADED).setText("4.5");
					teclado("{TAB}");
				}
				else
					teclado("{TAB}"); sleep(2);
			}
			
			recorrerLista(GetRandom1_2()-1);
			teclado("{TAB}");
			
			if(tipoPLazo_DSCTO.equals("Fijo"))
			{
				recorrerLista(0);
				teclado("{TAB}");
				
				text_diasPlazoFac(ANY, LOADED).setText(""+ new Double(Double.parseDouble(plazoDescuento)/2).intValue());
				teclado("{TAB}");
				text_diasPlazoAdicio(ANY, LOADED).setText(""+ new Double(Double.parseDouble(plazoDescuento)/2).intValue());
				teclado("{TAB}{TAB}");
				
			}
			else
			{
				recorrerLista(1);
				browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{TAB}");
			}
			
			text_diaDesembolso(ubicacion(1), DEFAULT).setText(ObtenerFechaDesembolso());
			teclado("{TAB}{TAB}");
			Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
			teclado("{ENTER}");sleep(3);
		}
		guardarImagen(Imagen, (String)args[3] + "RegistroDatos", "Creacion_Planes");
	}

	public void recorrerLista(int cantidad){
		for(int i = 0; i<=cantidad; i++ )
			browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
	}
	public void teclado(String tecla){
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
	}	
	public TestObject ubicacion(int nivel){
		if(nivel==1)
			return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
		else
			return browser_htmlBrowser(document_crearPlanes(), DEFAULT);	
	}
	
}

