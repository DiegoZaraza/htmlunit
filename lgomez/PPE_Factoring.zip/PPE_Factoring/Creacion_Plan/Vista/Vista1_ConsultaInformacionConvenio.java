package Creacion_Plan.Vista;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.Creacion_Plan.Vista.Vista1_ConsultaInformacionConvenioHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Vista1_ConsultaInformacionConvenio extends Vista1_ConsultaInformacionConvenioHelper
{
	RenderedImage Imagen;
	String convenio;
	
	public void testMain(Object[] args) throws IOException 
	{
		convenio = (String)args[0];
		
		if(link_creaci�nPlanes(ANY, LOADED).exists() && link_creaci�nPlanes(ANY, LOADED).isShowing())
		{
			
			link_creaci�nPlanes().click();
		}
		else
		{
			
			link_factoring().click();sleep(1);	
			link_planes().click();sleep(1);
			link_creaci�nPlanes().click();sleep(3);
		}
		
		// CONSULTA INFORMACION CONVENIO 
		
		text_numeroConvenio(ubicacion(1), DEFAULT).waitForExistence();
		text_numeroConvenio(ubicacion(1), DEFAULT).setText(convenio);
		teclado("{TAB}");
		teclado("{TAB}");
		teclado("{TAB}");
		teclado("{TAB}");
		teclado("{TAB}");
		Imagen = browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).getScreenSnapshot();
		guardarImagen(Imagen, convenio + "Consulta_infoConvenio", "Creacion_Planes");
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("{ENTER}");sleep(3);
	}
	
public void recorrerLista(int cantidad){
	for(int i = 0; i<=cantidad; i++ )
		browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys("2{ExtDown}");
}
public void teclado(String tecla){
	browser_htmlBrowser(document_bancoDeBogot�(),DEFAULT_FLAGS).inputKeys(tecla);
}	
public TestObject ubicacion(int nivel){
	if(nivel==1)
		return browser_htmlBrowser(document_bancoDeBogot�(), DEFAULT); 
	else
		return browser_htmlBrowser(document_crearPlanes(), DEFAULT);	
}

}

