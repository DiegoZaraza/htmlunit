package Creacion_Plan.Controlador;
import java.sql.ResultSet;
import java.sql.SQLException;

import resources.Creacion_Plan.Controlador.Crear_PlanHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author GORTEG1
 */
public class Crear_Plan extends Crear_PlanHelper
{
	String no_CP_Plan, segmento, tipoTasa_DSCTO, condicionTasa_DSCTO;
	String tipoTasa_Financiacion, modoTasa_Financiacion, tipoPLazo_DSCTO, tipoPLazoFinanciacion;
	String tasaDescuento, tasaFinanciacion, plazoDescuento, plazoFinanciacion, convenio, documentoArelacionar;
	String cadena;
	String[][] data;
	String[] dataVista1 = new String[1];
	String[] dataVista2 = new String[6];
	String[] dataVista3 = new String[6];
	boolean flujo = false;
	ResultSet resultado2, resultado3;
	int cantidaDatos, ubicacion;
	
	public void testMain(Object[] args) 
	{
		/*
		 * args[0] = Sql consulta CP_Plan
		 * args[1] = tasaDescuento
		 * args[2] = tasaFinanciacion
		 * args[3] = Cantidad
		 * args[4] = plazoDescuento
		 * args[5] = plazoFinanciacion
		 * args[6] = Numero Convenio 
		*/	
//		args = new Object[7];
//		args[0] = "SELECT * FROM CasoPrueba_Plan WHERE Segmento = 'E- Empresarial ' AND TipoTasa_DSCTO = 'Fija' AND TipoTasa_Financiacion = 'Fija'AND CondicionTasa_DSCTO = 'Est�ndar' AND TipoPLazo_DSCTO = 'Fijo' AND ModoTasa_Financiacion = 'Est�ndar' AND TipoPLazoFinanciacion = 'Fijo' ";
//		args[1] = "2";
//		args[2] = "3";
//		args[3] = "1";
//		args[4] = "2";
//		args[5] = "15";
//		args[6] = "5000227";
		
		System.out.println("-*-*-*-*-*-*-*CREACION PLAN-*-*-*-*-*-*-*-*-*-*-*");
		for (Object object : args) {
			System.out.println(object);
		}
		System.out.println("-*-*-*-*-*-*-*CREACION PLAN-*-*-*-*-*-*-*-*-*-*-*");
		ConnecionDB();
		
		//Se valida Object[] args == sql de jpanel generacion o varible de Quality Manager
		if(EsNumero((String)args[0])==true){
			if(Integer.valueOf((String) args[0])==1){
				args = new Object[7];
				args[0] = "SELECT TOP 1 * " +
							"FROM CasoPrueba_Plan " +
							"WHERE TipoTasa_DSCTO = 'variable' and TipoTasa_Financiacion = 'fija' " +
							"and TipoPLazo_DSCTO = 'fijo' and TipoPLazoFinanciacion = 'fijo' " +
							"ORDER BY NEWID()";
				args[1] = "3.3";
				args[2] = "10.3";
			}
			else if(Integer.valueOf((String) args[0])==2){
				args = new Object[7];
				args[0] = "SELECT TOP 1 * " +
							"FROM CasoPrueba_Plan " +
							"WHERE TipoTasa_DSCTO = 'fija' and TipoTasa_Financiacion = 'variable' " +
							"and TipoPLazo_DSCTO = 'fijo' and TipoPLazoFinanciacion = 'fijo' " +
							"ORDER BY NEWID()";
				args[1] = "10.3";
				args[2] = "3.3";
			}
			else if(Integer.valueOf((String) args[0])==3){
				args = new Object[7];
				args[0] = "SELECT TOP 1 * " +
							"FROM CasoPrueba_Plan " +
							"WHERE TipoTasa_DSCTO = 'fija' and TipoTasa_Financiacion = 'fija' " +
							"and TipoPLazo_DSCTO = 'abierto' and TipoPLazoFinanciacion = 'fijo' " +
							"ORDER BY NEWID()";
				args[1] = "10.3";
				args[2] = "10.3";
			}
			else{
				args = new Object[7];
				args[0] = "SELECT TOP 1 * " +
							"FROM CasoPrueba_Plan " +
							"WHERE TipoTasa_DSCTO = 'fija' and TipoTasa_Financiacion = 'fija' " +
							"and TipoPLazo_DSCTO = 'fijo' and TipoPLazoFinanciacion = 'abierto' " +
							"ORDER BY NEWID()";
				args[1] = "10.3";
				args[2] = "10.3";
			}
			
			args[3] = "1";
			args[4] = "45";
			args[5] = "45";
						
			ResultSet ultimoConvenio = Consulta("SELECT TOP 1 No_Convenio, Nombre_Convenio " +
													"FROM Convenio " + 
														"WHERE Estado_convenio = 'CREADO-APROBADO' " +
															"ORDER BY No_Convenio DESC");
			
			try {
				while(ultimoConvenio.next())
					args[6] = ultimoConvenio.getString(1);
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
			
			flujo = true;
		}	
		if(args[6].equals("Aplicar a Todos")){
			
			resultado2 =Consulta("SELECT No_Convenio " +
					"FROM Convenio " +
					"WHERE Estado_convenio = 'CREADO/APROBADO' " +
					"AND No_Convenio NOT IN (SELECT No_Convenio FROM Cliente_Con_Convenio)");
			
			try {
				while(resultado2.next()){
					cantidaDatos++;
				}
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
		}
		
		if(cantidaDatos>0)
			data = new String[cantidaDatos][4];
		else
			data = new String[Integer.parseInt((String)args[3])][4];
		
		if((boolean)callScript("Scripts.Login"))
			System.out.println("lOGIN");
		
		for(int i = 0; i < Integer.parseInt((String)args[3]); i++)
		{
			ResultSet resultado =Consulta((String)args[0]);
			if(args[6].equals("Aplicar a Todos")){
				resultado2 =Consulta("SELECT No_Convenio " +
						"FROM Convenio " +
						"WHERE Estado_convenio = 'CREADO/APROBADO' " +
						"AND No_Convenio NOT IN (SELECT No_Convenio FROM Cliente_Con_Convenio)");
			}
			else
				resultado2 =Consulta("SELECT No_Convenio FROM Convenio WHERE No_Convenio = '" + (String)args[6] +"'");
			
			try {
				while(resultado.next()){
					
					no_CP_Plan = resultado.getString(1);
					segmento = resultado.getString(2);
					tipoTasa_DSCTO = resultado.getString(3);
					condicionTasa_DSCTO = resultado.getString(4);
					tipoTasa_Financiacion = resultado.getString(5);
					modoTasa_Financiacion = resultado.getString(6);
					tipoPLazo_DSCTO = resultado.getString(7);
					tipoPLazoFinanciacion = resultado.getString(8);
			
					grabarArchivo("CREACION PLANES ", "Creacion_Planes");
					grabarArchivo("No Caso Prueba: " + no_CP_Plan, "Creacion_Planes");
					grabarArchivo("Segmento: " + segmento, "Creacion_Planes");
					grabarArchivo("Tipo Tasa de Descuento: " + tipoTasa_DSCTO, "Creacion_Planes");
					grabarArchivo("Condici�n Tasa de Descuento: " + condicionTasa_DSCTO, "Creacion_Planes");
					grabarArchivo("Tipo Tasa Financiacion: " + tipoTasa_Financiacion,  "Creacion_Planes");
					grabarArchivo("Modo Tasa Financiacion: " + modoTasa_Financiacion, "Creacion_Planes");
					grabarArchivo("Tipo PLazo Descuento: " + tipoPLazo_DSCTO, "Creacion_Planes");
					grabarArchivo("Tipo PLazo Financiaci�n: " + tipoPLazoFinanciacion, "Creacion_Planes");
					
					if(!(tipoTasa_DSCTO.equals("Sin descuento")))
						tasaDescuento = (String)args[1];
					if(!(tipoTasa_Financiacion.equals("Sin Financiacion")))
						tasaFinanciacion = (String)args[2];
					
					if(!(tipoTasa_DSCTO.equals("Sin descuento")))
						plazoDescuento = (String)args[4];
					if(!(tipoTasa_Financiacion.equals("Sin Financiacion")))
						plazoFinanciacion = (String)args[5];
							
				}
				
				while(resultado2.next()){
					
					convenio = resultado2.getString(1);		
					//Vista1
					dataVista1[0] = convenio;
					callScript("Creacion_Plan.Vista.Vista1_ConsultaInformacionConvenio", dataVista1);
					
					//Vista2
					dataVista2[0] = segmento;
					dataVista2[1] = tipoTasa_DSCTO;
					dataVista2[2] = condicionTasa_DSCTO;
					dataVista2[3] = tasaDescuento; 
					dataVista2[4] = tipoPLazo_DSCTO;
					dataVista2[5] = plazoDescuento;
					callScript("Creacion_Plan.Vista.Vista2_DatosPlanDescuento", dataVista2);
					
					//Vista3
					dataVista3[0] = tipoTasa_Financiacion;
					dataVista3[1] = modoTasa_Financiacion;
					dataVista3[2] = tasaFinanciacion; 
					dataVista3[3] = tipoPLazoFinanciacion;
					dataVista3[4] = plazoFinanciacion;
					dataVista3[5] = convenio;
					Object resultCreacion = callScript("Creacion_Plan.Vista.Vista3_DatosPlanFinanciacion", dataVista3);
					cadena = (String) resultCreacion;
					System.out.println(cadena);
					if(cadena.substring(0, 58).equals("Plan creado correctamente, El n�mero de Plan asignado es :"))
					{
						data[ubicacion][0]= no_CP_Plan;
						data[ubicacion][1]= "Plan creado correctamente, El n�mero de Plan asignado es : XXXX";
						data[ubicacion][2]= cadena;
						data[ubicacion][3]= "Exitoso";
						
						ejecutar("INSERT INTO PlanFinanciero " +
								"VALUES ('" + cadena.substring(59) + "'," +
								"'CREADO', " +
								"'" + convenio + "', " +
								no_CP_Plan + ")");
					}
					else
					{
						data[ubicacion][0]= no_CP_Plan;
						data[ubicacion][1]= "Plan creado correctamente, El n�mero de Plan asignado es : XXXX";
						data[ubicacion][2]= cadena;
						data[ubicacion][3]= "Fallido";
					}
					
					ubicacion++;
				}
								
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
			
		}	
		
		createPdf("Creacion_Planes");
		createPdfInforme("INFORME CREACION PLANES", data);
		
		if(flujo==true){

			String[] dataFlujo = new String[3];
			dataFlujo[0]= convenio;
			dataFlujo[1]= cadena.substring(59);
			dataFlujo[2]= "Autorizar";
			callScript("Autorizacion_Planes.Controlador.Autorizar_Plan", dataFlujo);
			
			resultado3 =Consulta("SELECT Top 1 No_Documento "+
									"FROM Cliente_Con_Convenio "+
									"ORDER BY Id_Asociacion Desc");
			
			try {
				while (resultado3.next()) {
					documentoArelacionar = resultado3.getString(1);
				}
			} catch (SQLException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}

			if(!args[0].equals("1"))
			ProponerRelacionConvenio_Cliente((String)args[6], documentoArelacionar);
		}
			
	}
}

