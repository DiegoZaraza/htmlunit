
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.ParametrosGeneralesHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.pdf.PdfPTable;

public class ParametrosGenerales extends ParametrosGeneralesHelper
{
	public void testMain(Object[] args) throws IOException, DocumentException 
	{
		Document doc = (Document) args[5];
		PdfPTable table = (PdfPTable) args[7];
		
		link_par�metrosGenerales(ANY, LOADED).click();

		list_ldw_UsuarioWS(ANY, LOADED).click();
		browser_htmlBrowser(document_soluci�nDeOficinas(ANY, LOADED),DEFAULT_FLAGS).inputKeys("IDMUSER" + "{TAB}");
		
		list_ldw_Terminal1WS(ANY, LOADED).click(); 
		browser_htmlBrowser(document_soluci�nDeOficinas(ANY, LOADED),DEFAULT_FLAGS).inputKeys("DPINT1" + "{TAB}");
		
		list_ldw_Terminal2WS(ANY, LOADED).click(); 
		browser_htmlBrowser(document_soluci�nDeOficinas(ANY, LOADED),DEFAULT_FLAGS).inputKeys("DPINT2" + "{TAB}");
		
		list_ldw_usrCmndoPrgrmdo(ANY, LOADED).click(); 
		browser_htmlBrowser(document_soluci�nDeOficinas(ANY, LOADED),DEFAULT_FLAGS).inputKeys("AUTOMATA" + "{TAB}");
		
		list_ldw_TerDec(ANY, LOADED).click(); 
		browser_htmlBrowser(document_soluci�nDeOficinas(ANY, LOADED),DEFAULT_FLAGS).inputKeys("VIRTUAL" + "{TAB}");
		
		guardarImagen((RenderedImage)document_soluci�nDeOficinas(ANY, LOADED).getScreenSnapshot() , "Validacion Parametros Generales", doc, table);	
		
		button_aceptarbutton(ANY, LOADED).click();
	}
}

