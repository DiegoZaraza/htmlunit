package ScriptsGenerales;
import resources.ScriptsGenerales.SC_LoginHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author dzaraza
 */
public class SC_Login extends SC_LoginHelper
{
	public void testMain(Object[] args) 
	{
		if(!browser_htmlBrowser(ANY, LOADED).exists())
			startApp("" + args[1]);

		if(!text_txt_TkenSOfiA(ANY, LOADED).isEnabled())
			callScript("Scripts_Generales.SC_MensajesCanales", args);

		text_txt_TkenSOfiA(ANY, LOADED).waitForExistence();
		text_txt_ClienteSOfiA(ANY, LOADED).setText("" + args[2]);
		text_txt_TkenSOfiA(ANY, LOADED).setText("" + args[3]);
		browser_htmlBrowser(document_httpsBop0077CanalesEn(ANY, LOADED),DEFAULT_FLAGS).inputKeys("{TAB}");

		button_aceptarbutton(ANY, LOADED).click();
		
		args[9] = false;
		
		callScript("ScriptsGenerales.SC_MensajesCanales", args);
		callScript("ScriptsGenerales.SC_MensajesCanales", args);
		
		if(text_lbl_ttlo().getProperty(".value").equals("Conexion de Usuarios"))
			button_aceptarbutton2(ANY, LOADED).click();
		
		browser_htmlBrowser(document_httpsBop0077CanalesEn(ANY, LOADED),DEFAULT_FLAGS).inputKeys("{F11}");
	}
}