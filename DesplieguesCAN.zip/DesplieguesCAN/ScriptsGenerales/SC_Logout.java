package ScriptsGenerales;
import resources.ScriptsGenerales.SC_LogoutHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author dzaraza
 */
public class SC_Logout extends SC_LogoutHelper {
	public void testMain(Object[] args) {
		html_btn_Slir(ANY, LOADED).click();
		button_htmlDialogButtonAceptar(ANY, LOADED).click();
		button_cerrarbutton(ANY, LOADED).click();
		button_htmlDialogButtonS�(ANY,MAY_EXIT).click();
	}
}