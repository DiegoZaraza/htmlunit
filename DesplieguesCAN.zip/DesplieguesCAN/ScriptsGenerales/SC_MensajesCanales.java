package ScriptsGenerales;

import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.ScriptsGenerales.SC_MensajesCanalesHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;


public class SC_MensajesCanales extends SC_MensajesCanalesHelper {
	public boolean testMain(Object[] args) throws IOException, DocumentException {
		Document doc = (Document) args[5];
		PdfPTable table = (PdfPTable) args[7];
		Boolean valida = (boolean)args[9];
		// DEFINICION VARIABLE PARA ALMACENAR LA CAPTURA DE PANTALLA
		RenderedImage imagen;

		esperarObjeto(html_htmlDialog(ANY, LOADED));

		boolean retorno = false;

		if (html_htmlDialog(ANY, LOADED).exists() && html_htmlDialog(ANY, LOADED).isShowing()) {
			// CONDICION DONDE INGRESA CUANDO LA VENTANA ESTA ACTIVA Y EXISTENTE
			if(valida) {
				imagen = html_htmlDialog(ANY, LOADED).getScreenSnapshot();
				guardarImagen(imagen, "Mensaje Validacion", doc, table);
			}
			// CLICK EN ACEPTAR
			button_htmlDialogButtonAceptar(ANY, LOADED).waitForExistence();
			button_htmlDialogButtonAceptar(ANY, LOADED).click();
			retorno = true;
		}
		return retorno;
	}
}