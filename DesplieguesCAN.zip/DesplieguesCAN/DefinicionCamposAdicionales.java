import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.DefinicionCamposAdicionalesHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;

public class DefinicionCamposAdicionales extends DefinicionCamposAdicionalesHelper {
	public void testMain(Object[] args) throws IOException, DocumentException {
		Document doc = (Document) args[5];
		PdfPTable table = (PdfPTable) args[7];
		
		list_ldw_Cnal(ANY, LOADED).click();
		browser_htmlBrowser(document_httpsBop0077CanalesSC(ANY, LOADED), DEFAULT_FLAGS).inputKeys("Oficina Normal" + "{TAB}");

		list_ldw_srvcio(ANY, LOADED).click();
		browser_htmlBrowser(document_httpsBop0077CanalesSC(ANY, LOADED), DEFAULT_FLAGS).inputKeys("Conexion Usuario" + "{TAB}");

		callScript("ScriptsBotones.BtnConsultar");
				
		ITestDataTable tabla = (ITestDataTable) table_tbl_CmposAdcionles(ANY, LOADED).getTestData("contents");
		int Ki = 0;
		String flag = "";

		guardarImagen((RenderedImage) document_httpsBop0077CanalesSC(ANY,LOADED).getScreenSnapshot(), "Definicion Campos Adicionales", doc, table);

		while (Ki < tabla.getRowCount() && flag.equals("")) {
			TestObject celda = table_tbl_CmposAdcionles(ANY, LOADED).find(
					atList(atChild(".class", "Html.TBODY"), atChild(".class", "Html.TR", "rowIndex", Ki), atChild(".class", "Html.TD", "cellIndex", 1)), false)[0];

			TestObject[] wrappedObj = celda.find(atChild(".class", "Html.INPUT.text"));

			if (wrappedObj.length > 0) {
				String valor = (String) ((TextGuiTestObject) wrappedObj[0]).getProperty(".value");

				if (valor.equals("ValidacionTexto1Xvalor")) {
					celda = table_tbl_CmposAdcionles(ANY, LOADED).find(
							atList(atChild(".class", "Html.TBODY"), atChild(".class", "Html.TR", "rowIndex", Ki), atChild(".class", "Html.TD", "cellIndex", 3)), false)[0];

					wrappedObj = celda.find(atChild(".class", "Html.INPUT.button"));
					((GuiTestObject) wrappedObj[0]).click();
					flag = "1";
				}
			}
			Ki++;
		}

		callScript("DetallesCamposAdicionales.DetallesCampos", args);

		checkBox_chk_pblcarSrvon(ANY, LOADED).click();

		guardarImagen((RenderedImage)document_httpsBop0077CanalesSC(ANY, LOADED).getScreenSnapshot(), "Registra Operacion", doc, table);

		button_aceptarbutton(ANY, LOADED).click();

		callScript("ScriptsGenerales.SC_MensajesCanales", args);

		html_btn_Slir(ANY, LOADED).click();
		//(10);
	}
}