package SuperClase;

import java.awt.image.BufferedImage;

import java.awt.image.RenderedImage;
import java.io.*;
import java.net.MalformedURLException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.Vector;
import java.util.regex.*;

import javax.imageio.ImageIO;

import org.eclipse.hyades.edit.datapool.IDatapool;

import com.google.common.collect.Table;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;

import com.rational.test.ft.datapool.DatapoolFactory;
import com.rational.test.ft.datapool.DatapoolUtilities;
import com.rational.test.ft.object.interfaces.GuiTestObject;
import com.rational.test.ft.script.RationalTestScript;

public abstract class Helper extends RationalTestScript {
	protected int i;
	String cont;

	// METODO PARA ESPERAR QUE EL OBJETO CARGUE
	public boolean esperarObjeto(GuiTestObject objeto) {
		// DECLARA VARIABLE Y LA INICIALIZA
		i = 0;

		boolean val = false;

		// REALIZA EL CICLO MIENTRA EL OBJETO EXISTE
		while (i < 30 && !objeto.exists()) {
			// RETARDO Y SUMA EL CONTADOR
			sleep(1.5);
			i++;
			val = objeto.exists();
		}

		return val;
	}

	// FUNCION PARA ESPERAR QUE EL OBJETO CARGUE
	public void esperarContenido(GuiTestObject text) {
		// DECLARA VARIABLE Y LA INICIALIZA
		i = 0;
		cont = "";

		// REALIZA EL CICLO MIENTRAS ESPERA EL CONTENIDO
		while (i < 10 && cont.equals("")) {
			// CARGA EL CONTENIDO DEL CAMPO EN VARIABLE
			cont = (String) text.getProperty(".value");
			sleep(2);
			i++;
		}
	}

	public void waitEnable(GuiTestObject text) {
		// DECLARA VARIABLE Y LA INICIALIZA
		i = 0;
		boolean variable = true;

		// REALIZA EL CICLO MIENTRAS ESPERA EL CONTENIDO
		while (i < 10 && variable) {
			// CARGA EL CONTENIDO DEL CAMPO EN VARIABLE
			variable = (boolean) text.getProperty(".disabled");
			sleep(2);
		}
	}

	// FUNCION PARA GUARDAR LAS IMAGENES CAPTURADAS
	public void guardarImagen(RenderedImage image, String Nombre, Document doc, PdfPTable table) throws IOException, DocumentException {
		String ruta = "D:\\EVIDENCIA\\" + Nombre + ObtenerHora() + " .jpg";

		// DECLARA Y CREA EL ARCHIVO CON LA IMAGEN RECIBIDA
		File file = new File(ruta);
		ImageIO.write(image, "jpg", file);
//		cutImage(ruta);
		addImage(ruta, doc, table, Nombre);
	}

	// METODO QUE CREA UN PDF PARA PRESENTAR LOS RESULTADOS DE LOS SCRIPT
	public class FooterPiePaginaiText extends PdfPageEventHelper {
		
		Font piePagina, encabezado;
		
		@Override
		public void onStartPage(PdfWriter writer, Document document) {	
			try {
				encabezado = new Font(BaseFont.createFont("D:/resources/kalinga.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 12, Font.BOLD, BaseColor.BLACK);
				piePagina = new Font(BaseFont.createFont("d:/resources/kalinga.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 9, Font.NORMAL, BaseColor.BLACK);
			} catch (DocumentException | IOException e1) {
				// TODO Bloque catch generado autom�ticamente
				e1.printStackTrace();
			}
			Image img;
			try {
				img = Image.getInstance("D:/resources/Logo.jpg");
				img.scaleAbsolute(114, 39);
				img.setAbsolutePosition(document.left(), document.top() + 30);
				writer.getDirectContent().addImage(img);
			} catch (BadElementException e) {
				e.printStackTrace();
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (DocumentException e) {
				e.printStackTrace();
			}

			Paragraph texto1 = new Paragraph("DIRECCI�N DE DESARROLLO TECNOL�GICO", encabezado);
			Paragraph texto2 = new Paragraph("Checklist Armado Versi�n", piePagina);

			String annio = ObtenerFecha().substring(0,4);
			String mes = ObtenerFecha().substring(4,6);
			String dia = ObtenerFecha().substring(6,8);

			Paragraph texto3 = new Paragraph(dia + "/" + mes + "/" + annio, piePagina);

			texto2.setAlignment(Paragraph.ALIGN_CENTER);
			texto1.setAlignment(Paragraph.ALIGN_CENTER);
			texto3.setAlignment(Paragraph.ALIGN_CENTER);


			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER, texto1, 363, document.top() + 57, 0);
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT, texto2, 199, document.top() + 37, 0);
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_RIGHT, texto3, document.right(), document.top() + 37, 0);

		}

		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			Paragraph texto2 = new Paragraph("Automatizaci�n de Pruebas", piePagina);
			Paragraph NroPagina = new Paragraph("" + document.getPageNumber(), piePagina);
			Paragraph texto4 = new Paragraph("Versi�n Mes de " + ObtenerMes(), piePagina);

			texto2.setAlignment(Paragraph.ALIGN_LEFT);
			NroPagina.setAlignment(Paragraph.ALIGN_RIGHT);
			texto4.setAlignment(Paragraph.ALIGN_CENTER);

			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_RIGHT, NroPagina, document.right(), document.bottom() - 30, 0);
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT, texto2, document.left(), document.bottom() - 30, 0);
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER, texto4, 363, document.bottom() - 30, 0);
		}
	}

	// SE CREA UN DOCUMENTO CON TAMA�O CARTA Y SE ESCOJE LA RUTA Y NOMBRE DEL ARCHIVO
	public Document createPdf(Object[] args) throws DocumentException, MalformedURLException, IOException {		
		Document documento = new Document(PageSize.LETTER, 85, 85, 114, 60);

		String Mes = ObtenerMes();
		String Fecha = ObtenerFecha();

		String archivo = "D:\\Despliegues\\Despliegue_CAN_" + Mes + "_" + Fecha + "_" + args[4] + ".pdf";

		PdfWriter writer = PdfWriter.getInstance(documento, new FileOutputStream(archivo, true));
		FooterPiePaginaiText event = new FooterPiePaginaiText();
		writer.setPageEvent(event);

		// SE LE AGREGA EL TITULO Y AUTOR AL DOCUMENTO
		documento.addTitle("Proceso Despliegue Canales Version - " + Mes);
		documento.addAuthor("Equipo de Automatizaci�n - Direcci�n de Desarrollo Tecnologico");
		documento.open();

		return documento;
	}

	public PdfPTable creartabla(Document doc) {
		PdfPTable table = new PdfPTable(1);
		table.setTotalWidth(442);

		return table;
	}

	public void createCell(String content, float borderWidth, int colspan, int alignment, Document doc, PdfPTable table) throws DocumentException, IOException {
		Font contenido = new Font(BaseFont.createFont("d:/resources/kalinga.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 9, Font.NORMAL, BaseColor.BLACK);
		PdfPCell cell = new PdfPCell(new Phrase(content, contenido));
		cell.setBorderWidth(borderWidth);
		cell.setColspan(colspan);
		cell.setHorizontalAlignment(alignment);

		table.addCell(cell);
	}
	
	public void createCellTitle(String content, float borderWidth, int colspan, int alignment, Document doc, PdfPTable table) throws DocumentException, IOException {
		Font titulos = new Font(BaseFont.createFont("d:/resources/kalinga.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 10, Font.BOLD, BaseColor.BLACK);
		PdfPCell cell = new PdfPCell(new Phrase(content, titulos));
		cell.setBorderWidth(borderWidth);
		cell.setColspan(colspan);
		cell.setHorizontalAlignment(alignment);

		table.addCell(cell);
	}

	public void createCellImg(Image imagen, float borderWidth, int colspan, int alignment, Document doc, PdfPTable table, String prop) throws DocumentException, IOException {
			Font pieFoto = new Font(BaseFont.createFont("d:/resources/kalinga.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED), 6, Font.NORMAL, BaseColor.BLACK);
			
			PdfPTable prov = new PdfPTable(1);

			PdfPCell cell = new PdfPCell(imagen);

			cell.setBorderWidth(borderWidth);
			cell.setColspan(colspan);
			cell.setHorizontalAlignment(alignment);

			prov.addCell(cell);

			Phrase parr = new Phrase(prop, pieFoto);

			cell = new PdfPCell(parr);

			cell.setBorderWidth(borderWidth);
			cell.setColspan(colspan);
			cell.setHorizontalAlignment(alignment);

			prov.addCell(cell);

			cell = new PdfPCell(prov);
			cell.setBorderWidth(borderWidth);
			cell.setColspan(colspan);
			cell.setHorizontalAlignment(alignment);
			
			table.addCell(cell);
	}

	/* M�otdo para agregar una im�gen a un PDF */
	public void addImage(String ruta, Document doc, PdfPTable table, String nombre) throws DocumentException {
		Image imagen;
		try {
			imagen = Image.getInstance(ruta);

			imagen.setAlignment(Image.ALIGN_CENTER);
			imagen.setUseVariableBorders(true);
			imagen.scalePercent(30);
			//			imagen.setAnnotation(annotation)	
			createCellImg(imagen, 0, 1, Element.ALIGN_CENTER, doc, table, nombre);
		} catch (BadElementException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}

	/* M�todo para cerrar PDF */
	public void closePDF(Document doc, PdfPTable table) throws DocumentException {
		doc.add(table);
		doc.close();
	}

	// METODO QUE RECORTA LA IMAGEN A UNAS MEDIDAS PREESTABLESIDAS
	public void cutImage(String ruta) throws IOException {
		File file = new File(ruta);
		BufferedImage bi = ImageIO.read(file);

		if (bi.getWidth() > 937) {
			bi = bi.getSubimage(0, 0, 937, bi.getHeight());
			ImageIO.write(bi, "jpg", file);
		}
	}

	/**
	 * 
	 * METODOS PARA EL MANEJO DE HORA, MINUTOS Y SEGUNDOS (FECHAS)
	 * 
	 * */

	// M�todo para obtener FECHA en formato, A�o/Mes/Dia
	public String ObtenerFecha() {
		String fecha;
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("yyyyMMdd");
		fecha = formato.format(calendar.getTime());
		return fecha;
	}

	// M�todo para obtener mes de certificaci�n
	public String ObtenerMes() {
		Calendar miCalendario = Calendar.getInstance();
		int mes;
		String m;

		if (ObtenerDia() > 20)
			if (miCalendario.get(Calendar.MONTH) == 11)
				mes = 1;
			else
				mes = miCalendario.get(Calendar.MONTH) + 2;
		else
			mes = miCalendario.get(Calendar.MONTH) + 1;

		if (mes < 10)
			m = "0" + mes;
		else
			m = "" + mes;

		String mesCertif = null;
		switch (m) {

			case "01": {
				mesCertif = "Enero";
				break;
			}
			case "02": {
				mesCertif = "Febrero";
				break;
			}
			case "03": {
				mesCertif = "Marzo";
				break;
			}
			case "04": {
				mesCertif = "Abril";
				break;
			}
			case "05": {
				mesCertif = "Mayo";
				break;
			}
			case "06": {
				mesCertif = "Junio";
				break;
			}
			case "07": {
				mesCertif = "Julio";
				break;
			}
			case "08": {
				mesCertif = "Agosto";
				break;
			}
			case "09": {
				mesCertif = "Septiembre";
				break;
			}
			case "10": {
				mesCertif = "Octubre";
				break;
			}
			case "11": {
				mesCertif = "Noviembre";
				break;
			}
			case "12": {
				mesCertif = "Diciembre";
				break;
			}
		}
		return mesCertif;
	}

	// M�todo para obteber el d�a actual
	public Integer ObtenerDia() {
		Calendar miCalendario = Calendar.getInstance();
		int diaHoy = miCalendario.get(Calendar.DAY_OF_MONTH);
		return diaHoy;
	}

	// M�todo para obtener HORA en formato Hora:Minutos:Segundos
	public String ObtenerHora() {
		String hora;
		Date fechaActual = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fechaActual); // Fecha Actual
		SimpleDateFormat formato = new SimpleDateFormat("HHmmss");
		calendar.get(Calendar.MONTH);
		hora = formato.format(calendar.getTime());
		return hora;
	}
}