import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.MttoEventosyAccionesHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;

public class MttoEventosyAcciones extends MttoEventosyAccionesHelper {
	public void testMain(Object[] args) throws IOException, DocumentException {
		Document doc = (Document) args[5];
		PdfPTable table = (PdfPTable) args[7];
		
		String[] Servicios = { "2121", "21641", "2164", "2160" };

		for (int i = 0; i < Servicios.length; i++) {
			args[8] = Servicios[i];

			image_ayudaParaBuscarServicio(ANY, LOADED).click();

			callScript("DetallesCamposAdicionales.BusquedaServicio", args); //(20);

			ITestDataTable tabla = (ITestDataTable) table_tbl_GrposAccionesEvntos(ANY, LOADED).getTestData("contents");
			int Ki = 0;
			String flag = "";

			while (Ki < tabla.getRowCount() && flag.equals("")) {
				TestObject celda = table_tbl_GrposAccionesEvntos(ANY, LOADED).find(
						atList(atChild(".class", "Html.TBODY"), atChild(".class", "Html.TR", "rowIndex", Ki), atChild(".class", "Html.TD", "cellIndex", 6)), false)[0];

				TestObject[] wrappedObj = celda.find(atChild(".class", "Html.SELECT"));

				if (wrappedObj.length > 0) {

					String valor = (String) ((SelectGuiSubitemTestObject) wrappedObj[0]).getProperty(".value");

					if (valor.equals("ContinuarXvalor")) {
						celda = table_tbl_GrposAccionesEvntos(ANY, LOADED).find(
								atList(atChild(".class", "Html.TBODY"), atChild(".class", "Html.TR", "rowIndex", Ki), atChild(".class", "Html.TD", "cellIndex", 9)), false)[0];

						wrappedObj = celda.find(atChild(".class", "Html.INPUT.button"));
						((GuiTestObject) wrappedObj[0]).click();

						callScript("DetallesCamposAdicionales.DetalleEventosAcciones", args);

						flag = "1";
					}
				}
				Ki++;
			}
			checkBox_chk_pblcarSrvon(ANY, LOADED).click();
			guardarImagen((RenderedImage)document_httpsBop0077CanalesSC(ANY, LOADED).getScreenSnapshot() , "Respaldo Los Historico de Servicios", doc, table);	
			button_aceptarbutton(ANY, LOADED).click();
			
			callScript("ScriptsGenerales.SC_MensajesCanales", args);
		}
	}
}