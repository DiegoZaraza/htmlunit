
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.EliminarRolHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.pdf.PdfPTable;

public class EliminarRol extends EliminarRolHelper {
	public void testMain(Object[] args) throws IOException, DocumentException {
		
		Document doc = (Document) args[5];
		PdfPTable table = (PdfPTable) args[7];
		
		list_ldw_Rles(ANY, LOADED).click();
		browser_htmlBrowser(document_httpsBop0077CanalesSC(ANY, LOADED),DEFAULT_FLAGS).inputKeys(args[0] + "{TAB}");
			
		callScript("ScriptsBotones.BtnConsultar");//(3);

		guardarImagen((RenderedImage)document_httpsBop0077CanalesSC(ANY, LOADED).getScreenSnapshot() , "Elimina Rol " + args[0], doc, table);
		
		button_borrarbutton(ANY, LOADED).click();
		callScript("ScriptsGenerales.SC_MensajesCanales", args);//(5);
		callScript("ScriptsGenerales.SC_MensajesCanales", args);//(5);
		
		callScript("ScriptsGenerales.SC_MensajesCanales", args);//(5);
		
		browser_htmlBrowser(document_httpsBop0077CanalesEn(ANY, LOADED),DEFAULT_FLAGS).close();
	}
}