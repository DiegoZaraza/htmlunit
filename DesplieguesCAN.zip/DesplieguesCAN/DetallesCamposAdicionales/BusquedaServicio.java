package DetallesCamposAdicionales;

import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.DetallesCamposAdicionales.BusquedaServicioHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;


public class BusquedaServicio extends BusquedaServicioHelper {
	public void testMain(Object[] args) throws IOException, DocumentException {
		Document doc = (Document) args[5];
		PdfPTable table = (PdfPTable) args[7];
		
		text_txt_Cdgo(ANY, LOADED).waitForExistence();
		
		text_txt_Cdgo(ANY, LOADED).click();
		browser_htmlHTMLDialog(document_soluci�nDeOficinasB�s(ANY, LOADED), DEFAULT_FLAGS).inputKeys("" + args[8]);

		guardarImagen((RenderedImage)document_soluci�nDeOficinasB�s(ANY, LOADED).getScreenSnapshot() , "Buesqueda Servicio " + args[8], doc, table);
		
		button_buscarbutton(ANY, LOADED).click();
		//(5);
	}
}
