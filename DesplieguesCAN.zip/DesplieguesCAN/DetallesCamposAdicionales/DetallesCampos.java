package DetallesCamposAdicionales;
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.DetallesCamposAdicionales.DetallesCamposHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;

public class DetallesCampos extends DetallesCamposHelper {
	public void testMain(Object[] args) throws IOException, DocumentException {
		Document doc = (Document) args[5];
		PdfPTable table = (PdfPTable) args[7];
		
		link_fuenteDeDatos(ANY, LOADED).click();
		
		text_txt_Frmla_CM1(ANY, LOADED).setText("'" + args[4] + "'");

		guardarImagen((RenderedImage)document_soluci�nDeOficinasDet(ANY, LOADED).getScreenSnapshot(), "Cambia Version en Fuente de Datos " + args[4], doc, table);
		
		link_valorPorDefecto(ANY, LOADED).click();
		
		text_txt_NmbreVrDfcto_CM1(ANY, LOADED).setText("'" + args[4] + "'");
		guardarImagen((RenderedImage)document_soluci�nDeOficinasDet(ANY, LOADED).getScreenSnapshot(), "Cambia Version en Valor por Defecto" + args[4], doc, table);
		
		button_aceptarbutton(ANY, LOADED).click();
	}
}