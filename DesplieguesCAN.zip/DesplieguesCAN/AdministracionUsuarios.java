
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.AdministracionUsuariosHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;

public class AdministracionUsuarios extends AdministracionUsuariosHelper {
	public void testMain(Object[] args) throws IOException, DocumentException {
		Document doc = (Document) args[5];
		PdfPTable table = (PdfPTable) args[7];
		String[] usuario = (String[]) args[6];
		
		list_ldw_UsuarioComTU(ANY, LOADED).waitForExistence();
		
		for(int i = 0; i < usuario.length; i++)
		{
			list_ldw_UsuarioComTU(ANY, LOADED).click();
			browser_htmlBrowser(document_httpsBop0077CanalesSC(),DEFAULT_FLAGS).inputKeys(usuario[i] + "{TAB}");
			
			callScript("ScriptsBotones.BtnConsultar");

			guardarImagen((RenderedImage)document_httpsBop0077CanalesSC(ANY, LOADED).getScreenSnapshot(), "Busqueda de Usuario " + usuario[i], doc, table);

			link_rolJornada(ANY, LOADED).click();
			
			button__Button(ANY, LOADED).click();

			list_lst_DisRlesTT(ANY, LOADED).click(atText("Jefe de Servicios SB"));
			button__button(ANY, LOADED).click();
			
			list_ldw_RolActvoTT(ANY, LOADED).click();
			browser_htmlHTMLDialog(document_soluci�nDeOficinasAsi(),DEFAULT_FLAGS).inputKeys("Administrador de Usuarios" + "{TAB}");
			
			guardarImagen(document_soluci�nDeOficinasAsi().getScreenSnapshot(), "Asiga Administrador de Usuario", doc, table);
			
			button_aceptarbutton(ANY, LOADED).click();//(5);
			
			button_aceptarbutton2(ANY, LOADED).click();//(5);
		}
		
		html_btn_Slir(ANY, LOADED).click();

	}
}