
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.ConsultaUsuarioHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.pdf.PdfPTable;
/**
 * Description   : Functional Test Script
 * @author dzaraza
 */
public class ConsultaUsuario extends ConsultaUsuarioHelper {
	public String[] testMain(Object[] args) throws IOException, DocumentException {
		Document doc = (Document) args[5];
		PdfPTable table = (PdfPTable) args[7];
		
		checkBox_chk_MstrarCtaUsuon(ANY, LOADED).waitForExistence();
		checkBox_chk_MstrarCtaUsuon(ANY, LOADED).click();
		
		list_ldw_CrtrioRol(ANY, LOADED).click();
		browser_htmlBrowser(document_soluci�nDeOficinas(),DEFAULT_FLAGS).inputKeys("Grupo de Parametrizacion" + "{TAB}");
		
		button_aceptarbutton(ANY, LOADED).click();//(5);
		
		ITestDataTable tabla = (ITestDataTable) table_tbl_Dtlle(ANY, LOADED).getTestData("contents");
		int Ki = 0;
		String flag = "";
		String[] usuarios = new String[tabla.getRowCount()];
				
		while(Ki < tabla.getRowCount() && flag.equals("")) {
			TestObject celda = table_tbl_Dtlle(ANY, LOADED).find(atList(atChild(".class", "Html.TBODY"),
					atChild(".class","Html.TR","rowIndex", Ki), 
					atChild(".class","Html.TD","cellIndex", 1)),false)[0];

			TestObject []wrappedObj = celda.find(atChild(".class", "Html.INPUT.text"));

			if(wrappedObj.length > 0)		
				usuarios[Ki] = (String) ((TextGuiTestObject ) wrappedObj[0]).getProperty(".value");
			
			Ki++;
		}
		
		guardarImagen((RenderedImage)document_soluci�nDeOficinas(ANY, LOADED).getScreenSnapshot(), "Consulta Usuario Rol " + args[0], doc, table);
		createCell("Consulta Usuarios con Rol Grupo Parametrizacion", 0, 1, Element.ALIGN_JUSTIFIED, doc, table);
		
		button_regresarbutton(ANY, LOADED).click();//(5);
		button_regresarbutton(ANY, LOADED).click();
		return usuarios;
	}
}