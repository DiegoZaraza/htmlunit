
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.RespaldoEInicializacionHistSegHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.pdf.PdfPTable;

public class RespaldoEInicializacionHistSeg extends RespaldoEInicializacionHistSegHelper {
	public void testMain(Object[] args) throws IOException, DocumentException {
		Document doc = (Document) args[5];
		PdfPTable table = (PdfPTable) args[7];
		
		list_ldw_Script(ANY, LOADED).click();
		browser_htmlBrowser(document_soluci�nDeOficinas(ANY, LOADED),DEFAULT_FLAGS).inputKeys("RespaldoEInicializacionLogSeg" + "{TAB}");
		
		guardarImagen((RenderedImage)document_soluci�nDeOficinas(ANY, LOADED).getScreenSnapshot() , "Respaldo Historico Log de Seguridad", doc, table);
		
		button_aceptarbutton(ANY, LOADED).click();
	}
}