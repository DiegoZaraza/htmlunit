
import java.awt.image.RenderedImage;
import java.io.IOException;

import resources.VerificarDLLHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.pdf.PdfPTable;
/**
 * Description   : Functional Test Script
 * @author dzaraza
 */
public class VerificarDLL extends VerificarDLLHelper
{
	public void testMain(Object[] args) throws IOException, DocumentException 
	{
		Document doc = (Document) args[5];
		PdfPTable table = (PdfPTable) args[7];
		
		String[] WebServices = {"Biometria_Bogota", "WebServiceFirmas", "WebServices_Doc_Cc_Ef_Firmas"};
		String[] Ubicacion = {"http://10.86.79.69/BiometriaWeb/ECGTSWS.dll/wsdl/IECGTSWS ",
				"http://10.85.2.64:8200/wsFirmasV2/servicioFirmasPort?WSDL", 
				"http://10.85.2.64:8200/wsFirmasAutorizadasEncargosFiduciarios/firmasPort?WSDL"};

		for(int i = 0; i < WebServices.length; i++)
		{
			list_ldw_WebSrvce(ANY, LOADED).click();
				
			browser_htmlBrowser(document_httpsBop0077CanalesSC(ANY, LOADED), DEFAULT_FLAGS).inputKeys(WebServices[i] + "{TAB}");
			
			callScript("ScriptsBotones.BtnConsultar");

			text_txt_Ubccion(ANY, LOADED).setText(Ubicacion[i]);
			browser_htmlBrowser(document_httpsBop0077CanalesSC(ANY, LOADED), DEFAULT_FLAGS).inputKeys("{TAB}");
			
			guardarImagen((RenderedImage)document_httpsBop0077CanalesSC(ANY, LOADED).getScreenSnapshot(), "Validacion WebService " + WebServices[i] , doc, table);
			
			button_importarWSDLbutton(ANY, LOADED).click();

			callScript("ScriptsGenerales.SC_MensajesCanales", args);
			
			button_aceptarbutton(ANY, LOADED).click();
			
			callScript("ScriptsGenerales.SC_MensajesCanales", args);
		}		
		html_btn_Slir(ANY, LOADED).click();
	}
}