
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Toolkit;
import javax.swing.SwingConstants;

import resources.MainHelper;

import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.pdf.PdfPTable;

import java.awt.List;
import java.awt.Panel;
import java.awt.Label;
import java.awt.Button;
import java.awt.TextField;

public class Main extends MainHelper {
	Document doc = null;
	PdfPTable table = null;
			
	@SuppressWarnings("unchecked")
	public void testMain(Object[] args) throws DocumentException {
		try {
			String userjs = null;
			String passjs = null;
			
			args= new Object[10];
			
			args[0] = "Grupo de Parametrizacion";
			args[9] = true;
			
			
			JLabel labelCombo = new JLabel("Servidor:");

			String[] item = new String[]{"BOP0071", "BOP0072", "BOP0077"};
			@SuppressWarnings("rawtypes")
			JComboBox comboServidor = new JComboBox(item);
			
			JLabel labelLogin = new JLabel("Usuario Grupo Parametrizador:");
			JTextField login = new JTextField();
			 
			JLabel labelPassword = new JLabel("Password Grupo Parametrizador:");
			JPasswordField password = new JPasswordField();
			
			JLabel labelLoginJefe = new JLabel("Usuario Jefe de Servicios:");
			JTextField loginJefe = new JTextField();
			 
			JLabel labelPasswordJefe = new JLabel("Password Jefe de Servicios:");
			JPasswordField passwordJefe = new JPasswordField();
			 
			JLabel labelVersion = new JLabel("Versi�n Software:");
			JTextField version = new JTextField();
			
			Object[] array = { labelCombo, comboServidor, labelLogin,  login, labelPassword, password, labelLoginJefe, loginJefe, labelPasswordJefe, passwordJefe, labelVersion, version};
			 
			int res = JOptionPane.showConfirmDialog(null, array, "Configuraci�n Par�metros", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
			 
			if (res == JOptionPane.OK_OPTION) {
				args[1] = comboServidor.getSelectedItem();
			    args[2] = login.getText().trim();
			    args[3] = new String(password.getPassword());
			    args[4] = version.getText().trim();
			    userjs = loginJefe.getText().trim();
			    passjs = new String(passwordJefe.getPassword());
			    
			    doc = createPdf(args);			
				table = creartabla(doc);
				
				args[5] = doc;
				args[7] = table;
				
				callScript("ScriptsGenerales.SC_Login", args);

				callScript("ScriptsBotones.BtnServiciosOperativos", args);
				callScript("MenuServicioOperativo.LnkCambioRol", args);
				callScript("CambioRol", args);

				createCellTitle("MODIFICACION ETIQUETAS DE LA VERSI�N DE PRODUCCI�N", 0, 1, Element.ALIGN_CENTER, doc, table);

				callScript("ScriptsBotones.BtnServiciosOperativos", args);
				callScript("MenuServicioOperativo.LnkParametrizacionServicios", args);
				callScript("MenuParametrizacion.MnServiciosOperativosDCA", args);
				callScript("DefinicionCamposAdicionales", args); sleep(5);
				
				doc.add(table);
				doc.newPage();
				table = creartabla(doc);
				
				createCellTitle("TERMINALES DE PRODUCCI�N IDM", 0, 1, Element.ALIGN_CENTER, doc, table);
				
				callScript("ScriptsBotones.BtnServiciosOperativos", args);
				callScript("MenuServicioOperativo.LnkParametrosInstGenericos", args);
				callScript("ParametrosGenerales", args);

				doc.add(table);
				doc.newPage();
				table = creartabla(doc);
				
				createCellTitle("RESPALDO LOG HISTORICO", 0, 1, Element.ALIGN_CENTER, doc, table);
				
				callScript("MenuServicioOperativo.LnkRespaldoHistSeguridad", args);
				callScript("RespaldoEInicializacionHistSeg", args);

				doc.add(table);
				doc.newPage();
				table = creartabla(doc);
				
				createCellTitle("RESPALDO LOG DE SEGURIDAD", 0, 1, Element.ALIGN_CENTER, doc, table);
				
				callScript("MenuServicioOperativo.LnkRespaldoHistoricoServicios", args);
				callScript("RespaldoEInicializacionHistServ", args);

				doc.add(table);
				doc.newPage();
				table = creartabla(doc);
				
				createCellTitle("CAMBIO MANUAL DEL SERVICIO", 0, 1, Element.ALIGN_CENTER, doc, table);
				
				callScript("MenuServicioOperativo.LnkParametrizacionServicios", args);
				callScript("MenuParametrizacion.MnServFinEspEventos", args);
				callScript("MttoEventosyAcciones", args);

				doc.add(table);
				doc.newPage();
				table = creartabla(doc);
				
				createCellTitle("VERIFICACION DLL'S", 0, 1, Element.ALIGN_CENTER, doc, table);
				
				callScript("MenuParametrizacion.MnMensajeTramaWS", args);
				callScript("VerificarDLL", args);

				callScript("ScriptsBotones.BtnServiciosOperativos", args);

				doc.add(table);
				doc.newPage();
				table = creartabla(doc);
				
				createCellTitle("CONSULTA DE USUARIOS", 0, 1, Element.ALIGN_CENTER, doc, table);
				
				callScript("MenuServicioOperativo.LnkConsultaDeUsuarios", args);
				String[] usuario = (String[]) callScript("ConsultaUsuario", args);

				callScript("MenuServicioOperativo.LnkCambioRol", args);

				args[0] = "Administrador de Usuarios";

				callScript("CambioRol", args);
				callScript("MenuServicioOperativo.LnkParametrizacionServicios", args);
				callScript("MenuServicioOperativo.LnkRoles");

				args[0] = "Grupo de Parametrizacion";
				
				doc.add(table);
				doc.newPage();
				table = creartabla(doc);
				
				createCellTitle("ELIMINACI�N DE ROL GRUPO PARAMETRIZACION", 0, 1, Element.ALIGN_CENTER, doc, table);
				callScript("EliminarRol", args);
				
				args[6] = usuario;

				String userpar = (String) args[2];
				String passpar = (String) args[3];

				args[2] = userjs;	
				args[3] = passjs;

				callScript("ScriptsGenerales.SC_Login", args);
				callScript("ScriptsBotones.BtnServiciosOperativos", args);
				callScript("MenuServicioOperativo.LnkParametrizacionServicios", args);
				callScript("MenuParametrizacion.MnUsuarios", args);
				callScript("AdministracionUsuarios", args);
				callScript("ScriptsGenerales.SC_Logout", args);

				args[2] = userpar;
				args[3] = passpar;

				callScript("ScriptsGenerales.SC_Login", args);
				callScript("ScriptsBotones.BtnServiciosOperativos", args);
				callScript("MenuServicioOperativo.LnkParametrizacionServicios", args);
				callScript("MenuServicioOperativo.LnkRoles", args);

				args[0] = "Administrador de Usuarios";
				
				doc.add(table);
				doc.newPage();
				table = creartabla(doc);
				
				createCellTitle("ELIMINACI�N DE ROL GRUPO ADMINISTRACIDOR DE USUARIOS", 0, 1, Element.ALIGN_CENTER, doc, table);
				callScript("EliminarRol", args);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(doc != null)
				closePDF(doc, table);
		}
	}
}