
import resources.CambioRolHelper;
import com.rational.test.ft.*;
import com.rational.test.ft.object.interfaces.*;
import com.rational.test.ft.object.interfaces.SAP.*;
import com.rational.test.ft.object.interfaces.WPF.*;
import com.rational.test.ft.object.interfaces.dojo.*;
import com.rational.test.ft.object.interfaces.siebel.*;
import com.rational.test.ft.object.interfaces.flex.*;
import com.rational.test.ft.object.interfaces.generichtmlsubdomain.*;
import com.rational.test.ft.script.*;
import com.rational.test.ft.value.*;
import com.rational.test.ft.vp.*;
import com.ibm.rational.test.ft.object.interfaces.sapwebportal.*;
/**
 * Description   : Functional Test Script
 * @author dzaraza
 */
public class CambioRol extends CambioRolHelper
{
	/**
	 * Script Name   : <b>CambioRol</b>
	 * Generated     : <b>12/04/2017 11:07:36</b>
	 * Description   : Functional Test Script
	 * Original Host : WinNT Version 6.1  Build 7601 (S)
	 * 
	 * @since  2017/04/12
	 * @author dzaraza
	 */
	public void testMain(Object[] args) 
	{
		list_ldw_NvelActvo(ANY, LOADED).click();
		browser_htmlBrowser(document_soluci�nDeOficinas(),DEFAULT_FLAGS).inputKeys(args[0] + "{TAB}");
		
		button_aceptarbutton(ANY, LOADED).click();//(10);
		
		button_aceptarbutton2(ANY, LOADED).click();
		
	}
}

